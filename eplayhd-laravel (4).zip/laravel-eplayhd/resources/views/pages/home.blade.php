@extends('layouts.app')

@section('title', $siteSettings->site_title ?? 'ePlayHD - Live Sports Streaming')
@section('meta_description', $siteSettings->site_description ?? '')
@section('meta_keywords', $siteSettings->site_keywords ?? '')

@section('content')
<main class="main-content">
    {{-- Banner/Hero Slider --}}
    @if($banners->count() > 0)
    @include('components.banner-slider', ['banners' => $banners, 'sliderDuration' => $sliderDuration])
    @endif

    {{-- Header Ad Slot --}}
    @if($siteSettings?->ads_enabled && $siteSettings?->header_ad_code)
    <div class="ad-slot container mx-auto px-4 py-2">
        {!! $siteSettings->header_ad_code !!}
    </div>
    @endif

    {{-- Match List --}}
    <section class="matches-section container" id="matches">
        {{-- Filters --}}
        <div class="match-filters">
            <div class="filter-tabs">
                <button class="filter-tab {{ !request('status') || request('status') === 'all' ? 'active' : '' }}"
                    onclick="filterMatches('all')">All</button>
                <button class="filter-tab {{ request('status') === 'live' ? 'active' : '' }}"
                    onclick="filterMatches('live')">
                    <span class="live-dot"></span> Live
                </button>
                <button class="filter-tab {{ request('status') === 'upcoming' ? 'active' : '' }}"
                    onclick="filterMatches('upcoming')">Upcoming</button>
                <button class="filter-tab {{ request('status') === 'completed' ? 'active' : '' }}"
                    onclick="filterMatches('completed')">Completed</button>
            </div>

            {{-- Sport Filter --}}
            <div class="sport-filters">
                <button class="sport-btn {{ !request('sport') ? 'active' : '' }}" onclick="filterSport('')">All</button>
                @foreach($sports as $sport)
                <button class="sport-btn {{ request('sport') === $sport->id ? 'active' : '' }}"
                    onclick="filterSport('{{ $sport->id }}')">
                    @if($sport->icon_url)
                        <img src="{{ $sport->icon_url }}" alt="{{ $sport->name }}" class="w-4 h-4 inline">
                    @endif
                    {{ $sport->name }}
                </button>
                @endforeach
            </div>
        </div>

        {{-- Live Matches --}}
        @if($liveMatches->count() > 0)
        <div class="matches-group">
            <h2 class="section-title">
                <span class="live-badge">LIVE</span>
                Live Matches
            </h2>
            <div class="match-grid">
                @foreach($liveMatches as $match)
                    @include('components.match-card', ['match' => $match, 'index' => $loop->index])
                @endforeach
            </div>
        </div>
        @endif

        {{-- Upcoming Matches --}}
        @if($upcomingMatches->count() > 0)
        <div class="matches-group">
            <h2 class="section-title">Upcoming Matches</h2>
            <div class="match-grid">
                @foreach($upcomingMatches as $match)
                    @include('components.match-card', ['match' => $match, 'index' => $loop->index])
                @endforeach
            </div>
        </div>
        @endif

        {{-- Completed Matches --}}
        @if($completedMatches->count() > 0)
        <div class="matches-group">
            <h2 class="section-title">Recent Results</h2>
            <div class="match-grid">
                @foreach($completedMatches as $match)
                    @include('components.match-card', ['match' => $match, 'index' => $loop->index])
                @endforeach
            </div>
        </div>
        @endif

        @if($liveMatches->count() === 0 && $upcomingMatches->count() === 0 && $completedMatches->count() === 0)
        <div class="empty-state">
            <svg class="w-16 h-16 text-muted mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/>
            </svg>
            <p class="text-muted">No matches scheduled right now. Check back soon!</p>
        </div>
        @endif
    </section>

    {{-- Channels Section --}}
    @if($channels->count() > 0)
    <section class="channels-section container">
        <div class="section-header">
            <h2 class="section-title">
                <svg class="w-5 h-5 inline mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>
                </svg>
                Sports Channels
            </h2>
            <a href="{{ route('channels.index') }}" class="view-all-btn">View All →</a>
        </div>
        <div class="channel-grid">
            @foreach($channels as $channel)
            <a href="{{ route('channel.show', $channel->slug) }}" class="channel-card">
                <div class="channel-logo" style="{{ $channel->logo_background_color ? 'background-color:' . $channel->logo_background_color : '' }}">
                    @if($channel->logo_url)
                        <img src="{{ $channel->logo_url }}" alt="{{ $channel->name }}" class="channel-logo-img">
                    @else
                        <span class="channel-initials">{{ strtoupper(substr($channel->name, 0, 2)) }}</span>
                    @endif
                </div>
                <span class="channel-name">{{ $channel->name }}</span>
            </a>
            @endforeach
        </div>
    </section>
    @endif

    {{-- Live Tournaments --}}
    @if($liveTournaments->count() > 0)
    <section class="tournaments-section container">
        <h2 class="section-title">
            <svg class="w-5 h-5 inline mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/>
                <path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/>
                <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/>
                <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>
            </svg>
            Live Tournaments
        </h2>
        <div class="tournament-grid">
            @foreach($liveTournaments as $tournament)
            <a href="{{ route('tournament.show', $tournament->slug) }}" class="tournament-card">
                @if($tournament->logo_url)
                <div class="tournament-logo" style="{{ $tournament->logo_background_color ? 'background-color:' . $tournament->logo_background_color : '' }}">
                    <img src="{{ $tournament->logo_url }}" alt="{{ $tournament->name }}">
                </div>
                @endif
                <div class="tournament-info">
                    <h3 class="tournament-name">{{ $tournament->name }}</h3>
                    <span class="tournament-season">{{ $tournament->season }}</span>
                    <span class="tournament-sport">{{ $tournament->sport }}</span>
                </div>
            </a>
            @endforeach
        </div>
    </section>
    @endif

    {{-- Footer Ad Slot --}}
    @if($siteSettings?->ads_enabled && $siteSettings?->footer_ad_code)
    <div class="ad-slot container mx-auto px-4 py-2">
        {!! $siteSettings->footer_ad_code !!}
    </div>
    @endif
</main>

@push('scripts')
<script>
let currentFilter = '{{ request("status", "all") }}';
let currentSport = '{{ request("sport", "") }}';

function filterMatches(status) {
    currentFilter = status;
    window.location.href = `/?status=${status}&sport=${currentSport}`;
}

function filterSport(sportId) {
    currentSport = sportId;
    window.location.href = `/?status=${currentFilter}&sport=${sportId}`;
}

// Auto-refresh every 60 seconds for live updates
@if($hasLiveMatches)
setInterval(() => {
    fetch('/api/matches?status=live')
        .then(r => r.json())
        .then(data => {
            // Update live match scores without full page reload
            data.matches?.forEach(match => {
                const scoreA = document.getElementById(`score-a-${match.id}`);
                const scoreB = document.getElementById(`score-b-${match.id}`);
                if (scoreA) scoreA.textContent = match.score_a || '';
                if (scoreB) scoreB.textContent = match.score_b || '';
                // Update match minute for football
                const minute = document.getElementById(`minute-${match.id}`);
                if (minute && match.match_minute) minute.textContent = match.match_minute + "'";
            });
        })
        .catch(() => {});
}, 60000);
@endif
</script>
@endpush
@endsection
