@props(['item'])
@if($item->children->count() > 0)
<div class="dropdown-wrapper">
    <button class="dropdown-btn">
        {{ $item->title }}
        <svg style="width:0.75rem;height:0.75rem" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
    </button>
    <div class="dropdown-menu hidden">
        @foreach($item->children as $child)
        <a href="{{ $child->url }}" class="dropdown-item" {{ $child->open_in_new_tab ? 'target="_blank" rel="noopener"' : '' }}>
            {{ $child->title }}
        </a>
        @endforeach
    </div>
</div>
@else
<a href="{{ $item->url }}" class="nav-link {{ request()->url() === $item->url ? 'active' : '' }}" {{ $item->open_in_new_tab ? 'target="_blank" rel="noopener"' : '' }}>
    {{ $item->title }}
</a>
@endif
