<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\UserRole;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('pages.auth');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();

            // Check admin role
            $user = Auth::user();
            $isAdmin = UserRole::where('user_id', $user->id)->where('role', 'admin')->exists()
                || \App\Models\Profile::where('user_id', $user->id)->where('is_admin', true)->exists();

            if ($isAdmin) {
                return redirect()->intended('/admin')->with('success', 'Welcome back!');
            }

            return redirect('/')->with('success', 'Logged in successfully.');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/')->with('success', 'Logged out successfully.');
    }
}
