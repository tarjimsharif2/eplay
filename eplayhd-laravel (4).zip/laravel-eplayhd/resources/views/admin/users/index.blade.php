@extends('layouts.admin')
@section('title','Users')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Users</h1><button onclick="document.getElementById('add-user-modal').style.display='flex'" class="btn-primary-sm">+ New User</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($users as $user)
            <tr>
                <td style="font-weight:500">{{ $user->name }}</td>
                <td style="font-size:0.875rem;color:var(--muted)">{{ $user->email }}</td>
                <td><span class="badge {{ $user->roles->first()?->role === 'admin' ? 'badge-live-sm' : 'badge-upcoming-sm' }}">{{ $user->roles->first()?->role ?? 'viewer' }}</span></td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $user->created_at?->format('d M Y') }}</td>
                <td>
                    @if($user->id !== auth()->id())
                    <form method="POST" action="{{ route('admin.users.destroy', $user->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete user {{ $user->name }}?">Del</button></form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:2rem">No users.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem">{{ $users->links() }}</div>
</div>
<div id="add-user-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:440px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700">New User</h3><button onclick="document.getElementById('add-user-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.users.store') }}">@csrf
            <div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" class="form-input" required></div>
            <div class="form-group"><label class="form-label">Email *</label><input type="email" name="email" class="form-input" required></div>
            <div class="form-group"><label class="form-label">Password *</label><input type="password" name="password" class="form-input" required minlength="8"></div>
            <div class="form-group"><label class="form-label">Role</label>
                <select name="role" class="form-select">
                    @foreach(['admin','moderator','editor','viewer'] as $r)<option value="{{ $r }}">{{ ucfirst($r) }}</option>@endforeach
                </select></div>
            <div style="display:flex;gap:0.75rem;margin-top:1rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Create User</button><button type="button" onclick="document.getElementById('add-user-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@endsection
