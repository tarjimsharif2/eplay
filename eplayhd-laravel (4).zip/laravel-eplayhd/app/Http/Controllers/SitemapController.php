<?php
namespace App\Http\Controllers;
use App\Models\MatchModel;
use App\Models\Tournament;
use App\Models\Channel;
use App\Models\DynamicPage;
use App\Models\SiteSettings;
class SitemapController extends Controller
{
    public function show()
    {
        $settings = SiteSettings::first();
        $matches = bMatchModel::where('is_active', true)->whereNotNull('slug')->where('page_type','page')->orderBy('updated_at','desc')->get(['slug','updated_at']);
        $tournaments = Tournament::where('is_active', true)->whereNotNull('slug')->get(['slug','updated_at']);
        $channels = Channel::where('is_active', true)->whereNotNull('slug')->get(['slug','updated_at']);
        $pages = DynamicPage::where('is_active', true)->get(['slug','updated_at']);
        $content = view('pages.sitemap', compact('matches','tournaments','channels','pages','settings'))->render();
        return response($content, 200)->header('Content-Type', 'application/xml');
    }
    public function robots()
    {
        $settings = SiteSettings::first();
        $content = $settings?->robots_txt ?? "User-agent: *\nAllow: /\nSitemap: " . url('/sitemap.xml');
        return response($content, 200)->header('Content-Type', 'text/plain');
    }
}
