<?php

namespace App\Http\Controllers;

use App\Models\Channel;
use App\Models\SiteSettings;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ChannelController extends Controller
{
    public function index()
    {
        $channels = Channel::where('is_active', true)
            ->with('streamingServers')
            ->orderBy('display_order')
            ->get();

        $siteSettings = SiteSettings::first();

        return view('pages.channels', compact('channels', 'siteSettings'));
    }

    public function show(string $slug)
    {
        $channel = Channel::with('streamingServers')
            ->where('is_active', true)
            ->where(function($q) use ($slug) {
                $q->where('slug', $slug)->orWhere('id', $slug);
            })
            ->first();

        if (!$channel) abort(404);

        $siteSettings = SiteSettings::first();

        $seoTitle = $channel->seo_title
            ?? ($channel->name . ' Live Stream | ' . ($siteSettings?->site_name ?? 'ePlayHD'));
        $seoDescription = $channel->seo_description
            ?? ('Watch ' . $channel->name . ' live stream online for free.');
        $seoKeywords = $channel->seo_keywords ?? '';

        return view('pages.channel', compact('channel', 'seoTitle', 'seoDescription', 'seoKeywords', 'siteSettings'));
    }

    public function apiChannels(): JsonResponse
    {
        $channels = Channel::where('is_active', true)
            ->orderBy('display_order')
            ->get(['id', 'name', 'slug', 'logo_url', 'logo_background_color']);

        return response()->json(['channels' => $channels]);
    }
}
