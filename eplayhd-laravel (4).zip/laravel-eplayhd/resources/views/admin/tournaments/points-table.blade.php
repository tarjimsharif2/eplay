@extends('layouts.admin')
@section('title','Points Table')
@section('content')
<div class="admin-header">
    <div><a href="{{ route('admin.tournaments.index') }}" style="font-size:0.875rem;color:var(--muted)">← Back</a><h1 class="admin-page-title">Points Table: {{ $tournament->name }}</h1></div>
    <button onclick="document.getElementById('add-entry-modal').style.display='flex'" class="btn-primary-sm">+ Add Entry</button>
</div>
<div class="admin-card">
    <div style="overflow-x:auto;">
    <table class="admin-table">
        <thead><tr><th>Pos</th><th>Team</th><th>P</th><th>W</th><th>L</th><th>T</th><th>NR</th><th>Pts</th><th>NRR</th><th>Q/E</th><th></th></tr></thead>
        <tbody>
            @forelse($table as $entry)
            <tr>
                <td style="font-weight:700">{{ $entry->position }}</td>
                <td style="font-size:0.875rem;font-weight:500">{{ $entry->team?->name }}</td>
                <td>{{ $entry->played }}</td><td>{{ $entry->won }}</td><td>{{ $entry->lost }}</td><td>{{ $entry->tied }}</td><td>{{ $entry->no_result }}</td>
                <td style="font-weight:700;color:var(--primary)">{{ $entry->points }}</td>
                <td style="font-size:0.8rem">{{ $entry->net_run_rate }}</td>
                <td><span class="badge {{ $entry->qualified ? 'badge-completed-sm' : ($entry->eliminated ? 'badge-live-sm' : '') }}">{{ $entry->qualified ? 'Q' : ($entry->eliminated ? 'E' : '–') }}</span></td>
                <td>
                    <form method="POST" action="{{ route('admin.tournaments.points-table.destroy', [$tournament->id, $entry->id]) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete?">×</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="11" style="text-align:center;color:var(--muted);padding:2rem;">No entries.</td></tr>
            @endforelse
        </tbody>
    </table>
    </div>
</div>
<div id="add-entry-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:560px;max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700;">Add Points Table Entry</h3><button onclick="document.getElementById('add-entry-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.tournaments.points-table.store', $tournament->id) }}">@csrf
            <div class="form-group"><label class="form-label">Team *</label>
                <select name="team_id" class="form-select" required>
                    @foreach($teams as $t)<option value="{{ $t->id }}">{{ $t->name }}</option>@endforeach
                </select></div>
            <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:0.5rem;">
                @foreach(['played'=>'P','won'=>'W','lost'=>'L','tied'=>'T','no_result'=>'NR','points'=>'Pts','position'=>'Pos'] as $f=>$l)
                <div class="form-group"><label class="form-label" style="font-size:0.75rem">{{ $l }}</label><input type="number" name="{{ $f }}" class="form-input" style="padding:0.375rem 0.5rem;font-size:0.8rem" value="0" min="0"></div>
                @endforeach
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;">
                <div class="form-group"><label class="form-label">NRR</label><input type="number" name="net_run_rate" class="form-input" step="0.001" value="0.000"></div>
                <div style="display:flex;gap:1rem;align-items:center;padding-top:1.5rem">
                    <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.8rem;cursor:pointer"><input type="hidden" name="qualified" value="0"><input type="checkbox" name="qualified" class="form-checkbox" value="1">Qualified</label>
                    <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.8rem;cursor:pointer"><input type="hidden" name="eliminated" value="0"><input type="checkbox" name="eliminated" class="form-checkbox" value="1">Eliminated</label>
                </div>
            </div>
            <div style="display:flex;gap:0.75rem;margin-top:1rem;">
                <button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add Entry</button>
                <button type="button" onclick="document.getElementById('add-entry-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
