<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use App\Models\MatchModel;

class Tournament extends Model
{
    protected $table = 'tournaments';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'name', 'sport', 'season', 'logo_url', 'logo_background_color', 'slug',
        'is_active', 'show_in_menu', 'show_in_homepage', 'is_completed',
        'seo_title', 'seo_description', 'seo_keywords',
        'total_matches', 'start_date', 'end_date', 'description',
        'total_teams', 'total_venues', 'show_participating_teams',
        'participating_teams_position', 'custom_participating_teams', 'series_id',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'show_in_menu' => 'boolean',
        'show_in_homepage' => 'boolean',
        'is_completed' => 'boolean',
        'show_participating_teams' => 'boolean',
        'custom_participating_teams' => 'array',
        'start_date' => 'date',
        'end_date' => 'date',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($m) {
            $m->id = $m->id ?: (string) Str::uuid();
            if (!$m->slug) $m->slug = Str::slug($m->name . '-' . $m->season);
        });
    }

    public function matches(): HasMany { return $this->hasMany(MatchModel::class, 'tournament_id'); }
    public function pointsTable(): HasMany { return $this->hasMany(TournamentPointsTable::class, 'tournament_id')->orderBy('position'); }
    public function banners(): HasMany { return $this->hasMany(Banner::class, 'tournament_id'); }
}
