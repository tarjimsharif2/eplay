<?php

namespace App\Http\Controllers;

use App\Models\MatchModel;
use App\Models\Channel;
use App\Models\Tournament;
use App\Models\Sport;
use App\Models\Banner;
use App\Models\SiteSettings;
use Illuminate\Http\Request;
use Carbon\Carbon;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $settings = SiteSettings::first();
        $statusFilter = $request->get('status', 'all');
        $sportFilter = $request->get('sport');
        $completedDays = $settings?->homepage_completed_days ?? 3;

        // Base query with relationships
        $baseQuery = bMatchModel::with(['teamA', 'teamB', 'tournament', 'sport', 'innings'])
            ->where('is_active', true)
            ->orderBy('is_priority', 'desc');

        // Apply sport filter
        if ($sportFilter) {
            $baseQuery->where('sport_id', $sportFilter);
        }

        // Live Matches
        $liveQuery = clone $baseQuery;
        $liveMatches = $liveQuery->where('status', 'live')
            ->orderBy('updated_at', 'desc')
            ->get();

        // Upcoming Matches
        $upcomingQuery = clone $baseQuery;
        $upcomingMatches = $upcomingQuery->where('status', 'upcoming')
            ->orderByRaw("CASE WHEN match_start_time IS NOT NULL THEN match_start_time ELSE STR_TO_DATE(CONCAT(match_date, ' ', match_time), '%Y-%m-%d %H:%i') END ASC")
            ->get();

        // Completed Matches (last N days)
        $completedQuery = clone $baseQuery;
        $completedMatches = $completedQuery->where('status', 'completed')
            ->where(function($q) use ($completedDays) {
                $q->where('updated_at', '>=', Carbon::now()->subDays($completedDays))
                  ->orWhereNull('updated_at');
            })
            ->orderBy('updated_at', 'desc')
            ->take(20)
            ->get();

        // Apply status filter for display
        if ($statusFilter !== 'all') {
            $liveMatches = $statusFilter === 'live' ? $liveMatches : collect();
            $upcomingMatches = $statusFilter === 'upcoming' ? $upcomingMatches : collect();
            $completedMatches = $statusFilter === 'completed' ? $completedMatches : collect();
        }

        // Channels (limited for homepage)
        $channelLimit = $settings?->homepage_channels_limit ?? 6;
        $channels = Channel::where('is_active', true)
            ->orderBy('display_order')
            ->take($channelLimit)
            ->get();

        // Active Tournaments for the homepage
        $liveTournaments = Tournament::where('is_active', true)
            ->where('show_in_homepage', true)
            ->where('is_completed', false)
            ->orderBy('created_at', 'desc')
            ->take(6)
            ->get();

        // Sports for filter
        $sports = Sport::orderBy('display_order')->get();

        // Banners
        $banners = Banner::where('is_active', true)
            ->orderBy('display_order')
            ->with(['match', 'tournament'])
            ->get();

        $sliderDuration = ($settings?->slider_duration_seconds ?? 5) * 1000;
        $hasLiveMatches = $liveMatches->count() > 0;

        return view('pages.home', compact(
            'liveMatches', 'upcomingMatches', 'completedMatches',
            'channels', 'liveTournaments', 'sports', 'banners',
            'sliderDuration', 'hasLiveMatches', 'settings'
        ));
    }
}
