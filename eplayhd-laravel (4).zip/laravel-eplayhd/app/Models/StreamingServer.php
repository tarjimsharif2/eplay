<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;
use App\Models\MatchModel;

class StreamingServer extends Model
{
    protected $table = 'streaming_servers';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'match_id', 'server_name', 'server_url', 'server_type', 'player_type',
        'display_order', 'original_display_order', 'is_active', 'is_working',
        'not_working_reports', 'last_reported_at', 'drm_scheme', 'drm_license_url',
        'clearkey_key_id', 'clearkey_key', 'referer_value', 'origin_value',
        'user_agent', 'cookie_value', 'ad_block_enabled',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_working' => 'boolean',
        'ad_block_enabled' => 'boolean',
        'last_reported_at' => 'datetime',
    ];

    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }

    public function match(): BelongsTo { return $this->belongsTo(MatchModel::class, 'match_id'); }
}
