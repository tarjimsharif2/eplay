<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class ChannelStreamingServer extends Model {
    protected $table = 'channel_streaming_servers';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['channel_id','server_name','server_url','server_type','player_type','display_order','original_display_order','is_active','is_working','drm_scheme','drm_license_url','clearkey_key_id','clearkey_key','referer_value','origin_value','user_agent','cookie_value','ad_block_enabled'];
    protected $casts = ['is_active'=>'boolean','is_working'=>'boolean','ad_block_enabled'=>'boolean'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function channel() { return $this->belongsTo(Channel::class,'channel_id'); }
}
