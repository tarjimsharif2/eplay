<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\TournamentPointsTable;
use App\Models\Tournament;
use App\Models\Team;
use App\Models\MatchModel;
use Illuminate\Http\Request;

class PointsTableAdminController extends Controller
{
    public function index(string $matchId) {
        $match = bMatchModel::with('tournament')->findOrFail($matchId);
        $table = $match->tournament ? TournamentPointsTable::where('tournament_id',$match->tournament_id)->with('team')->orderBy('position')->get() : collect();
        $teams = Team::orderBy('name')->get();
        return view('admin.points-table.index', compact('match','table','teams'));
    }
    public function store(Request $request, string $matchId) {
        $match = bMatchModel::findOrFail($matchId);
        $v = $request->validate(['tournament_id'=>'required|exists:tournaments,id','team_id'=>'required|exists:teams,id','played'=>'nullable|integer','won'=>'nullable|integer','lost'=>'nullable|integer','tied'=>'nullable|integer','no_result'=>'nullable|integer','points'=>'nullable|integer','net_run_rate'=>'nullable|numeric','position'=>'nullable|integer','qualified'=>'boolean','eliminated'=>'boolean']);
        TournamentPointsTable::updateOrCreate(['tournament_id'=>$v['tournament_id'],'team_id'=>$v['team_id']], $v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Points table updated.');
    }
    public function update(Request $request, string $matchId, string $id) {
        TournamentPointsTable::findOrFail($id)->update($request->validate(['played'=>'nullable|integer','won'=>'nullable|integer','lost'=>'nullable|integer','tied'=>'nullable|integer','no_result'=>'nullable|integer','points'=>'nullable|integer','net_run_rate'=>'nullable|numeric','position'=>'nullable|integer','qualified'=>'boolean','eliminated'=>'boolean']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Updated.');
    }
    public function destroy(string $matchId, string $id) { TournamentPointsTable::findOrFail($id)->delete(); return back()->with('success','Entry deleted.'); }
    public function tournamentTable(string $id) {
        $tournament = Tournament::findOrFail($id);
        $table = TournamentPointsTable::where('tournament_id',$id)->with('team')->orderBy('position')->get();
        $teams = Team::orderBy('name')->get();
        return view('admin.tournaments.points-table', compact('tournament','table','teams'));
    }
    public function storeTournament(Request $request, string $id) {
        $v = $request->validate(['team_id'=>'required|exists:teams,id','played'=>'nullable|integer','won'=>'nullable|integer','lost'=>'nullable|integer','tied'=>'nullable|integer','no_result'=>'nullable|integer','points'=>'nullable|integer','net_run_rate'=>'nullable|numeric','position'=>'nullable|integer','qualified'=>'boolean','eliminated'=>'boolean']);
        $v['tournament_id'] = $id;
        TournamentPointsTable::updateOrCreate(['tournament_id'=>$id,'team_id'=>$v['team_id']], $v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Points table updated.');
    }
    public function updateTournament(Request $request, string $id, string $entryId) {
        TournamentPointsTable::where('tournament_id',$id)->findOrFail($entryId)->update($request->validate(['played'=>'nullable|integer','won'=>'nullable|integer','lost'=>'nullable|integer','tied'=>'nullable|integer','no_result'=>'nullable|integer','points'=>'nullable|integer','net_run_rate'=>'nullable|numeric','position'=>'nullable|integer','qualified'=>'boolean','eliminated'=>'boolean']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Updated.');
    }
    public function destroyTournament(string $id, string $entryId) { TournamentPointsTable::where('tournament_id',$id)->findOrFail($entryId)->delete(); return back()->with('success','Deleted.'); }
}
