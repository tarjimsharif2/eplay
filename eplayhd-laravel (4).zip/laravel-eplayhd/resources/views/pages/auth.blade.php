{{-- resources/views/pages/auth.blade.php --}}
@extends('layouts.app')
@section('title', 'Login - ' . ($siteSettings->site_name ?? 'ePlayHD'))
@section('content')
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            @if($siteSettings?->logo_url)
                <img src="{{ $siteSettings->logo_url }}" alt="{{ $siteSettings->site_name }}" class="w-16 h-16 mx-auto object-contain">
            @else
                <div class="logo-icon" style="width:4rem;height:4rem;margin:0 auto;border-radius:1rem;font-size:1.5rem">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:2rem;height:2rem">
                        <rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>
                    </svg>
                </div>
            @endif
        </div>
        <h1 class="auth-title">Welcome Back</h1>
        <p class="auth-subtitle">Sign in to {{ $siteSettings?->site_name ?? 'ePlayHD' }}</p>

        @if(session('error'))
        <div class="alert-error">{{ session('error') }}</div>
        @endif

        <form method="POST" action="{{ route('auth.login') }}">
            @csrf
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-input" value="{{ old('email') }}" required autocomplete="email" placeholder="admin@eplayhd.com">
                @error('email')<p class="error-msg">{{ $message }}</p>@enderror
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <input type="password" id="password" name="password" class="form-input" required autocomplete="current-password" placeholder="••••••••">
                @error('password')<p class="error-msg">{{ $message }}</p>@enderror
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;">
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer">
                    <input type="checkbox" name="remember" class="form-checkbox"> Remember me
                </label>
            </div>
            <button type="submit" class="btn-primary">Sign In</button>
        </form>
    </div>
</div>
@endsection
