<?php
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Auto-sync live match scores every minute
Schedule::command('matches:sync-scores')->everyMinute()->when(function () {
    return \App\Models\SiteSettings::first()?->api_cricket_enabled;
});
