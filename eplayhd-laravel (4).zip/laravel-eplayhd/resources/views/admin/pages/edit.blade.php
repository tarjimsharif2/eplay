@extends('layouts.admin')
@section('title','Edit Page')
@section('content')
<div class="admin-header"><a href="{{ route('admin.pages.index') }}" style="font-size:0.875rem;color:var(--muted)">← Back</a><h1 class="admin-page-title">Edit: {{ $page->title }}</h1></div>
<form method="POST" action="{{ route('admin.pages.update', $page->id) }}">
    @csrf @method('PUT')
    <div style="display:grid;grid-template-columns:1fr 280px;gap:1.5rem;">
        <div>
            <div class="admin-card"><div class="admin-card-header"><h2 class="admin-card-title">Content</h2></div>
            <div class="admin-card-body">
                <div class="form-group"><label class="form-label">Title *</label><input type="text" name="title" class="form-input" required value="{{ $page->title }}"></div>
                <div class="form-group"><label class="form-label">Slug *</label><input type="text" name="slug" class="form-input" required value="{{ $page->slug }}"></div>
                <div class="form-group"><label class="form-label">Content Type</label>
                    <select name="content_type" class="form-select">
                        @foreach(['html'=>'HTML','markdown'=>'Markdown','text'=>'Plain Text'] as $v=>$l)<option value="{{ $v }}" {{ ($page->content_type===$v?'selected':'') }}>{{ $l }}</option>@endforeach
                    </select></div>
                <div class="form-group"><label class="form-label">Content</label><textarea name="content" class="form-textarea" rows="15">{{ $page->content }}</textarea></div>
            </div></div>
            <div class="admin-card"><div class="admin-card-header"><h2 class="admin-card-title">SEO</h2></div>
            <div class="admin-card-body">
                <div class="form-group"><label class="form-label">SEO Title</label><input type="text" name="seo_title" class="form-input" value="{{ $page->seo_title }}"></div>
                <div class="form-group"><label class="form-label">SEO Description</label><textarea name="seo_description" class="form-textarea" rows="2">{{ $page->seo_description }}</textarea></div>
                <div class="form-group"><label class="form-label">Keywords</label><input type="text" name="seo_keywords" class="form-input" value="{{ $page->seo_keywords }}"></div>
                <div class="form-group"><label class="form-label">OG Image URL</label><input type="text" name="og_image_url" class="form-input" value="{{ $page->og_image_url }}"></div>
            </div></div>
        </div>
        <div>
            <div class="admin-card" style="position:sticky;top:1.5rem;"><div class="admin-card-header"><h2 class="admin-card-title">Settings</h2></div>
            <div class="admin-card-body" style="display:flex;flex-direction:column;gap:0.625rem;">
                @foreach([['is_active','Active'],['show_in_header','Show in Header'],['show_in_footer','Show in Footer']] as [$f,$l])
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="{{ $f }}" value="0"><input type="checkbox" name="{{ $f }}" class="form-checkbox" value="1" {{ ($page->$f?'checked':'') }}>{{ $l }}</label>
                @endforeach
                <div class="form-group" style="margin-top:0.5rem"><label class="form-label">Display Order</label><input type="number" name="display_order" class="form-input" value="{{ $page->display_order }}"></div>
                <button type="submit" class="btn-primary-sm" style="width:100%;justify-content:center;margin-top:0.75rem">Save Changes</button>
            </div></div>
        </div>
    </div>
</form>
@endsection
