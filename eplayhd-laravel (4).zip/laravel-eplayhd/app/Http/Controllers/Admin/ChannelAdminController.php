<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Channel;
use App\Models\ChannelStreamingServer;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ChannelAdminController extends Controller
{
    public function index() {
        $channels = Channel::withCount('streamingServers')->orderBy('display_order')->paginate(20);
        return view('admin.channels.index', compact('channels'));
    }
    public function store(Request $request) {
        $v = $request->validate(['name'=>'required|string|max:255','slug'=>'nullable|string|unique:channels,slug','description'=>'nullable|string','logo_url'=>'nullable|string','logo_background_color'=>'nullable|string|max:50','display_order'=>'nullable|integer','is_active'=>'boolean','seo_title'=>'nullable|string','seo_description'=>'nullable|string','seo_keywords'=>'nullable|string']);
        if (empty($v['slug'])) $v['slug'] = Str::slug($v['name']);
        Channel::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Channel created.');
    }
    public function edit(string $id) {
        $channel = Channel::with('streamingServers')->findOrFail($id);
        return view('admin.channels.edit', compact('channel'));
    }
    public function update(Request $request, string $id) {
        $ch = Channel::findOrFail($id);
        $v = $request->validate(['name'=>'required|string|max:255','slug'=>'nullable|string|unique:channels,slug,'.$id,'description'=>'nullable|string','logo_url'=>'nullable|string','logo_background_color'=>'nullable|string|max:50','display_order'=>'nullable|integer','is_active'=>'boolean','seo_title'=>'nullable|string','seo_description'=>'nullable|string','seo_keywords'=>'nullable|string']);
        $ch->update($v);
        return redirect()->route('admin.channels.edit',$id)->with('success','Channel updated.');
    }
    public function destroy(string $id) { Channel::findOrFail($id)->delete(); return redirect()->route('admin.channels.index')->with('success','Channel deleted.'); }
    public function addServer(Request $request, string $channelId) {
        Channel::findOrFail($channelId);
        $v = $request->validate(['server_name'=>'required|string|max:255','server_url'=>'required|string','server_type'=>'nullable|string','player_type'=>'nullable|string','display_order'=>'nullable|integer','is_active'=>'boolean','drm_scheme'=>'nullable|string','drm_license_url'=>'nullable|string','clearkey_key_id'=>'nullable|string','clearkey_key'=>'nullable|string','referer_value'=>'nullable|string','origin_value'=>'nullable|string','user_agent'=>'nullable|string','cookie_value'=>'nullable|string','ad_block_enabled'=>'boolean']);
        $v['channel_id'] = $channelId;
        ChannelStreamingServer::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Server added.');
    }
    public function updateServer(Request $request, string $channelId, string $id) {
        ChannelStreamingServer::where('channel_id',$channelId)->findOrFail($id)->update($request->validate(['server_name'=>'required|string|max:255','server_url'=>'required|string','server_type'=>'nullable|string','player_type'=>'nullable|string','display_order'=>'nullable|integer','is_active'=>'boolean','drm_scheme'=>'nullable|string','drm_license_url'=>'nullable|string','clearkey_key_id'=>'nullable|string','clearkey_key'=>'nullable|string','referer_value'=>'nullable|string','origin_value'=>'nullable|string','user_agent'=>'nullable|string','cookie_value'=>'nullable|string','ad_block_enabled'=>'boolean']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Server updated.');
    }
    public function destroyServer(string $channelId, string $id) { ChannelStreamingServer::where('channel_id',$channelId)->findOrFail($id)->delete(); return back()->with('success','Server deleted.'); }
}
