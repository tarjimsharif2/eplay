<!DOCTYPE html>
<html lang="en" class="{{ session('theme', 'light') }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    {{-- SEO Meta --}}
    <title>@yield('title', $siteSettings->site_title ?? 'ePlayHD - Live Sports Streaming')</title>
    <meta name="description" content="@yield('meta_description', $siteSettings->site_description ?? '')">
    <meta name="keywords" content="@yield('meta_keywords', $siteSettings->site_keywords ?? '')">

    {{-- Canonical --}}
    @if($siteSettings?->canonical_url)
    <link rel="canonical" href="{{ $siteSettings->canonical_url }}{{ request()->getPathInfo() }}">
    @else
    <link rel="canonical" href="{{ url()->current() }}">
    @endif

    {{-- OG Tags --}}
    <meta property="og:title" content="@yield('title', $siteSettings->site_title ?? 'ePlayHD')">
    <meta property="og:description" content="@yield('meta_description', $siteSettings->site_description ?? '')">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:image" content="@yield('og_image', $siteSettings->og_image_url ?? '')">
    @if($siteSettings?->facebook_app_id)
    <meta property="fb:app_id" content="{{ $siteSettings->facebook_app_id }}">
    @endif

    {{-- Twitter Card --}}
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="@yield('title', $siteSettings->site_title ?? 'ePlayHD')">
    <meta name="twitter:description" content="@yield('meta_description', $siteSettings->site_description ?? '')">
    @if($siteSettings?->twitter_handle)
    <meta name="twitter:site" content="{{ $siteSettings->twitter_handle }}">
    @endif

    {{-- Favicon --}}
    @if($siteSettings?->favicon_url)
    <link rel="icon" href="{{ $siteSettings->favicon_url }}" type="image/x-icon">
    @else
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    @endif

    {{-- Google Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    {{-- Main CSS --}}
    <link rel="stylesheet" href="/css/app.css">

    {{-- Google Analytics --}}
    @if($siteSettings?->google_analytics_id)
    <script async src="https://www.googletagmanager.com/gtag/js?id={{ $siteSettings->google_analytics_id }}"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '{{ $siteSettings->google_analytics_id }}');
    </script>
    @endif

    {{-- Google AdSense --}}
    @if($siteSettings?->ads_enabled && $siteSettings?->google_adsense_id)
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={{ $siteSettings->google_adsense_id }}" crossorigin="anonymous"></script>
    @endif

    {{-- Schema.org --}}
    @if($siteSettings?->schema_org_enabled)
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "{{ $siteSettings->site_name ?? 'ePlayHD' }}",
        "url": "{{ config('app.url') }}",
        "description": "{{ $siteSettings->site_description ?? '' }}"
    }
    </script>
    @endif

    {{-- Custom Header Code --}}
    @if($siteSettings?->custom_header_code)
    {!! $siteSettings->custom_header_code !!}
    @endif

    {{-- Header Ad Code --}}
    @if($siteSettings?->ads_enabled && $siteSettings?->header_ad_code)
    {!! $siteSettings->header_ad_code !!}
    @endif

    @stack('head')
</head>
<body class="{{ session('theme', 'light') }}">

{{-- Maintenance Mode Check - handled in middleware --}}

@include('components.header')

{{-- Popup Ad --}}
@if($siteSettings?->ads_enabled && $siteSettings?->popup_ad_code)
<div id="popup-ad-container">
    {!! $siteSettings->popup_ad_code !!}
</div>
@endif

@yield('content')

@include('components.footer')

{{-- Custom Footer Code --}}
@if($siteSettings?->custom_footer_code)
{!! $siteSettings->custom_footer_code !!}
@endif

{{-- Footer Ad Code --}}
@if($siteSettings?->ads_enabled && $siteSettings?->footer_ad_code)
{!! $siteSettings->footer_ad_code !!}
@endif

{{-- Main JS --}}
<script src="/js/app.js"></script>

@stack('scripts')
</body>
</html>
