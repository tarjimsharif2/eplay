<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class SavedStreamingServer extends Model {
    protected $table = 'saved_streaming_servers';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['server_name','server_url','server_type','player_type','drm_scheme','drm_license_url','clearkey_key_id','clearkey_key','referer_value','origin_value','user_agent','cookie_value','ad_block_enabled','notes','tags'];
    protected $casts = ['ad_block_enabled'=>'boolean','tags'=>'array'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
}
