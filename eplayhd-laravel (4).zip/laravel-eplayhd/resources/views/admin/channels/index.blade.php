@extends('layouts.admin')
@section('title','Channels')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Channels</h1><button onclick="document.getElementById('add-ch-modal').style.display='flex'" class="btn-primary-sm">+ New</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Logo</th><th>Name</th><th>Slug</th><th>Servers</th><th>Active</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($channels as $ch)
            <tr>
                <td>@if($ch->logo_url)<img src="{{ $ch->logo_url }}" style="width:2rem;height:2rem;object-fit:contain;border-radius:0.25rem">@endif</td>
                <td style="font-weight:500">{{ $ch->name }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $ch->slug }}</td>
                <td>{{ $ch->streaming_servers_count }}</td>
                <td><span class="badge {{ $ch->is_active ? 'badge-completed-sm' : 'badge-live-sm' }}">{{ $ch->is_active ? 'Active' : 'Off' }}</span></td>
                <td>
                    <a href="{{ route('admin.channels.edit', $ch->id) }}" class="btn-sm btn-edit">Manage</a>
                    <form method="POST" action="{{ route('admin.channels.destroy', $ch->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete channel?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">No channels.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem">{{ $channels->links() }}</div>
</div>
<div id="add-ch-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:500px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700">Add Channel</h3><button onclick="document.getElementById('add-ch-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.channels.store') }}">@csrf
            <div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" class="form-input" required></div>
            <div class="form-group"><label class="form-label">Slug</label><input type="text" name="slug" class="form-input" placeholder="auto-generated"></div>
            <div class="form-group"><label class="form-label">Logo URL</label><input type="text" name="logo_url" class="form-input"></div>
            <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="2"></textarea></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Display Order</label><input type="number" name="display_order" class="form-input" value="0"></div>
            </div>
            <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer;margin-bottom:1rem"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" class="form-checkbox" value="1" checked>Active</label>
            <div style="display:flex;gap:0.75rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Create</button><button type="button" onclick="document.getElementById('add-ch-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@endsection
