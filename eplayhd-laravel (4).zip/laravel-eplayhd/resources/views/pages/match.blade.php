@extends('layouts.app')

@section('title', $seoTitle ?? ($match->team_a?->name . ' vs ' . $match->team_b?->name . ' - Live Stream'))
@section('meta_description', $seoDescription ?? ($match->team_a?->name . ' vs ' . $match->team_b?->name . ' live stream, scores, playing XI'))
@section('meta_keywords', $seoKeywords ?? '')
@section('og_image', $match->tournament?->logo_url ?? $siteSettings?->og_image_url ?? '')

@section('content')
@php
    $teamA = $match->teamA;
    $teamB = $match->teamB;
    $sport = $match->sport;
    $tournament = $match->tournament;
    $sportName = $sport?->name ?? $tournament?->sport ?? 'Sport';
    $isCricket = str_contains(strtolower($sportName), 'cricket');
    $isFootball = str_contains(strtolower($sportName), 'football') || str_contains(strtolower($sportName), 'soccer');
    $adPositions = is_array($match->match_page_ad_positions ?? null) ? $match->match_page_ad_positions : json_decode($siteSettings?->match_page_ad_positions ?? '{}', true) ?? [];
    $showAd = fn($pos) => ($siteSettings?->ads_enabled && ($adPositions[$pos] ?? true));
@endphp

<div class="match-page">
    {{-- Sponsor Notices (top) --}}
    @foreach($sponsorNotices->where('position', 'top') as $notice)
    <div class="sponsor-notice" style="{{ $notice->background_color ? 'background:' . $notice->background_color : '' }}; {{ $notice->text_color ? 'color:' . $notice->text_color : '' }}">
        <strong>{{ $notice->title }}</strong>: {!! $notice->content !!}
    </div>
    @endforeach

    <div class="container">

        {{-- Match Header --}}
        <div class="match-header-section">
            @if($tournament)
            <div class="match-tournament-header">
                @if($tournament->logo_url)
                <img src="{{ $tournament->logo_url }}" alt="{{ $tournament->name }}" class="w-8 h-8 object-contain">
                @endif
                <span>{{ $tournament->name }} • {{ $tournament->season }}</span>
            </div>
            @endif

            @if($match->match_label)
            <div class="match-label-full">{{ $match->match_label }}</div>
            @endif

            <div class="match-teams-header">
                {{-- Team A --}}
                <div class="team-header-col">
                    <div class="team-logo-lg" style="{{ $teamA?->logo_background_color ? 'background:' . $teamA->logo_background_color : '' }}">
                        @if($teamA?->logo_url)
                            <img src="{{ $teamA->logo_url }}" alt="{{ $teamA->name }}">
                        @else
                            <span>{{ strtoupper(substr($teamA?->name ?? '?', 0, 2)) }}</span>
                        @endif
                    </div>
                    <h2 class="team-header-name">{{ $teamA?->name }}</h2>
                    @if($match->score_a)
                    <div class="team-header-score" id="score-a-detail">{{ $match->score_a }}</div>
                    @endif
                </div>

                <div class="vs-header">
                    <span class="vs-text">VS</span>
                    <span class="status-badge-lg {{ 'badge-' . $match->status }}">
                        @if($match->status === 'live' && !$match->is_stumps)
                        <span class="live-pulse"></span>
                        @endif
                        {{ $match->is_stumps ? 'STUMPS' : ucfirst($match->status) }}
                    </span>
                    @if($match->status === 'live' && $isFootball && $match->match_minute !== null)
                    <span class="football-live-minute" id="detail-minute">{{ $match->match_minute }}'</span>
                    @endif
                </div>

                {{-- Team B --}}
                <div class="team-header-col">
                    <div class="team-logo-lg" style="{{ $teamB?->logo_background_color ? 'background:' . $teamB->logo_background_color : '' }}">
                        @if($teamB?->logo_url)
                            <img src="{{ $teamB->logo_url }}" alt="{{ $teamB->name }}">
                        @else
                            <span>{{ strtoupper(substr($teamB?->name ?? '?', 0, 2)) }}</span>
                        @endif
                    </div>
                    <h2 class="team-header-name">{{ $teamB?->name }}</h2>
                    @if($match->score_b)
                    <div class="team-header-score" id="score-b-detail">{{ $match->score_b }}</div>
                    @endif
                </div>
            </div>

            {{-- Match Info --}}
            <div class="match-info-bar">
                @if($match->venue)
                <span><svg class="w-4 h-4 inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> {{ $match->venue }}</span>
                @endif
                @if($match->match_start_time)
                <span><svg class="w-4 h-4 inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg> {{ \Carbon\Carbon::parse($match->match_start_time)->format('D, d M Y • g:i A') }}</span>
                @endif
                <span class="sport-badge">{{ $sportName }}</span>
            </div>

            {{-- Toss --}}
            @if($isCricket && $match->toss_winner_id)
            @php $tossWinner = $match->toss_winner_id === $match->team_a_id ? $teamA : $teamB; @endphp
            <div class="toss-info-full">
                🪙 <strong>{{ $tossWinner?->name }}</strong> won the toss and elected to <strong>{{ $match->toss_decision === 'bat' ? 'Bat' : 'Bowl' }}</strong>
            </div>
            @endif

            {{-- Match Result --}}
            @if($match->status === 'completed' && $match->match_result)
            @php
                $resultTexts = [
                    'team_a_won' => $teamA?->name . ' Won' . ($match->result_margin ? ' by ' . $match->result_margin : ''),
                    'team_b_won' => $teamB?->name . ' Won' . ($match->result_margin ? ' by ' . $match->result_margin : ''),
                    'tied' => 'Match Tied',
                    'draw' => 'Match Drawn',
                    'no_result' => 'No Result',
                ];
            @endphp
            <div class="match-result-banner">
                {{ $resultTexts[$match->match_result] ?? '' }}
            </div>
            @endif
        </div>

        {{-- Before Player Ad --}}
        @if($showAd('before_player') && $siteSettings?->in_article_ad_code)
        <div class="ad-slot">{!! $siteSettings->in_article_ad_code !!}</div>
        @endif

        {{-- Sponsor Notices (before player) --}}
        @foreach($sponsorNotices->where('position', 'before_player') as $notice)
        <div class="sponsor-notice" style="{{ $notice->background_color ? 'background:' . $notice->background_color : '' }}">
            {!! $notice->content !!}
        </div>
        @endforeach

        <div class="match-page-grid">
            <div class="match-main-col">
                {{-- Streaming Servers --}}
                @if($servers->count() > 0)
                <div class="servers-section">
                    <div class="server-tabs">
                        @foreach($servers as $server)
                        <button class="server-tab {{ $loop->first ? 'active' : '' }}"
                            data-server-id="{{ $server->id }}"
                            data-url="{{ $server->server_url }}"
                            data-type="{{ $server->server_type }}"
                            data-player="{{ $server->player_type }}"
                            data-drm="{{ $server->drm_scheme }}"
                            data-license="{{ $server->drm_license_url }}"
                            data-working="{{ $server->is_working ? '1' : '0' }}"
                            onclick="switchServer(this)">
                            {{ $server->server_name }}
                            @if(!$server->is_working)
                            <span class="server-broken">⚠</span>
                            @endif
                        </button>
                        @endforeach
                    </div>

                    {{-- Video Player --}}
                    <div class="player-container" id="player-container">
                        @include('components.video-player', ['server' => $servers->first()])
                    </div>

                    {{-- Server Report Buttons --}}
                    <div class="server-actions">
                        <button class="btn-report-broken" onclick="reportNotWorking()">
                            <svg class="w-4 h-4 inline mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                            Report Not Working
                        </button>
                        <button class="btn-report-working" onclick="reportWorking()">
                            <svg class="w-4 h-4 inline mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg>
                            Working
                        </button>
                    </div>
                </div>
                @else
                <div class="no-servers">
                    <svg class="w-16 h-16 text-muted mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    <p>No streaming servers available for this match.</p>
                </div>
                @endif

                {{-- After Player Ad --}}
                @if($showAd('after_player') && $siteSettings?->in_article_ad_code)
                <div class="ad-slot">{!! $siteSettings->in_article_ad_code !!}</div>
                @endif

                {{-- Cricket Live Score (API) --}}
                @if($isCricket && $match->api_score_enabled && $apiScore)
                <div class="live-score-section">
                    <h3 class="section-title">
                        <span class="live-badge">LIVE</span> Cricket Score
                    </h3>
                    <div class="api-scorecard">
                        <div class="scorecard-teams">
                            <div class="scorecard-team">
                                <span class="sc-team-name">{{ $apiScore->home_team }}</span>
                                <span class="sc-score">{{ $apiScore->home_score }}</span>
                                @if($apiScore->home_overs)<span class="sc-overs">({{ $apiScore->home_overs }})</span>@endif
                            </div>
                            <div class="scorecard-team">
                                <span class="sc-team-name">{{ $apiScore->away_team }}</span>
                                <span class="sc-score">{{ $apiScore->away_score }}</span>
                                @if($apiScore->away_overs)<span class="sc-overs">({{ $apiScore->away_overs }})</span>@endif
                            </div>
                        </div>
                        @if($apiScore->status_info)
                        <p class="score-status">{{ $apiScore->status_info }}</p>
                        @endif
                        @if($apiScore->batsmen)
                        @php $batsmen = is_array($apiScore->batsmen) ? $apiScore->batsmen : json_decode($apiScore->batsmen, true); @endphp
                        @if($batsmen)
                        <div class="batsmen-table">
                            <table>
                                <thead><tr><th>Batsman</th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>SR</th></tr></thead>
                                <tbody>
                                    @foreach($batsmen as $b)
                                    <tr {{ isset($b['on_strike']) && $b['on_strike'] ? 'class=on-strike' : '' }}>
                                        <td>{{ $b['name'] ?? '' }} {{ isset($b['on_strike']) && $b['on_strike'] ? '●' : '' }}</td>
                                        <td>{{ $b['runs'] ?? 0 }}</td>
                                        <td>{{ $b['balls'] ?? 0 }}</td>
                                        <td>{{ $b['fours'] ?? 0 }}</td>
                                        <td>{{ $b['sixes'] ?? 0 }}</td>
                                        <td>{{ $b['strike_rate'] ?? '-' }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endif
                        @endif
                        @if($apiScore->bowlers)
                        @php $bowlers = is_array($apiScore->bowlers) ? $apiScore->bowlers : json_decode($apiScore->bowlers, true); @endphp
                        @if($bowlers)
                        <div class="bowlers-table">
                            <table>
                                <thead><tr><th>Bowler</th><th>O</th><th>M</th><th>R</th><th>W</th><th>Eco</th></tr></thead>
                                <tbody>
                                    @foreach($bowlers as $b)
                                    <tr>
                                        <td>{{ $b['name'] ?? '' }}</td>
                                        <td>{{ $b['overs'] ?? 0 }}</td>
                                        <td>{{ $b['maidens'] ?? 0 }}</td>
                                        <td>{{ $b['runs'] ?? 0 }}</td>
                                        <td>{{ $b['wickets'] ?? 0 }}</td>
                                        <td>{{ $b['economy'] ?? '-' }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @endif
                        @endif
                    </div>
                </div>
                @endif

                {{-- Manual Scorecard (Innings) --}}
                @if($isCricket && $innings->count() > 0)
                <div class="innings-section">
                    <h3 class="section-title">Scorecard</h3>
                    @foreach($innings->sortBy('innings_number') as $inn)
                    @php
                        $battingTeam = $inn->batting_team_id === $match->team_a_id ? $teamA : $teamB;
                    @endphp
                    <div class="innings-card {{ $inn->is_current ? 'current' : '' }}">
                        <div class="innings-header">
                            <span class="innings-num">{{ $inn->innings_number === 1 ? '1st' : '2nd' }} Innings</span>
                            <span class="innings-batting">{{ $battingTeam?->name }}</span>
                            @if($inn->is_current)<span class="innings-live">Batting</span>@endif
                        </div>
                        <div class="innings-score-display">
                            <span class="innings-main-score">{{ $inn->runs }}/{{ $inn->wickets }}</span>
                            <span class="innings-overs">({{ number_format($inn->overs, 1) }} ov)</span>
                            @if($inn->declared)<span class="innings-d-label">d</span>@endif
                            @if($inn->extras > 0)<span class="innings-extras">Extras: {{ $inn->extras }}</span>@endif
                        </div>
                    </div>
                    @endforeach
                </div>
                @endif

                {{-- Football Match Details --}}
                @if($isFootball)
                <div class="football-details">
                    @if($match->score_a !== null || $match->score_b !== null)
                    <div class="football-scoreboard">
                        <div class="football-score-full">
                            <div class="team-score-block">
                                <div class="team-logo-sm" style="{{ $teamA?->logo_background_color ? 'background:' . $teamA->logo_background_color : '' }}">
                                    @if($teamA?->logo_url)<img src="{{ $teamA->logo_url }}" alt="">@else<span>{{ substr($teamA?->name??'?',0,2) }}</span>@endif
                                </div>
                                <span class="team-name-xs">{{ $teamA?->name }}</span>
                                <span class="football-score-xl">{{ $match->score_a ?? '0' }}</span>
                            </div>
                            <div class="score-vs">-</div>
                            <div class="team-score-block">
                                <span class="football-score-xl">{{ $match->score_b ?? '0' }}</span>
                                <span class="team-name-xs">{{ $teamB?->name }}</span>
                                <div class="team-logo-sm" style="{{ $teamB?->logo_background_color ? 'background:' . $teamB->logo_background_color : '' }}">
                                    @if($teamB?->logo_url)<img src="{{ $teamB->logo_url }}" alt="">@else<span>{{ substr($teamB?->name??'?',0,2) }}</span>@endif
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif

                    {{-- Substitutions --}}
                    @if($substitutions->count() > 0)
                    <div class="substitutions">
                        <h4 class="sub-title">Substitutions</h4>
                        @foreach($substitutions as $sub)
                        @php $subTeam = $sub->team_id === $match->team_a_id ? $teamA : $teamB; @endphp
                        <div class="sub-row">
                            <span class="sub-team">{{ $subTeam?->name }}</span>
                            <span class="sub-in">↑ {{ $sub->player_in }}</span>
                            <span class="sub-out">↓ {{ $sub->player_out }}</span>
                            <span class="sub-minute">{{ $sub->minute }}'</span>
                        </div>
                        @endforeach
                    </div>
                    @endif
                </div>
                @endif

                {{-- After Score Ad --}}
                @if($showAd('after_score') && $siteSettings?->in_article_ad_code)
                <div class="ad-slot">{!! $siteSettings->in_article_ad_code !!}</div>
                @endif

                {{-- Playing XI --}}
                @if($match->show_playing_xi && $playingXI->count() > 0)
                <div class="playing-xi-section">
                    <h3 class="section-title">Playing XI</h3>
                    <div class="playing-xi-grid">
                        {{-- Team A XI --}}
                        <div class="xi-team">
                            <div class="xi-team-header">
                                <div class="team-logo-sm" style="{{ $teamA?->logo_background_color ? 'background:' . $teamA->logo_background_color : '' }}">
                                    @if($teamA?->logo_url)<img src="{{ $teamA->logo_url }}" alt="">@else<span>{{ substr($teamA?->name??'?',0,2) }}</span>@endif
                                </div>
                                <h4>{{ $teamA?->name }}</h4>
                            </div>
                            @foreach($playingXI->where('team_id', $match->team_a_id)->sortBy('batting_order') as $player)
                            @unless($player->is_bench)
                            <div class="player-row">
                                @if($player->player_image)
                                <img src="{{ $player->player_image }}" alt="{{ $player->player_name }}" class="player-avatar">
                                @else
                                <div class="player-avatar-placeholder">{{ strtoupper(substr($player->player_name, 0, 1)) }}</div>
                                @endif
                                <div class="player-info">
                                    <span class="player-name">
                                        {{ $player->player_name }}
                                        @if($player->is_captain) <span class="badge-c">(c)</span> @endif
                                        @if($player->is_vice_captain) <span class="badge-vc">(vc)</span> @endif
                                        @if($player->is_wicket_keeper) <span class="badge-wk">(wk)</span> @endif
                                    </span>
                                    @if($player->player_role)
                                    <span class="player-role">{{ $player->player_role }}</span>
                                    @endif
                                </div>
                            </div>
                            @endunless
                            @endforeach
                        </div>

                        {{-- Team B XI --}}
                        <div class="xi-team">
                            <div class="xi-team-header">
                                <div class="team-logo-sm" style="{{ $teamB?->logo_background_color ? 'background:' . $teamB->logo_background_color : '' }}">
                                    @if($teamB?->logo_url)<img src="{{ $teamB->logo_url }}" alt="">@else<span>{{ substr($teamB?->name??'?',0,2) }}</span>@endif
                                </div>
                                <h4>{{ $teamB?->name }}</h4>
                            </div>
                            @foreach($playingXI->where('team_id', $match->team_b_id)->sortBy('batting_order') as $player)
                            @unless($player->is_bench)
                            <div class="player-row">
                                @if($player->player_image)
                                <img src="{{ $player->player_image }}" alt="{{ $player->player_name }}" class="player-avatar">
                                @else
                                <div class="player-avatar-placeholder">{{ strtoupper(substr($player->player_name, 0, 1)) }}</div>
                                @endif
                                <div class="player-info">
                                    <span class="player-name">
                                        {{ $player->player_name }}
                                        @if($player->is_captain) <span class="badge-c">(c)</span> @endif
                                        @if($player->is_vice_captain) <span class="badge-vc">(vc)</span> @endif
                                        @if($player->is_wicket_keeper) <span class="badge-wk">(wk)</span> @endif
                                    </span>
                                    @if($player->player_role)
                                    <span class="player-role">{{ $player->player_role }}</span>
                                    @endif
                                </div>
                            </div>
                            @endunless
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif

                {{-- Points Table --}}
                @if($pointsTable->count() > 0)
                @include('components.points-table', ['pointsTable' => $pointsTable, 'tournament' => $tournament])
                @endif
            </div>

            {{-- Sidebar --}}
            <div class="match-sidebar">
                @if($showAd('sidebar') && $siteSettings?->sidebar_ad_code)
                <div class="ad-slot sidebar-ad">{!! $siteSettings->sidebar_ad_code !!}</div>
                @endif

                {{-- Sponsor Notices (sidebar) --}}
                @foreach($sponsorNotices->where('position', 'sidebar') as $notice)
                <div class="sponsor-notice-sidebar" style="{{ $notice->background_color ? 'background:' . $notice->background_color : '' }}">
                    <strong>{{ $notice->title }}</strong>
                    <div>{!! $notice->content !!}</div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
const matchId = '{{ $match->id }}';
let currentServerId = '{{ $servers->first()?->id ?? '' }}';

function switchServer(btn) {
    document.querySelectorAll('.server-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    currentServerId = btn.dataset.serverId;
    const container = document.getElementById('player-container');
    const url = btn.dataset.url;
    const type = btn.dataset.type;
    const player = btn.dataset.player;
    loadPlayer(container, url, type, player);
}

function loadPlayer(container, url, type, playerType) {
    let html = '';
    if (playerType === 'iframe' || type === 'iframe') {
        html = `<iframe src="${url}" allowfullscreen class="video-iframe" allow="autoplay; encrypted-media" scrolling="no" frameborder="0"></iframe>`;
    } else if (type === 'youtube' || url.includes('youtube.com') || url.includes('youtu.be')) {
        const videoId = url.match(/(?:v=|youtu\.be\/)([^&\?]+)/)?.[1] ?? '';
        html = `<iframe src="https://www.youtube.com/embed/${videoId}?autoplay=1" allowfullscreen class="video-iframe" allow="autoplay; encrypted-media" frameborder="0"></iframe>`;
    } else {
        html = `<div class="hls-player-wrapper" data-url="${url}" data-type="${type}"></div>`;
        container.innerHTML = html;
        loadHLSPlayer(container.querySelector('.hls-player-wrapper'));
        return;
    }
    container.innerHTML = html;
}

function loadHLSPlayer(wrapper) {
    const url = wrapper.dataset.url;
    const video = document.createElement('video');
    video.className = 'hls-video';
    video.controls = true;
    video.autoplay = true;
    video.playsInline = true;
    wrapper.appendChild(video);

    if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = url;
    } else if (window.Hls) {
        const hls = new Hls();
        hls.loadSource(url);
        hls.attachMedia(video);
    } else {
        video.src = url;
    }
}

function reportNotWorking() {
    if (!currentServerId) return;
    fetch(`/api/match/${matchId}/server/${currentServerId}/not-working`, {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content, 'Content-Type': 'application/json' }
    }).then(() => {
        showToast('Server reported as not working. Thank you!', 'info');
    });
}

function reportWorking() {
    if (!currentServerId) return;
    fetch(`/api/match/${matchId}/server/${currentServerId}/working`, {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content, 'Content-Type': 'application/json' }
    }).then(() => {
        showToast('Thanks for the feedback!', 'success');
    });
}

function showToast(msg, type) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// Auto-refresh match score
@if($match->status === 'live')
setInterval(() => {
    fetch(`/api/match/${matchId}/score`)
        .then(r => r.json())
        .then(data => {
            if (data.score_a) {
                const scoreA = document.getElementById('score-a-detail');
                if (scoreA) scoreA.textContent = data.score_a;
            }
            if (data.score_b) {
                const scoreB = document.getElementById('score-b-detail');
                if (scoreB) scoreB.textContent = data.score_b;
            }
            if (data.match_minute) {
                const min = document.getElementById('detail-minute');
                if (min) min.textContent = data.match_minute + "'";
            }
        });
}, 30000);
@endif
</script>
@endpush
@endsection
