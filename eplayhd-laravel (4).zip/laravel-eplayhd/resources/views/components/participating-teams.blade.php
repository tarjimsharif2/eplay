<div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.25rem;margin-bottom:1.5rem;">
    <h2 style="font-size:1rem;font-weight:700;margin-bottom:1rem;">Participating Teams</h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:0.75rem;">
        @foreach($teams as $team)
        @php $teamName = is_array($team) ? ($team['name'] ?? '') : ($team->name ?? ''); $teamLogo = is_array($team) ? ($team['logo_url'] ?? '') : ($team->logo_url ?? ''); $teamShort = is_array($team) ? ($team['short_name'] ?? substr($teamName,0,3)) : ($team->short_name ?? substr($teamName,0,3)); @endphp
        <div style="display:flex;flex-direction:column;align-items:center;gap:0.375rem;text-align:center;">
            <div style="width:3rem;height:3rem;border-radius:0.5rem;border:1px solid var(--border);padding:0.25rem;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                @if($teamLogo)
                    <img src="{{ $teamLogo }}" alt="{{ $teamName }}" style="width:100%;height:100%;object-fit:contain">
                @else
                    <span style="font-size:0.75rem;font-weight:700;color:var(--primary)">{{ strtoupper(substr($teamShort,0,3)) }}</span>
                @endif
            </div>
            <span style="font-size:0.7rem;font-weight:500;line-height:1.2">{{ $teamShort }}</span>
        </div>
        @endforeach
    </div>
</div>
