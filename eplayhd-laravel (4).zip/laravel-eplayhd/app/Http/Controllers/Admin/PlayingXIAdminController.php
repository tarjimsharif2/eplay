<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\MatchPlayingXI;
use App\Models\MatchModel;
use Illuminate\Http\Request;

class PlayingXIAdminController extends Controller
{
    public function index(string $matchId) {
        $match = bMatchModel::with(['teamA','teamB','playingXI.team'])->findOrFail($matchId);
        return view('admin.matches.playing-xi', compact('match'));
    }
    public function store(Request $request, string $matchId) {
        bMatchModel::findOrFail($matchId);
        $v = $request->validate(['team_id'=>'required|exists:teams,id','player_name'=>'required|string|max:255','player_role'=>'nullable|string|max:100','player_image'=>'nullable|string','batting_order'=>'nullable|integer','is_captain'=>'boolean','is_vice_captain'=>'boolean','is_wicket_keeper'=>'boolean','is_bench'=>'boolean','change_status'=>'nullable|string|max:100']);
        $v['match_id'] = $matchId;
        MatchPlayingXI::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Player added.');
    }
    public function update(Request $request, string $matchId, string $id) {
        MatchPlayingXI::where('match_id',$matchId)->findOrFail($id)->update($request->validate(['player_name'=>'required|string|max:255','player_role'=>'nullable|string|max:100','player_image'=>'nullable|string','batting_order'=>'nullable|integer','is_captain'=>'boolean','is_vice_captain'=>'boolean','is_wicket_keeper'=>'boolean','is_bench'=>'boolean','change_status'=>'nullable|string|max:100']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Player updated.');
    }
    public function destroy(string $matchId, string $id) { MatchPlayingXI::where('match_id',$matchId)->findOrFail($id)->delete(); return back()->with('success','Player removed.'); }
}
