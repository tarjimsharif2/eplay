<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MatchModel;
use App\Models\Team;
use App\Models\Tournament;
use App\Models\Sport;
use App\Models\StreamingServer;
use App\Models\SavedStreamingServer;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;
use Carbon\Carbon;

class MatchAdminController extends Controller
{
    public function index(Request $request)
    {
        $query = bMatchModel::with(['teamA', 'teamB', 'tournament', 'sport'])
            ->orderBy('created_at', 'desc');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('sport_id')) {
            $query->where('sport_id', $request->sport_id);
        }
        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('teamA', fn($q) => $q->where('name', 'like', "%$search%"))
                ->orWhereHas('teamB', fn($q) => $q->where('name', 'like', "%$search%"));
        }

        $matches = $query->paginate(20);
        $sports = Sport::orderBy('display_order')->get();

        return view('admin.matches.index', compact('matches', 'sports'));
    }

    public function create()
    {
        $teams = Team::orderBy('name')->get();
        $tournaments = Tournament::where('is_active', true)->orderBy('name')->get();
        $sports = Sport::orderBy('display_order')->get();
        $savedServers = SavedStreamingServer::orderBy('server_name')->get();

        return view('admin.matches.create', compact('teams', 'tournaments', 'sports', 'savedServers'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'team_a_id' => 'required|exists:teams,id',
            'team_b_id' => 'required|exists:teams,id|different:team_a_id',
            'match_date' => 'required|string',
            'match_time' => 'required|string',
            'status' => 'required|in:upcoming,live,completed,abandoned,postponed',
            'tournament_id' => 'nullable|exists:tournaments,id',
            'sport_id' => 'nullable|exists:sports,id',
            'venue' => 'nullable|string|max:500',
            'match_number' => 'nullable|string|max:100',
            'match_format' => 'nullable|string|max:50',
            'match_label' => 'nullable|string|max:255',
            'page_type' => 'nullable|in:page,link',
            'match_link' => 'nullable|url',
            'slug' => 'nullable|string|unique:matches,slug',
            'is_priority' => 'boolean',
            'is_active' => 'boolean',
            'show_playing_xi' => 'boolean',
            'seo_title' => 'nullable|string|max:500',
            'seo_description' => 'nullable|string',
            'seo_keywords' => 'nullable|string',
        ]);

        // Generate slug if not provided
        if (empty($validated['slug'])) {
            $teamA = Team::find($validated['team_a_id']);
            $teamB = Team::find($validated['team_b_id']);
            $slug = Str::slug($teamA->name . '-vs-' . $teamB->name . '-' . $validated['match_date']);
            // Ensure unique
            $originalSlug = $slug;
            $i = 1;
            while (bMatchModel::where('slug', $slug)->exists()) {
                $slug = $originalSlug . '-' . $i++;
            }
            $validated['slug'] = $slug;
        }

        // Parse start time
        if ($request->filled('match_start_time')) {
            $validated['match_start_time'] = Carbon::parse($request->match_start_time);
        }

        $match = bMatchModel::create($validated);

        // Handle streaming servers if provided
        if ($request->has('servers')) {
            foreach ($request->servers as $serverData) {
                StreamingServer::create(array_merge($serverData, ['match_id' => $match->id]));
            }
        }

        // Clear cache
        cache()->forget('site_settings');

        return redirect()->route('admin.matches.show', $match->id)
            ->with('success', 'Match created successfully!');
    }

    public function show(string $id)
    {
        $match = bMatchModel::with([
            'teamA', 'teamB', 'tournament', 'sport',
            'streamingServers', 'innings.battingTeam', 'playingXI.team',
            'substitutions.team', 'sponsorNotices'
        ])->findOrFail($id);

        $savedServers = SavedStreamingServer::orderBy('server_name')->get();
        $teams = Team::orderBy('name')->get();

        return view('admin.matches.show', compact('match', 'savedServers', 'teams'));
    }

    public function edit(string $id)
    {
        $match = bMatchModel::with(['streamingServers'])->findOrFail($id);
        $teams = Team::orderBy('name')->get();
        $tournaments = Tournament::where('is_active', true)->orderBy('name')->get();
        $sports = Sport::orderBy('display_order')->get();

        return view('admin.matches.edit', compact('match', 'teams', 'tournaments', 'sports'));
    }

    public function update(Request $request, string $id)
    {
        $match = bMatchModel::findOrFail($id);

        $validated = $request->validate([
            'team_a_id' => 'required|exists:teams,id',
            'team_b_id' => 'required|exists:teams,id',
            'match_date' => 'required|string',
            'match_time' => 'required|string',
            'status' => 'required|in:upcoming,live,completed,abandoned,postponed',
            'tournament_id' => 'nullable|exists:tournaments,id',
            'sport_id' => 'nullable|exists:sports,id',
            'venue' => 'nullable|string|max:500',
            'match_number' => 'nullable|string|max:100',
            'match_format' => 'nullable|string|max:50',
            'match_label' => 'nullable|string|max:255',
            'page_type' => 'nullable|in:page,link',
            'match_link' => 'nullable',
            'slug' => 'nullable|string|unique:matches,slug,' . $id,
            'score_a' => 'nullable|string|max:200',
            'score_b' => 'nullable|string|max:200',
            'match_result' => 'nullable|in:team_a_won,team_b_won,tied,draw,no_result',
            'result_margin' => 'nullable|string|max:255',
            'match_minute' => 'nullable|integer',
            'test_day' => 'nullable|integer',
            'is_priority' => 'boolean',
            'is_active' => 'boolean',
            'is_stumps' => 'boolean',
            'api_score_enabled' => 'boolean',
            'auto_sync_enabled' => 'boolean',
            'show_playing_xi' => 'boolean',
            'manual_status_override' => 'boolean',
            'cricapi_match_id' => 'nullable|string',
            'cricbuzz_match_id' => 'nullable|string',
            'toss_winner_id' => 'nullable|exists:teams,id',
            'toss_decision' => 'nullable|in:bat,bowl',
            'seo_title' => 'nullable|string|max:500',
            'seo_description' => 'nullable|string',
            'seo_keywords' => 'nullable|string',
        ]);

        if ($request->filled('match_start_time')) {
            $validated['match_start_time'] = Carbon::parse($request->match_start_time);
        }
        if ($request->filled('match_end_time')) {
            $validated['match_end_time'] = Carbon::parse($request->match_end_time);
        }

        // Handle goals JSON
        if ($request->filled('goals_team_a_json')) {
            $validated['goals_team_a'] = json_decode($request->goals_team_a_json, true);
        }
        if ($request->filled('goals_team_b_json')) {
            $validated['goals_team_b'] = json_decode($request->goals_team_b_json, true);
        }

        $match->update($validated);

        // Clear relevant caches
        cache()->forget('site_settings');

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'match' => $match->fresh()]);
        }

        return redirect()->route('admin.matches.show', $match->id)
            ->with('success', 'Match updated successfully!');
    }

    public function destroy(string $id)
    {
        bMatchModel::findOrFail($id)->delete();
        return redirect()->route('admin.matches.index')->with('success', 'Match deleted.');
    }

    public function updateStatus(Request $request, string $id)
    {
        $match = bMatchModel::findOrFail($id);
        $request->validate(['status' => 'required|in:upcoming,live,completed,abandoned,postponed']);
        $match->update(['status' => $request->status]);
        return response()->json(['success' => true]);
    }

    public function updateScore(Request $request, string $id)
    {
        $match = bMatchModel::findOrFail($id);
        $match->update([
            'score_a' => $request->score_a,
            'score_b' => $request->score_b,
            'match_minute' => $request->match_minute,
        ]);
        return response()->json(['success' => true]);
    }

    public function syncScore(Request $request, string $id): JsonResponse
    {
        $match = bMatchModel::findOrFail($id);

        // Trigger API score sync (via job/service)
        try {
            $service = app(\App\Services\CricketApiService::class);
            $result = $service->syncMatchScore($match);
            return response()->json(['success' => true, 'data' => $result]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function apiIndex(Request $request): JsonResponse
    {
        $matches = bMatchModel::with(['teamA', 'teamB', 'tournament'])
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return response()->json($matches);
    }
}
