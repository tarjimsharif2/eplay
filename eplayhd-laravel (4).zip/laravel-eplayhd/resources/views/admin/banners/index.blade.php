@extends('layouts.admin')
@section('title','Banners')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Banners</h1><button onclick="document.getElementById('add-banner-modal').style.display='flex'" class="btn-primary-sm">+ Add</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Image</th><th>Title</th><th>Type</th><th>Order</th><th>Active</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($banners as $b)
            <tr>
                <td><img src="{{ $b->image_url }}" style="width:4rem;height:2.5rem;object-fit:cover;border-radius:0.25rem;border:1px solid var(--border)"></td>
                <td style="font-size:0.875rem;font-weight:500">{{ Str::limit($b->title,40) }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $b->banner_type }} / {{ $b->badge_type }}</td>
                <td>{{ $b->display_order }}</td>
                <td><span class="badge {{ $b->is_active ? 'badge-completed-sm' : '' }}" style="{{ !$b->is_active ? 'color:var(--muted)' : '' }}">{{ $b->is_active ? 'Yes' : 'No' }}</span></td>
                <td>
                    <form method="POST" action="{{ route('admin.banners.destroy', $b->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete banner?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">No banners.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div id="add-banner-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:550px;max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700">Add Banner</h3><button onclick="document.getElementById('add-banner-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.banners.store') }}">@csrf
            <div class="form-group"><label class="form-label">Title *</label><input type="text" name="title" class="form-input" required></div>
            <div class="form-group"><label class="form-label">Subtitle</label><input type="text" name="subtitle" class="form-input"></div>
            <div class="form-group"><label class="form-label">Image URL *</label><input type="text" name="image_url" class="form-input" required placeholder="https://…"></div>
            <div class="form-group"><label class="form-label">Link URL</label><input type="text" name="link_url" class="form-input" placeholder="https://…"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Type</label><select name="banner_type" class="form-select"><option value="custom">Custom</option><option value="match">Match</option><option value="tournament">Tournament</option></select></div>
                <div class="form-group"><label class="form-label">Badge</label><select name="badge_type" class="form-select"><option value="none">None</option><option value="live">Live</option><option value="upcoming">Upcoming</option><option value="watch_now">Watch Now</option></select></div>
                <div class="form-group"><label class="form-label">Order</label><input type="number" name="display_order" class="form-input" value="1"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Match (optional)</label><select name="match_id" class="form-select"><option value="">None</option>@foreach($matches as $m)<option value="{{ $m->id }}">{{ $m->teamA?->short_name }} vs {{ $m->teamB?->short_name }}</option>@endforeach</select></div>
                <div class="form-group"><label class="form-label">Tournament (optional)</label><select name="tournament_id" class="form-select"><option value="">None</option>@foreach($tournaments as $t)<option value="{{ $t->id }}">{{ $t->name }}</option>@endforeach</select></div>
            </div>
            <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer;margin-bottom:1rem"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" class="form-checkbox" value="1" checked>Active</label>
            <div style="display:flex;gap:0.75rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add Banner</button><button type="button" onclick="document.getElementById('add-banner-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@endsection
