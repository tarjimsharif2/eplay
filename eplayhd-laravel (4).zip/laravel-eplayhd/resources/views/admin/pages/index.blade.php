@extends('layouts.admin')
@section('title','Pages')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Pages</h1><a href="{{ route('admin.pages.create') }}" class="btn-primary-sm">+ New</a></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Title</th><th>Slug</th><th>Header</th><th>Footer</th><th>Active</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($pages as $p)
            <tr>
                <td style="font-weight:500">{{ $p->title }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $p->slug }}</td>
                <td><span class="badge {{ $p->show_in_header ? 'badge-completed-sm' : '' }}" style="{{ !$p->show_in_header ? 'color:var(--muted)' : '' }}">{{ $p->show_in_header ? 'Yes' : 'No' }}</span></td>
                <td><span class="badge {{ $p->show_in_footer ? 'badge-completed-sm' : '' }}" style="{{ !$p->show_in_footer ? 'color:var(--muted)' : '' }}">{{ $p->show_in_footer ? 'Yes' : 'No' }}</span></td>
                <td><span class="badge {{ $p->is_active ? 'badge-completed-sm' : 'badge-live-sm' }}">{{ $p->is_active ? 'Active' : 'Off' }}</span></td>
                <td>
                    <a href="{{ route('admin.pages.edit', $p->id) }}" class="btn-sm btn-edit">Edit</a>
                    <a href="{{ url('/page/'.$p->slug) }}" target="_blank" class="btn-sm btn-success">View</a>
                    <form method="POST" action="{{ route('admin.pages.destroy', $p->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete page?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">No pages.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem">{{ $pages->links() }}</div>
</div>
@endsection
