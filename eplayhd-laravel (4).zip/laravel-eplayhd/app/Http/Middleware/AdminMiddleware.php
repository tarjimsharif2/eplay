<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\UserRole;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Please login to access the admin panel.');
        }

        $user = auth()->user();

        // Check if user has admin role
        $isAdmin = \App\Models\UserRole::where('user_id', $user->id)
            ->where('role', 'admin')
            ->exists();

        if (!$isAdmin) {
            // Check profile is_admin flag
            $profile = \App\Models\Profile::where('user_id', $user->id)->first();
            if (!$profile?->is_admin) {
                abort(403, 'Access denied. Admin privileges required.');
            }
        }

        return $next($request);
    }
}
