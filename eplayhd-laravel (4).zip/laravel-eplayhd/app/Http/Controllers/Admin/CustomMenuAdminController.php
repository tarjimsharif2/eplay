<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\CustomMenu;
use Illuminate\Http\Request;

class CustomMenuAdminController extends Controller
{
    public function index() {
        $menus = CustomMenu::with('children')->whereNull('parent_id')->orderBy('display_order')->get();
        return view('admin.menus.index', compact('menus'));
    }
    public function store(Request $request) {
        CustomMenu::create($request->validate(['title'=>'required|string|max:255','url'=>'nullable|string','icon_name'=>'nullable|string|max:100','menu_type'=>'nullable|in:link,dropdown','parent_id'=>'nullable|exists:custom_menus,id','display_order'=>'nullable|integer','is_active'=>'boolean','open_in_new_tab'=>'boolean']));
        cache()->forget('custom_menus');
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Menu item created.');
    }
    public function update(Request $request, string $id) {
        CustomMenu::findOrFail($id)->update($request->validate(['title'=>'required|string|max:255','url'=>'nullable|string','icon_name'=>'nullable|string|max:100','menu_type'=>'nullable|in:link,dropdown','parent_id'=>'nullable|exists:custom_menus,id','display_order'=>'nullable|integer','is_active'=>'boolean','open_in_new_tab'=>'boolean']));
        cache()->forget('custom_menus');
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Menu item updated.');
    }
    public function destroy(string $id) { CustomMenu::findOrFail($id)->delete(); cache()->forget('custom_menus'); return back()->with('success','Menu item deleted.'); }
    public function reorder(Request $request) {
        foreach ($request->order as $item) { CustomMenu::where('id',$item['id'])->update(['display_order'=>$item['order']]); }
        cache()->forget('custom_menus');
        return response()->json(['success'=>true]);
    }
}
