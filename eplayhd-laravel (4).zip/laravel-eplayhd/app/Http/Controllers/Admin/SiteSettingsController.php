<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteSettings;
use App\Models\SitemapPingHistory;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class SiteSettingsController extends Controller
{
    public function index()
    {
        $settings = SiteSettings::first() ?? new SiteSettings();
        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        $settings = SiteSettings::first() ?? new SiteSettings();

        $validated = $request->validate([
            'site_name' => 'required|string|max:255',
            'site_title' => 'required|string|max:500',
            'site_description' => 'nullable|string',
            'site_keywords' => 'nullable|string',
            'logo_url' => 'nullable|url',
            'favicon_url' => 'nullable|url',
            'og_image_url' => 'nullable|url',
            'canonical_url' => 'nullable|url',
            'footer_text' => 'nullable|string',
            'disclaimer_text' => 'nullable|string',
            'show_disclaimer' => 'boolean',
            'telegram_link' => 'nullable|string',
            'twitter_handle' => 'nullable|string|max:100',
            'facebook_app_id' => 'nullable|string|max:100',
            'admin_slug' => 'nullable|string|max:255|regex:/^[a-zA-Z0-9\-_]+$/',
            'ads_enabled' => 'boolean',
            'ads_txt_content' => 'nullable|string',
            'google_adsense_id' => 'nullable|string|max:100',
            'header_ad_code' => 'nullable|string',
            'footer_ad_code' => 'nullable|string',
            'sidebar_ad_code' => 'nullable|string',
            'in_article_ad_code' => 'nullable|string',
            'popup_ad_code' => 'nullable|string',
            'google_analytics_id' => 'nullable|string|max:100',
            'robots_txt' => 'nullable|string',
            'schema_org_enabled' => 'boolean',
            'custom_header_code' => 'nullable|string',
            'custom_footer_code' => 'nullable|string',
            'homepage_channels_limit' => 'nullable|integer|min:0|max:50',
            'homepage_completed_days' => 'nullable|integer|min:0|max:30',
            'slider_duration_seconds' => 'nullable|integer|min:1|max:30',
            'maintenance_mode' => 'boolean',
            'maintenance_title' => 'nullable|string|max:500',
            'maintenance_subtitle' => 'nullable|string|max:500',
            'maintenance_description' => 'nullable|string',
            'maintenance_estimated_time' => 'nullable|string|max:255',
            'maintenance_end_time' => 'nullable|string|max:255',
            'maintenance_show_countdown' => 'boolean',
            'maintenance_contact_email' => 'nullable|email|max:255',
            'api_cricket_enabled' => 'boolean',
            'api_cricket_key' => 'nullable|string',
            'cricket_api_enabled' => 'boolean',
            'cricket_api_key' => 'nullable|string',
            'api_sync_interval_seconds' => 'nullable|integer|min:30',
            'auto_match_result_enabled' => 'boolean',
            'rapidapi_enabled' => 'boolean',
            'rapidapi_key' => 'nullable|string',
            'points_table_auto_sync_enabled' => 'boolean',
            'smtp_enabled' => 'boolean',
            'smtp_host' => 'nullable|string|max:255',
            'smtp_port' => 'nullable|integer',
            'smtp_user' => 'nullable|string|max:255',
            'smtp_password' => 'nullable|string',
            'smtp_from_email' => 'nullable|email|max:255',
            'smtp_from_name' => 'nullable|string|max:255',
        ]);

        // Handle JSON fields
        if ($request->has('match_page_ad_positions')) {
            $validated['match_page_ad_positions'] = $request->match_page_ad_positions;
        }
        if ($request->has('tournament_page_ad_positions')) {
            $validated['tournament_page_ad_positions'] = $request->tournament_page_ad_positions;
        }
        if ($request->has('social_links')) {
            $validated['social_links'] = $request->social_links;
        }
        if ($request->has('rapidapi_endpoints')) {
            $validated['rapidapi_endpoints'] = json_decode($request->rapidapi_endpoints, true);
        }
        if ($request->has('ad_click_protection')) {
            $validated['ad_click_protection'] = json_decode($request->ad_click_protection, true);
        }

        if (!$settings->exists) {
            $settings->id = (string) \Illuminate\Support\Str::uuid();
        }

        $settings->fill($validated)->save();

        // Clear all cached settings
        cache()->forget('site_settings');
        cache()->forget('custom_menus');
        cache()->forget('menu_tournaments');
        cache()->forget('footer_pages');

        if ($request->wantsJson()) {
            return response()->json(['success' => true]);
        }

        return back()->with('success', 'Settings saved successfully!');
    }

    public function pingSitemap(Request $request): JsonResponse
    {
        $sitemapUrl = url('/sitemap.xml');
        $engines = [
            'google' => "https://www.google.com/ping?sitemap={$sitemapUrl}",
            'bing' => "https://www.bing.com/ping?sitemap={$sitemapUrl}",
        ];

        $results = [];
        $successCount = 0;

        foreach ($engines as $engine => $pingUrl) {
            try {
                $response = \Illuminate\Support\Facades\Http::timeout(10)->get($pingUrl);
                $success = $response->successful();
                $results[$engine] = ['success' => $success, 'status' => $response->status()];
                if ($success) $successCount++;
            } catch (\Exception $e) {
                $results[$engine] = ['success' => false, 'error' => $e->getMessage()];
            }
        }

        // Log ping history
        \App\Models\SitemapPingHistory::create([
            'sitemap_url' => $sitemapUrl,
            'ping_type' => 'manual',
            'results' => $results,
            'success_count' => $successCount,
            'total_count' => count($engines),
            'triggered_by' => auth()->user()?->email,
        ]);

        return response()->json(['success' => true, 'results' => $results, 'success_count' => $successCount]);
    }

    public function googleIndex(Request $request): JsonResponse
    {
        $url = $request->url ?? url('/');
        return response()->json(['success' => true, 'message' => 'Google Indexing API requires OAuth setup. URL: ' . $url]);
    }
}
