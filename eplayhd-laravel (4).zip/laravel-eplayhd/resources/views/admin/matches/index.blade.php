@extends('layouts.admin')
@section('title', 'Matches')
@section('content')
<div class="admin-header">
    <div>
        <h1 class="admin-page-title">Matches</h1>
        <p style="font-size:0.875rem;color:var(--muted);">{{ $matches->total() }} total</p>
    </div>
    <div class="admin-actions">
        <a href="{{ route('admin.matches.create') }}" class="btn-primary-sm">
            <svg style="width:0.875rem;height:0.875rem" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            New Match
        </a>
    </div>
</div>

{{-- Filters --}}
<form method="GET" style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:1.25rem;">
    <select name="status" class="form-select" style="width:auto;" onchange="this.form.submit()">
        <option value="">All Statuses</option>
        @foreach(['live','upcoming','completed','abandoned','postponed'] as $s)
        <option value="{{ $s }}" {{ request('status') === $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
        @endforeach
    </select>
    <select name="sport_id" class="form-select" style="width:auto;" onchange="this.form.submit()">
        <option value="">All Sports</option>
        @foreach($sports as $sport)
        <option value="{{ $sport->id }}" {{ request('sport_id') === $sport->id ? 'selected' : '' }}>{{ $sport->name }}</option>
        @endforeach
    </select>
    <input type="text" name="search" class="form-input" style="width:220px" placeholder="Search team…" value="{{ request('search') }}">
    <button type="submit" class="btn-primary-sm">Filter</button>
    @if(request()->hasAny(['status','sport_id','search']))
    <a href="{{ route('admin.matches.index') }}" class="btn-sm btn-edit">Clear</a>
    @endif
</form>

<div class="admin-card">
    <table class="admin-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Match</th>
                <th>Tournament</th>
                <th>Score</th>
                <th>Status</th>
                <th>Date</th>
                <th>Servers</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($matches as $match)
            <tr>
                <td style="color:var(--muted);font-size:0.8rem;">{{ $match->match_number }}</td>
                <td>
                    <div style="display:flex;align-items:center;gap:0.5rem;">
                        @if($match->teamA?->logo_url)
                            <img src="{{ $match->teamA->logo_url }}" style="width:1.5rem;height:1.5rem;object-fit:contain;border-radius:0.25rem">
                        @endif
                        <div>
                            <div style="font-weight:600;font-size:0.875rem;">{{ $match->teamA?->short_name ?? '?' }} vs {{ $match->teamB?->short_name ?? '?' }}</div>
                            <div style="font-size:0.7rem;color:var(--muted)">{{ $match->sport?->name }} • {{ $match->match_format }}</div>
                        </div>
                    </div>
                </td>
                <td style="font-size:0.875rem;color:var(--muted);">{{ $match->tournament?->name ?? '–' }}</td>
                <td style="font-size:0.875rem;">
                    @if($match->score_a || $match->score_b)
                    <span style="font-weight:600;color:var(--primary)">{{ $match->score_a }}</span>
                    <span style="color:var(--muted)"> / </span>
                    <span style="font-weight:600;color:var(--primary)">{{ $match->score_b }}</span>
                    @else
                    <span style="color:var(--muted)">–</span>
                    @endif
                </td>
                <td>
                    <span class="badge {{ $match->status === 'live' ? 'badge-live-sm' : ($match->status === 'upcoming' ? 'badge-upcoming-sm' : 'badge-completed-sm') }}">
                        {{ $match->status === 'live' ? '🔴 ' : '' }}{{ ucfirst($match->status) }}
                    </span>
                </td>
                <td style="font-size:0.8rem;color:var(--muted);">{{ $match->match_date ?? '–' }}</td>
                <td style="font-size:0.875rem;color:var(--muted);">{{ $match->streamingServers->count() ?? 0 }}</td>
                <td>
                    <div style="display:flex;gap:0.375rem;flex-wrap:wrap;">
                        <a href="{{ route('admin.matches.show', $match->id) }}" class="btn-sm btn-edit">Edit</a>
                        @if($match->slug && $match->page_type === 'page')
                        <a href="{{ url('/match/'.$match->slug) }}" target="_blank" class="btn-sm btn-success">View</a>
                        @endif
                        <form method="POST" action="{{ route('admin.matches.destroy', $match->id) }}" style="display:inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="btn-sm btn-delete" data-confirm="Delete this match?">Del</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--muted);">No matches found.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem 1.25rem;border-top:1px solid var(--border);">
        {{ $matches->withQueryString()->links() }}
    </div>
</div>
@endsection
