<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserRole;
use App\Models\Profile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserAdminController extends Controller
{
    public function index() {
        $users = \App\Models\User::with(['profile','roles'])->orderBy('created_at','desc')->paginate(20);
        return view('admin.users.index', compact('users'));
    }
    public function store(Request $request) {
        $v = $request->validate(['name'=>'required|string|max:255','email'=>'required|email|unique:users','password'=>'required|min:8','role'=>'nullable|in:admin,moderator,editor,viewer']);
        $user = \App\Models\User::create(['name'=>$v['name'],'email'=>$v['email'],'password'=>Hash::make($v['password'])]);
        Profile::create(['user_id'=>$user->id,'email'=>$v['email'],'is_admin'=>($v['role']==='admin')]);
        UserRole::create(['user_id'=>$user->id,'role'=>$v['role']??'viewer']);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','User created.');
    }
    public function update(Request $request, string $id) {
        $user = \App\Models\User::findOrFail($id);
        $v = $request->validate(['name'=>'required|string|max:255','email'=>'required|email|unique:users,email,'.$id,'role'=>'nullable|in:admin,moderator,editor,viewer','password'=>'nullable|min:8']);
        $user->update(['name'=>$v['name'],'email'=>$v['email']]);
        if (!empty($v['password'])) $user->update(['password'=>Hash::make($v['password'])]);
        UserRole::where('user_id',$user->id)->delete();
        UserRole::create(['user_id'=>$user->id,'role'=>$v['role']??'viewer']);
        Profile::where('user_id',$user->id)->update(['is_admin'=>($v['role']==='admin'),'email'=>$v['email']]);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','User updated.');
    }
    public function destroy(string $id) {
        if ((int)$id === auth()->id()) return back()->with('error','Cannot delete yourself.');
        \App\Models\User::findOrFail($id)->delete();
        return back()->with('success','User deleted.');
    }
}
