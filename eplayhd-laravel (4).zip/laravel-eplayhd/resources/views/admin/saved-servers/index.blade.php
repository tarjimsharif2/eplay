@extends('layouts.admin')
@section('title','Saved Servers')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Saved Servers</h1><button onclick="document.getElementById('add-saved-modal').style.display='flex'" class="btn-primary-sm">+ Save Server</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Name</th><th>URL</th><th>Type</th><th>Notes</th><th></th></tr></thead>
        <tbody>
            @forelse($servers as $s)
            <tr>
                <td style="font-weight:500;font-size:0.875rem">{{ $s->server_name }}</td>
                <td style="font-size:0.75rem;color:var(--muted);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $s->server_url }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $s->server_type }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ Str::limit($s->notes,50) }}</td>
                <td><form method="POST" action="{{ route('admin.saved-servers.destroy', $s->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete?">Del</button></form></td>
            </tr>
            @empty
            <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:2rem">No saved servers.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem">{{ $servers->links() }}</div>
</div>
<div id="add-saved-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700">Save Server</h3><button onclick="document.getElementById('add-saved-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.saved-servers.store') }}">@csrf
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Name *</label><input type="text" name="server_name" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Type</label><select name="server_type" class="form-select"><option value="hls">HLS</option><option value="iframe">iFrame</option><option value="mp4">MP4</option></select></div>
            </div>
            <div class="form-group"><label class="form-label">URL *</label><input type="text" name="server_url" class="form-input" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Referer</label><input type="text" name="referer_value" class="form-input"></div>
                <div class="form-group"><label class="form-label">Origin</label><input type="text" name="origin_value" class="form-input"></div>
            </div>
            <div class="form-group"><label class="form-label">Notes</label><textarea name="notes" class="form-textarea" rows="2"></textarea></div>
            <div style="display:flex;gap:0.75rem;margin-top:0.75rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Save</button><button type="button" onclick="document.getElementById('add-saved-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@endsection
