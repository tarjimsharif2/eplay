<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>{{ url('/') }}</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc>{{ url('/channels') }}</loc>
        <changefreq>weekly</changefreq>
        <priority>0.7</priority>
    </url>
    @foreach($matches as $match)
    <url>
        <loc>{{ url('/match/' . $match->slug) }}</loc>
        <lastmod>{{ $match->updated_at ? $match->updated_at->toAtomString() : now()->toAtomString() }}</lastmod>
        <changefreq>hourly</changefreq>
        <priority>0.9</priority>
    </url>
    @endforeach
    @foreach($tournaments as $tournament)
    <url>
        <loc>{{ url('/tournament/' . $tournament->slug) }}</loc>
        <lastmod>{{ $tournament->updated_at ? $tournament->updated_at->toAtomString() : now()->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.8</priority>
    </url>
    @endforeach
    @foreach($channels as $channel)
    <url>
        <loc>{{ url('/channel/' . $channel->slug) }}</loc>
        <lastmod>{{ $channel->updated_at ? $channel->updated_at->toAtomString() : now()->toAtomString() }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.6</priority>
    </url>
    @endforeach
    @foreach($pages as $page)
    <url>
        <loc>{{ url('/page/' . $page->slug) }}</loc>
        <lastmod>{{ $page->updated_at ? $page->updated_at->toAtomString() : now()->toAtomString() }}</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.5</priority>
    </url>
    @endforeach
</urlset>
