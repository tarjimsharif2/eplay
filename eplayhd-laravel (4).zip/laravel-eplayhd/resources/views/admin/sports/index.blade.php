@extends('layouts.admin')
@section('title','Sports')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Sports</h1><button onclick="document.getElementById('add-sport-modal').style.display='flex'" class="btn-primary-sm">+ Add</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Name</th><th>Order</th><th>Icon</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($sports as $sport)
            <tr>
                <td style="font-weight:600;font-size:0.875rem">{{ $sport->name }}</td>
                <td style="color:var(--muted)">{{ $sport->display_order }}</td>
                <td>@if($sport->icon_url)<img src="{{ $sport->icon_url }}" style="width:1.5rem;height:1.5rem;object-fit:contain">@endif</td>
                <td>
                    <button onclick="editSport('{{ $sport->id }}','{{ addslashes($sport->name) }}','{{ $sport->icon_url }}','{{ $sport->display_order }}')" class="btn-sm btn-edit">Edit</button>
                    <form method="POST" action="{{ route('admin.sports.destroy', $sport->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" style="text-align:center;color:var(--muted);padding:2rem">No sports.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div id="add-sport-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:400px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700" id="sport-modal-title">Add Sport</h3><button onclick="closeSportModal()" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form id="sport-form" method="POST" action="{{ route('admin.sports.store') }}">@csrf
            <input type="hidden" id="sport-method" name="_method" value="">
            <div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" id="sport-name" class="form-input" required></div>
            <div class="form-group"><label class="form-label">Icon URL</label><input type="text" name="icon_url" id="sport-icon" class="form-input"></div>
            <div class="form-group"><label class="form-label">Display Order</label><input type="number" name="display_order" id="sport-order" class="form-input" value="0"></div>
            <div style="display:flex;gap:0.75rem;margin-top:1rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Save</button><button type="button" onclick="closeSportModal()" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@push('scripts')
<script>
function editSport(id, name, icon, order) {
    document.getElementById('sport-modal-title').textContent = 'Edit Sport';
    document.getElementById('sport-form').action = '/admin/sports/' + id;
    document.getElementById('sport-method').value = 'PUT';
    document.getElementById('sport-name').value = name;
    document.getElementById('sport-icon').value = icon || '';
    document.getElementById('sport-order').value = order || 0;
    document.getElementById('add-sport-modal').style.display = 'flex';
}
function closeSportModal() {
    document.getElementById('sport-form').action = '{{ route("admin.sports.store") }}';
    document.getElementById('sport-method').value = '';
    document.getElementById('sport-modal-title').textContent = 'Add Sport';
    document.getElementById('add-sport-modal').style.display = 'none';
}
</script>
@endpush
@endsection
