@extends('layouts.admin')
@section('title','Menus')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Custom Menus</h1><button onclick="document.getElementById('add-menu-modal').style.display='flex'" class="btn-primary-sm">+ Add Item</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Title</th><th>URL</th><th>Type</th><th>Children</th><th>Order</th><th>Active</th><th></th></tr></thead>
        <tbody>
            @forelse($menus as $menu)
            <tr>
                <td style="font-weight:600">{{ $menu->title }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $menu->url }}</td>
                <td style="font-size:0.8rem">{{ $menu->menu_type }}</td>
                <td>{{ $menu->children->count() }}</td>
                <td>{{ $menu->display_order }}</td>
                <td><span class="badge {{ $menu->is_active ? 'badge-completed-sm' : '' }}" style="{{ !$menu->is_active ? 'color:var(--muted)' : '' }}">{{ $menu->is_active ? 'Yes' : 'No' }}</span></td>
                <td>
                    <button onclick="editMenu('{{ $menu->id }}','{{ addslashes($menu->title) }}','{{ addslashes($menu->url ?? '') }}','{{ $menu->menu_type }}','{{ $menu->display_order }}','{{ $menu->is_active }}')" class="btn-sm btn-edit">Edit</button>
                    <form method="POST" action="{{ route('admin.menus.destroy', $menu->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete menu item?">Del</button></form>
                </td>
            </tr>
            @if($menu->children->count())
            @foreach($menu->children as $child)
            <tr style="background:var(--accent)">
                <td style="padding-left:2rem;font-size:0.8rem;color:var(--muted)">↳ {{ $child->title }}</td>
                <td style="font-size:0.75rem;color:var(--muted)">{{ $child->url }}</td>
                <td colspan="3"></td>
                <td><span class="badge {{ $child->is_active ? 'badge-completed-sm' : '' }}" style="{{ !$child->is_active ? 'color:var(--muted)' : '' }}">{{ $child->is_active ? 'Yes' : 'No' }}</span></td>
                <td>
                    <form method="POST" action="{{ route('admin.menus.destroy', $child->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete?">×</button></form>
                </td>
            </tr>
            @endforeach
            @endif
            @empty
            <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:2rem">No menu items.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div id="add-menu-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:480px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700" id="menu-modal-title">Add Menu Item</h3><button onclick="closeMenuModal()" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form id="menu-form" method="POST" action="{{ route('admin.menus.store') }}">@csrf
            <input type="hidden" id="menu-method" name="_method" value="">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Title *</label><input type="text" name="title" id="menu-title" class="form-input" required></div>
                <div class="form-group"><label class="form-label">URL</label><input type="text" name="url" id="menu-url" class="form-input" placeholder="/matches, https://…"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Type</label><select name="menu_type" id="menu-type" class="form-select"><option value="link">Link</option><option value="dropdown">Dropdown</option></select></div>
                <div class="form-group"><label class="form-label">Display Order</label><input type="number" name="display_order" id="menu-order" class="form-input" value="0"></div>
            </div>
            <div class="form-group"><label class="form-label">Parent (for sub-items)</label>
                <select name="parent_id" class="form-select">
                    <option value="">Top Level</option>
                    @foreach($menus as $m)<option value="{{ $m->id }}">{{ $m->title }}</option>@endforeach
                </select></div>
            <div style="display:flex;gap:1.5rem;margin-bottom:1rem;">
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" id="menu-active" class="form-checkbox" value="1" checked>Active</label>
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="open_in_new_tab" value="0"><input type="checkbox" name="open_in_new_tab" class="form-checkbox" value="1">New Tab</label>
            </div>
            <div style="display:flex;gap:0.75rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Save</button><button type="button" onclick="closeMenuModal()" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@push('scripts')
<script>
function editMenu(id, title, url, type, order, active) {
    document.getElementById('menu-modal-title').textContent = 'Edit Menu Item';
    document.getElementById('menu-form').action = '/admin/menus/' + id;
    document.getElementById('menu-method').value = 'PUT';
    document.getElementById('menu-title').value = title;
    document.getElementById('menu-url').value = url;
    document.getElementById('menu-type').value = type;
    document.getElementById('menu-order').value = order;
    document.getElementById('menu-active').checked = active == '1';
    document.getElementById('add-menu-modal').style.display = 'flex';
}
function closeMenuModal() {
    document.getElementById('menu-form').action = '{{ route("admin.menus.store") }}';
    document.getElementById('menu-method').value = '';
    document.getElementById('menu-modal-title').textContent = 'Add Menu Item';
    document.getElementById('add-menu-modal').style.display = 'none';
}
</script>
@endpush
@endsection
