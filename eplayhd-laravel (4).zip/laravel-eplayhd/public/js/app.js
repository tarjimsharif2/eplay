/* ============================================================
   ePlayHD - Main JavaScript
   Theme toggle, HLS.js player, banner slider, utilities
   ============================================================ */

// ============================================================
// Theme Toggle
// ============================================================
(function() {
    const THEME_KEY = 'eplayhd_theme';

    function applyTheme(theme) {
        document.documentElement.classList.toggle('dark', theme === 'dark');
        document.body.classList.toggle('dark', theme === 'dark');
        const sunIcon = document.querySelector('.sun-icon');
        const moonIcon = document.querySelector('.moon-icon');
        if (sunIcon) sunIcon.classList.toggle('hidden', theme === 'dark');
        if (moonIcon) moonIcon.classList.toggle('hidden', theme !== 'dark');
    }

    function getSavedTheme() {
        return localStorage.getItem(THEME_KEY) ||
            (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    }

    // Apply on load immediately to avoid flash
    applyTheme(getSavedTheme());

    document.addEventListener('DOMContentLoaded', function() {
        const toggleBtn = document.getElementById('theme-toggle');
        if (!toggleBtn) return;

        let current = getSavedTheme();
        applyTheme(current);

        toggleBtn.addEventListener('click', function() {
            current = current === 'dark' ? 'light' : 'dark';
            localStorage.setItem(THEME_KEY, current);
            applyTheme(current);

            // Persist to server session (optional)
            fetch('/api/set-theme', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || ''
                },
                body: JSON.stringify({ theme: current })
            }).catch(() => {});
        });
    });
})();

// ============================================================
// HLS.js CDN loader
// ============================================================
(function() {
    if (document.querySelector('.hls-player-wrapper, [data-hls]')) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/hls.js@latest/dist/hls.min.js';
        script.onload = function() { window._hlsLoaded = true; };
        document.head.appendChild(script);
    }
})();

// ============================================================
// Banner / Hero Slider
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.banner-slide');
    const dots = document.querySelectorAll('.slider-dot');
    if (!slides.length) return;

    let current = 0;
    let timer = null;
    const duration = parseInt(document.querySelector('.banner-slider')?.dataset.duration || '5000');

    function showSlide(idx) {
        slides.forEach((s, i) => s.classList.toggle('active', i === idx));
        dots.forEach((d, i) => d.classList.toggle('active', i === idx));
        current = idx;
    }

    function nextSlide() {
        showSlide((current + 1) % slides.length);
    }

    function startAuto() {
        if (slides.length <= 1) return;
        timer = setInterval(nextSlide, duration);
    }

    function stopAuto() {
        clearInterval(timer);
    }

    // Dot click
    dots.forEach((dot, i) => {
        dot.addEventListener('click', function() {
            stopAuto();
            showSlide(i);
            startAuto();
        });
    });

    // Touch/swipe
    let startX = 0;
    const slider = document.querySelector('.banner-slider');
    if (slider) {
        slider.addEventListener('touchstart', e => { startX = e.touches[0].clientX; });
        slider.addEventListener('touchend', e => {
            const diff = startX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) {
                stopAuto();
                if (diff > 0) nextSlide();
                else showSlide((current - 1 + slides.length) % slides.length);
                startAuto();
            }
        });
    }

    showSlide(0);
    startAuto();
});

// ============================================================
// Mobile Header Menu Toggle (fallback if not in component)
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const mobileNav = document.getElementById('mobile-nav');

    if (mobileBtn && mobileNav) {
        const hamburger = mobileBtn.querySelector('.hamburger');
        const closeIcon = mobileBtn.querySelector('.close-icon');
        let open = false;

        mobileBtn.addEventListener('click', function() {
            open = !open;
            mobileNav.classList.toggle('hidden', !open);
            hamburger?.classList.toggle('hidden', open);
            closeIcon?.classList.toggle('hidden', !open);
        });
    }

    // Dropdown menus
    document.querySelectorAll('.dropdown-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const dropdown = this.nextElementSibling;
            if (!dropdown) return;
            const isOpen = !dropdown.classList.contains('hidden');

            // Close all
            document.querySelectorAll('.dropdown-menu').forEach(d => d.classList.add('hidden'));
            if (!isOpen) dropdown.classList.remove('hidden');
        });
    });

    document.addEventListener('click', function() {
        document.querySelectorAll('.dropdown-menu').forEach(d => d.classList.add('hidden'));
    });
});

// ============================================================
// Flash message auto-dismiss
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    const flashes = document.querySelectorAll('.flash-success, .flash-error, .toast');
    flashes.forEach(el => {
        setTimeout(() => {
            el.style.transition = 'opacity 0.5s';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 500);
        }, 4000);
    });
});

// ============================================================
// Admin: Confirm delete
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', function(e) {
            if (!confirm(this.dataset.confirm || 'Are you sure?')) {
                e.preventDefault();
                e.stopPropagation();
            }
        });
    });
});

// ============================================================
// Admin: Live score refresh polling
// ============================================================
window.startScorePolling = function(matchId, interval) {
    interval = interval || 30000;
    return setInterval(function() {
        fetch('/api/match/' + matchId + '/score')
            .then(r => r.json())
            .then(data => {
                if (data.score_a) {
                    document.querySelectorAll('[id^="score-a-"]').forEach(el => {
                        el.textContent = data.score_a;
                    });
                }
                if (data.score_b) {
                    document.querySelectorAll('[id^="score-b-"]').forEach(el => {
                        el.textContent = data.score_b;
                    });
                }
                if (data.match_minute !== null) {
                    document.querySelectorAll('[id^="minute-"]').forEach(el => {
                        el.textContent = data.match_minute + "'";
                    });
                }
            })
            .catch(() => {});
    }, interval);
};

// ============================================================
// Video Player: Load HLS or iframe
// ============================================================
window.initVideoPlayer = function(container, url, type, playerType) {
    if (!container) return;

    if (playerType === 'iframe' || type === 'iframe') {
        container.innerHTML = '<iframe src="' + url + '" allowfullscreen class="video-iframe" allow="autoplay; encrypted-media" scrolling="no" frameborder="0"></iframe>';
        return;
    }

    if (type === 'youtube' || url.includes('youtube.com') || url.includes('youtu.be')) {
        const videoId = url.match(/(?:v=|youtu\.be\/)([^&?]+)/)?.[1] || '';
        container.innerHTML = '<iframe src="https://www.youtube.com/embed/' + videoId + '?autoplay=1" allowfullscreen class="video-iframe" allow="autoplay; encrypted-media" frameborder="0"></iframe>';
        return;
    }

    // HLS / MP4
    const video = document.createElement('video');
    video.className = 'hls-video';
    video.controls = true;
    video.autoplay = true;
    video.playsInline = true;
    video.style.width = '100%';
    video.style.height = '100%';
    container.innerHTML = '';
    container.appendChild(video);

    function attachHLS() {
        if (video.canPlayType('application/vnd.apple.mpegurl')) {
            video.src = url;
            video.play().catch(() => {});
        } else if (window.Hls && window.Hls.isSupported()) {
            const hls = new window.Hls({ startLevel: -1, enableWorker: true });
            hls.loadSource(url);
            hls.attachMedia(video);
            hls.on(window.Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}));
        } else {
            video.src = url;
            video.play().catch(() => {});
        }
    }

    if (window.Hls) {
        attachHLS();
    } else {
        // Wait for HLS.js to load
        const wait = setInterval(() => {
            if (window.Hls) { clearInterval(wait); attachHLS(); }
        }, 200);
        setTimeout(() => clearInterval(wait), 5000);
    }
};

// ============================================================
// Countdown Timer for upcoming matches
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-countdown]').forEach(el => {
        const target = new Date(el.dataset.countdown).getTime();

        function update() {
            const now = Date.now();
            const diff = target - now;
            if (diff <= 0) { el.textContent = 'Starting soon'; return; }

            const h = Math.floor(diff / 3600000);
            const m = Math.floor((diff % 3600000) / 60000);
            const s = Math.floor((diff % 60000) / 1000);

            el.textContent = [h, m, s].map(n => String(n).padStart(2, '0')).join(':');
        }

        update();
        setInterval(update, 1000);
    });
});

// ============================================================
// Football minute live counter
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-football-minute]').forEach(el => {
        let minute = parseInt(el.dataset.footballMinute) || 0;
        let seconds = 0;

        setInterval(() => {
            seconds++;
            if (seconds >= 60) { seconds = 0; /* don't increment minute client-side, wait server */ }
            // Show as MM:SS
            const display = String(minute).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
            el.textContent = display;
        }, 1000);
    });
});

// ============================================================
// Reorder drag-and-drop (for admin)
// ============================================================
window.initSortable = function(listEl, onReorder) {
    if (!listEl || typeof Sortable === 'undefined') return;
    return Sortable.create(listEl, {
        animation: 150,
        handle: '.drag-handle',
        onEnd: function(evt) {
            const items = listEl.querySelectorAll('[data-id]');
            const order = Array.from(items).map((el, idx) => ({
                id: el.dataset.id,
                order: idx + 1
            }));
            if (onReorder) onReorder(order);
        }
    });
};

// ============================================================
// CSRF helper for fetch
// ============================================================
window.csrfToken = function() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
};

window.jsonPost = function(url, data) {
    return fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': window.csrfToken(),
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    }).then(r => r.json());
};

window.jsonPut = function(url, data) {
    return fetch(url, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': window.csrfToken(),
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    }).then(r => r.json());
};

window.jsonDelete = function(url) {
    return fetch(url, {
        method: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': window.csrfToken(),
            'Accept': 'application/json'
        }
    }).then(r => r.json());
};
