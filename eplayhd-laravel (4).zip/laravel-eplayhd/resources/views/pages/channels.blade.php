@extends('layouts.app')
@section('title', 'Sports Channels - ' . ($siteSettings->site_name ?? 'ePlayHD'))
@section('meta_description', 'Watch live sports channels online - Cricket, Football and more')
@section('content')
<div class="container" style="padding:2rem 1rem;">
    <h1 class="section-title" style="margin-bottom:1.5rem;">
        <svg style="width:1.25rem;height:1.25rem;display:inline;margin-right:0.5rem" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
        Sports Channels
    </h1>
    <div class="channel-grid" style="grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:1rem;">
        @foreach($channels as $channel)
        <a href="{{ route('channel.show', $channel->slug) }}" class="channel-card" style="padding:1.25rem 0.75rem;">
            <div class="channel-logo" style="width:3.5rem;height:3.5rem;{{ $channel->logo_background_color ? 'background:'.$channel->logo_background_color : '' }}">
                @if($channel->logo_url)
                    <img src="{{ $channel->logo_url }}" alt="{{ $channel->name }}" class="channel-logo-img">
                @else
                    <span class="channel-initials" style="font-size:1rem;">{{ strtoupper(substr($channel->name,0,2)) }}</span>
                @endif
            </div>
            <span class="channel-name" style="font-size:0.8rem;">{{ $channel->name }}</span>
        </a>
        @endforeach
    </div>
    @if($channels->count() === 0)
    <div class="empty-state"><p>No channels available at the moment.</p></div>
    @endif
</div>
@endsection
