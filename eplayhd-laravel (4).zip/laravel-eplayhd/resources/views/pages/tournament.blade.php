@extends('layouts.app')
@section('title', $seoTitle)
@section('meta_description', $seoDescription)
@section('meta_keywords', $seoKeywords)
@section('og_image', $tournament->logo_url ?? $siteSettings?->og_image_url ?? '')
@section('content')
<div class="tournament-page container" style="padding:2rem 1rem;">

    {{-- Tournament Header --}}
    <div class="tournament-header" style="text-align:center;padding:2rem;background:var(--card);border:1px solid var(--border);border-radius:1rem;margin-bottom:1.5rem;">
        @if($tournament->logo_url)
        <div style="width:5rem;height:5rem;margin:0 auto 1rem;border-radius:1rem;border:1px solid var(--border);padding:0.5rem;display:flex;align-items:center;justify-content:center;{{ $tournament->logo_background_color ? 'background:'.$tournament->logo_background_color : '' }}">
            <img src="{{ $tournament->logo_url }}" alt="{{ $tournament->name }}" style="width:100%;height:100%;object-fit:contain">
        </div>
        @endif
        <h1 style="font-size:1.75rem;font-weight:800;font-family:var(--font-display);margin-bottom:0.375rem;">{{ $tournament->name }}</h1>
        <p style="color:var(--muted);font-size:0.875rem;">{{ $tournament->season }} • {{ $tournament->sport }}</p>
        @if($tournament->description)
        <p style="color:var(--muted);font-size:0.875rem;max-width:600px;margin:0.75rem auto 0;line-height:1.7;">{{ $tournament->description }}</p>
        @endif
        <div style="display:flex;align-items:center;justify-content:center;gap:1rem;margin-top:1rem;font-size:0.8rem;color:var(--muted);">
            @if($tournament->start_date)<span>📅 {{ $tournament->start_date->format('d M Y') }} – {{ $tournament->end_date?->format('d M Y') ?? 'TBD' }}</span>@endif
            @if($tournament->total_teams)<span>🏏 {{ $tournament->total_teams }} Teams</span>@endif
            @if($tournament->total_matches)<span>⚡ {{ $tournament->total_matches }} Matches</span>@endif
        </div>
    </div>

    {{-- Points Table --}}
    @if($pointsTable->count() > 0)
    @include('components.points-table', ['pointsTable' => $pointsTable, 'tournament' => $tournament])
    @endif

    {{-- Participating Teams --}}
    @if($tournament->show_participating_teams && $participatingTeams->count() > 0 && $tournament->participating_teams_position === 'above_table')
    @include('components.participating-teams', ['teams' => $participatingTeams])
    @endif

    {{-- Ad slot --}}
    @if($siteSettings?->ads_enabled && $siteSettings?->in_article_ad_code)
    <div class="ad-slot" style="margin:1rem 0;">{!! $siteSettings->in_article_ad_code !!}</div>
    @endif

    {{-- Live Matches --}}
    @if($liveMatches->count() > 0)
    <div class="matches-group">
        <h2 class="section-title"><span class="live-badge">LIVE</span> Live Matches</h2>
        <div class="match-grid">
            @foreach($liveMatches as $match)
                @include('components.match-card', ['match' => $match, 'index' => $loop->index])
            @endforeach
        </div>
    </div>
    @endif

    {{-- Upcoming --}}
    @if($upcomingMatches->count() > 0)
    <div class="matches-group">
        <h2 class="section-title">Upcoming Matches</h2>
        <div class="match-grid">
            @foreach($upcomingMatches as $match)
                @include('components.match-card', ['match' => $match, 'index' => $loop->index])
            @endforeach
        </div>
    </div>
    @endif

    {{-- Completed --}}
    @if($completedMatches->count() > 0)
    <div class="matches-group">
        <h2 class="section-title">Results</h2>
        <div class="match-grid">
            @foreach($completedMatches as $match)
                @include('components.match-card', ['match' => $match, 'index' => $loop->index])
            @endforeach
        </div>
    </div>
    @endif

    @if($matches->count() === 0)
    <div class="empty-state">
        <p>No matches scheduled for this tournament yet.</p>
    </div>
    @endif
</div>
@endsection
