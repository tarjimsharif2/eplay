<?php

namespace App\Http\Controllers;

use App\Models\MatchModel;
use App\Models\StreamingServer;
use App\Models\MatchApiScore;
use App\Models\MatchPlayingXI;
use App\Models\MatchInning;
use App\Models\TournamentPointsTable;
use App\Models\SponsorNotice;
use App\Models\MatchSubstitution;
use App\Models\SiteSettings;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class MatchController extends Controller
{
    public function show(string $slug)
    {
        // Try by slug first, then by id
        $match = bMatchModel::with([
            'teamA', 'teamB', 'tournament', 'sport',
            'innings.battingTeam', 'playingXI', 'substitutions'
        ])
        ->where('is_active', true)
        ->where(function($q) use ($slug) {
            $q->where('slug', $slug)->orWhere('id', $slug);
        })
        ->first();

        if (!$match) {
            abort(404, 'Match not found');
        }

        $siteSettings = SiteSettings::first();

        // Streaming servers (active only, ordered)
        $servers = StreamingServer::where('match_id', $match->id)
            ->where('is_active', true)
            ->orderBy('display_order')
            ->get();

        // API Score
        $apiScore = null;
        if ($match->api_score_enabled) {
            $apiScore = MatchApiScore::where('match_id', $match->id)->first();
        }

        // Innings (cricket)
        $innings = MatchInning::where('match_id', $match->id)
            ->with('battingTeam')
            ->orderBy('innings_number')
            ->get();

        // Playing XI
        $playingXI = MatchPlayingXI::where('match_id', $match->id)
            ->orderBy('batting_order')
            ->get();

        // Substitutions (football)
        $substitutions = MatchSubstitution::where('match_id', $match->id)
            ->with('team')
            ->orderBy('minute')
            ->get();

        // Sponsor notices
        $sponsorNotices = SponsorNotice::where('is_active', true)
            ->where(function($q) use ($match) {
                $q->where('is_global', true)
                  ->orWhere('match_id', $match->id);
            })
            ->orderBy('display_order')
            ->get();

        // Points table (for the match's tournament)
        $pointsTable = collect();
        if ($match->tournament_id) {
            $pointsTable = TournamentPointsTable::where('tournament_id', $match->tournament_id)
                ->with('team')
                ->orderBy('position')
                ->get();
        }

        // SEO
        $seoTitle = $match->seo_title
            ?? ($match->teamA?->name . ' vs ' . $match->teamB?->name . ' Live Stream | ' . ($siteSettings?->site_name ?? 'ePlayHD'));
        $seoDescription = $match->seo_description
            ?? ('Watch ' . $match->teamA?->name . ' vs ' . $match->teamB?->name . ' live streaming, live score, playing XI at ' . ($siteSettings?->site_name ?? 'ePlayHD'));
        $seoKeywords = $match->seo_keywords ?? '';

        return view('pages.match', compact(
            'match', 'servers', 'apiScore', 'innings', 'playingXI',
            'substitutions', 'sponsorNotices', 'pointsTable',
            'seoTitle', 'seoDescription', 'seoKeywords', 'siteSettings'
        ));
    }

    // API: Get matches
    public function apiMatches(Request $request): JsonResponse
    {
        $status = $request->get('status');
        $sportId = $request->get('sport_id');

        $query = bMatchModel::with(['teamA', 'teamB', 'tournament', 'sport'])
            ->where('is_active', true);

        if ($status && $status !== 'all') {
            $query->where('status', $status);
        }
        if ($sportId) {
            $query->where('sport_id', $sportId);
        }

        $matches = $query->orderBy('is_priority', 'desc')
            ->orderBy('updated_at', 'desc')
            ->get();

        return response()->json(['matches' => $matches]);
    }

    // API: Get match score (for real-time update)
    public function apiScore(string $id): JsonResponse
    {
        $match = bMatchModel::find($id);
        if (!$match) return response()->json(['error' => 'Not found'], 404);

        return response()->json([
            'id' => $match->id,
            'score_a' => $match->score_a,
            'score_b' => $match->score_b,
            'status' => $match->status,
            'match_minute' => $match->match_minute,
            'is_stumps' => $match->is_stumps,
        ]);
    }

    // API: Get streaming servers
    public function apiServers(string $id): JsonResponse
    {
        $servers = StreamingServer::where('match_id', $id)
            ->where('is_active', true)
            ->orderBy('display_order')
            ->get(['id', 'server_name', 'server_url', 'server_type', 'player_type', 'is_working', 'display_order']);

        return response()->json(['servers' => $servers]);
    }

    // API: Get innings
    public function apiInnings(string $id): JsonResponse
    {
        $innings = MatchInning::where('match_id', $id)
            ->with('battingTeam')
            ->orderBy('innings_number')
            ->get();

        return response()->json(['innings' => $innings]);
    }

    // API: Get playing XI
    public function apiPlayingXI(string $id): JsonResponse
    {
        $xi = MatchPlayingXI::where('match_id', $id)
            ->orderBy('batting_order')
            ->get();

        return response()->json(['playing_xi' => $xi]);
    }

    // Report server not working
    public function reportNotWorking(Request $request, string $matchId, string $serverId): JsonResponse
    {
        $server = StreamingServer::where('match_id', $matchId)->where('id', $serverId)->first();
        if (!$server) return response()->json(['error' => 'Not found'], 404);

        $server->increment('not_working_reports');
        $server->last_reported_at = now();

        // Auto-mark broken if enough reports
        if ($server->not_working_reports >= 5) {
            $server->is_working = false;
        }
        $server->save();

        return response()->json(['success' => true]);
    }

    // Report server working
    public function reportWorking(Request $request, string $matchId, string $serverId): JsonResponse
    {
        $server = StreamingServer::where('match_id', $matchId)->where('id', $serverId)->first();
        if (!$server) return response()->json(['error' => 'Not found'], 404);

        $server->is_working = true;
        $server->not_working_reports = max(0, $server->not_working_reports - 1);
        $server->save();

        return response()->json(['success' => true]);
    }
}
