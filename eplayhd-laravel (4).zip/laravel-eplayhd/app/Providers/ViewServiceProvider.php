<?php

namespace App\Providers;

use App\Models\SiteSettings;
use App\Models\CustomMenu;
use App\Models\Tournament;
use App\Models\DynamicPage;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class ViewServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        // Share global data to ALL views
        View::composer('*', function ($view) {
            // Site settings (cached for performance)
            $siteSettings = cache()->remember('site_settings', 300, fn() => SiteSettings::first());

            // Custom menus (active, ordered)
            $customMenus = cache()->remember('custom_menus', 300, fn() =>
                CustomMenu::with('children')
                    ->whereNull('parent_id')
                    ->where('is_active', true)
                    ->orderBy('display_order')
                    ->get()
            );

            // Tournaments for nav menu
            $menuTournaments = cache()->remember('menu_tournaments', 300, fn() =>
                Tournament::where('is_active', true)
                    ->where('show_in_menu', true)
                    ->where('is_completed', false)
                    ->orderBy('created_at', 'desc')
                    ->get()
            );

            // Group tournaments by sport
            $tournamentsBySport = $menuTournaments->groupBy('sport');

            // Footer pages
            $footerPages = cache()->remember('footer_pages', 300, fn() =>
                DynamicPage::where('is_active', true)
                    ->where('show_in_footer', true)
                    ->orderBy('display_order')
                    ->get()
            );

            // Active tournaments for footer
            $activeTournaments = $menuTournaments;

            $view->with(compact(
                'siteSettings',
                'customMenus',
                'menuTournaments',
                'tournamentsBySport',
                'footerPages',
                'activeTournaments'
            ));
        });
    }
}
