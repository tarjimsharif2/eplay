<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class SiteSettings extends Model {
    protected $table = 'site_settings';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $guarded = [];
    protected $casts = [
        'ads_enabled'=>'boolean',
        'maintenance_mode'=>'boolean',
        'show_disclaimer'=>'boolean',
        'schema_org_enabled'=>'boolean',
        'maintenance_show_countdown'=>'boolean',
        'api_cricket_enabled'=>'boolean',
        'cricket_api_enabled'=>'boolean',
        'auto_match_result_enabled'=>'boolean',
        'rapidapi_enabled'=>'boolean',
        'points_table_auto_sync_enabled'=>'boolean',
        'smtp_enabled'=>'boolean',
        'social_links'=>'array',
        'ad_click_protection'=>'array',
        'rapidapi_endpoints'=>'array',
        'match_page_ad_positions'=>'array',
        'tournament_page_ad_positions'=>'array',
    ];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
}
