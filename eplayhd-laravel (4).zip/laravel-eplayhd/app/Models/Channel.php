<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Channel extends Model
{
    protected $table = 'channels';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'name', 'slug', 'description', 'logo_url', 'logo_background_color',
        'display_order', 'is_active', 'seo_title', 'seo_description', 'seo_keywords',
    ];

    protected $casts = ['is_active' => 'boolean'];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($m) {
            $m->id = $m->id ?: (string) Str::uuid();
            if (!$m->slug) $m->slug = Str::slug($m->name);
        });
    }

    public function streamingServers(): HasMany
    {
        return $this->hasMany(ChannelStreamingServer::class, 'channel_id')
            ->where('is_active', true)
            ->orderBy('display_order');
    }
}
