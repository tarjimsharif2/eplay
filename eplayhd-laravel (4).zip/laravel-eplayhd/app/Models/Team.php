<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use App\Models\MatchModel;

class Team extends Model
{
    protected $table = 'teams';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = ['name', 'short_name', 'logo_url', 'logo_background_color'];

    protected static function boot()
    {
        parent::boot();
        static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid());
    }

    public function matchesAsTeamA(): HasMany { return $this->hasMany(MatchModel::class, 'team_a_id'); }
    public function matchesAsTeamB(): HasMany { return $this->hasMany(MatchModel::class, 'team_b_id'); }
}
