@extends('layouts.admin')
@section('title', 'Site Settings')
@section('content')
<div class="admin-header">
    <h1 class="admin-page-title">Site Settings</h1>
    <div class="admin-actions">
        <button onclick="pingSitemap()" class="btn-sm btn-success">🗺 Ping Sitemap</button>
    </div>
</div>

<form method="POST" action="{{ route('admin.settings.update') }}" id="settings-form">
    @csrf @method('PUT')

    {{-- Tabs --}}
    <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:1.5rem;border-bottom:1px solid var(--border);padding-bottom:0.75rem;">
        @foreach(['general'=>'General','seo'=>'SEO','ads'=>'Ads','api'=>'API','maintenance'=>'Maintenance','advanced'=>'Advanced'] as $tab=>$label)
        <button type="button" class="settings-tab {{ $tab === 'general' ? 'active' : '' }}" data-tab="{{ $tab }}" onclick="switchTab('{{ $tab }}')" style="padding:0.375rem 1rem;border-radius:0.375rem;font-size:0.875rem;font-weight:500;border:1px solid var(--border);background:var(--card);color:var(--foreground);cursor:pointer;transition:all 0.15s">
            {{ $label }}
        </button>
        @endforeach
    </div>

    {{-- General --}}
    <div class="settings-panel" id="panel-general">
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Site Identity</h2></div>
            <div class="admin-card-body">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Site Name *</label><input type="text" name="site_name" class="form-input" value="{{ $settings->site_name }}" required></div>
                    <div class="form-group"><label class="form-label">Site Title *</label><input type="text" name="site_title" class="form-input" value="{{ $settings->site_title }}" required></div>
                </div>
                <div class="form-group"><label class="form-label">Site Description</label><textarea name="site_description" class="form-textarea" rows="2">{{ $settings->site_description }}</textarea></div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Logo URL</label><input type="text" name="logo_url" class="form-input" value="{{ $settings->logo_url }}"></div>
                    <div class="form-group"><label class="form-label">Favicon URL</label><input type="text" name="favicon_url" class="form-input" value="{{ $settings->favicon_url }}"></div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">OG Image URL</label><input type="text" name="og_image_url" class="form-input" value="{{ $settings->og_image_url }}"></div>
                    <div class="form-group"><label class="form-label">Canonical URL</label><input type="text" name="canonical_url" class="form-input" value="{{ $settings->canonical_url }}"></div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Admin Slug</label><input type="text" name="admin_slug" class="form-input" value="{{ $settings->admin_slug ?? 'admin' }}" placeholder="admin"><p style="font-size:0.75rem;color:var(--muted);margin-top:0.25rem">Change admin URL prefix (⚠ requires server config)</p></div>
                    <div class="form-group"><label class="form-label">Telegram Link</label><input type="text" name="telegram_link" class="form-input" value="{{ $settings->telegram_link }}" placeholder="https://t.me/…"></div>
                </div>
                <div class="form-group"><label class="form-label">Footer Text</label><input type="text" name="footer_text" class="form-input" value="{{ $settings->footer_text }}" placeholder="© 2024 ePlayHD. All rights reserved."></div>
                <div class="form-group"><label class="form-label">Disclaimer Text</label><textarea name="disclaimer_text" class="form-textarea" rows="3">{{ $settings->disclaimer_text }}</textarea></div>
                <div style="display:flex;gap:1.5rem;flex-wrap:wrap;">
                    <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="show_disclaimer" value="0"><input type="checkbox" name="show_disclaimer" class="form-checkbox" value="1" {{ $settings->show_disclaimer ? 'checked' : '' }}>Show Disclaimer</label>
                    <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="schema_org_enabled" value="0"><input type="checkbox" name="schema_org_enabled" class="form-checkbox" value="1" {{ $settings->schema_org_enabled ? 'checked' : '' }}>Schema.org Markup</label>
                </div>
            </div>
        </div>
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Homepage Settings</h2></div>
            <div class="admin-card-body">
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Channels Limit</label><input type="number" name="homepage_channels_limit" class="form-input" value="{{ $settings->homepage_channels_limit ?? 12 }}" min="0" max="50"></div>
                    <div class="form-group"><label class="form-label">Completed Days</label><input type="number" name="homepage_completed_days" class="form-input" value="{{ $settings->homepage_completed_days ?? 3 }}" min="0" max="30"></div>
                    <div class="form-group"><label class="form-label">Slider Duration (s)</label><input type="number" name="slider_duration_seconds" class="form-input" value="{{ $settings->slider_duration_seconds ?? 5 }}" min="1" max="30"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- SEO --}}
    <div class="settings-panel" id="panel-seo" style="display:none">
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">SEO & Analytics</h2></div>
            <div class="admin-card-body">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Google Analytics ID</label><input type="text" name="google_analytics_id" class="form-input" value="{{ $settings->google_analytics_id }}" placeholder="G-XXXXXXXX or UA-…"></div>
                    <div class="form-group"><label class="form-label">Twitter Handle</label><input type="text" name="twitter_handle" class="form-input" value="{{ $settings->twitter_handle }}" placeholder="@yourhandle"></div>
                </div>
                <div class="form-group"><label class="form-label">Site Keywords</label><input type="text" name="site_keywords" class="form-input" value="{{ $settings->site_keywords }}" placeholder="cricket live, football stream…"></div>
                <div class="form-group"><label class="form-label">Robots.txt</label><textarea name="robots_txt" class="form-textarea" rows="5" style="font-family:monospace">{{ $settings->robots_txt }}</textarea></div>
                <div class="form-group"><label class="form-label">Sitemap Actions</label>
                    <div style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-top:0.25rem;">
                        <button type="button" onclick="pingSitemap()" class="btn-sm btn-success">🗺 Ping Search Engines</button>
                        <a href="{{ url('/sitemap.xml') }}" target="_blank" class="btn-sm btn-edit">View Sitemap</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Ads --}}
    <div class="settings-panel" id="panel-ads" style="display:none">
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Ad Settings</h2></div>
            <div class="admin-card-body">
                <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;margin-bottom:1rem;">
                    <input type="hidden" name="ads_enabled" value="0">
                    <input type="checkbox" name="ads_enabled" id="ads_enabled" class="form-checkbox" value="1" {{ $settings->ads_enabled ? 'checked' : '' }}>
                    <label for="ads_enabled" style="font-size:0.875rem;cursor:pointer">Ads Enabled</label>
                </div>
                <div class="form-group"><label class="form-label">Google AdSense Publisher ID</label><input type="text" name="google_adsense_id" class="form-input" value="{{ $settings->google_adsense_id }}" placeholder="ca-pub-xxxxxxxx"></div>
                <div class="form-group"><label class="form-label">Ads.txt Content</label><textarea name="ads_txt_content" class="form-textarea" rows="5" style="font-family:monospace" placeholder="google.com, pub-xxxxxxxx, DIRECT, f08c47fec0942fa0">{{ $settings->ads_txt_content }}</textarea></div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Header Ad Code</label><textarea name="header_ad_code" class="form-textarea" rows="3" style="font-family:monospace;font-size:0.75rem">{{ $settings->header_ad_code }}</textarea></div>
                    <div class="form-group"><label class="form-label">Footer Ad Code</label><textarea name="footer_ad_code" class="form-textarea" rows="3" style="font-family:monospace;font-size:0.75rem">{{ $settings->footer_ad_code }}</textarea></div>
                    <div class="form-group"><label class="form-label">Sidebar Ad Code</label><textarea name="sidebar_ad_code" class="form-textarea" rows="3" style="font-family:monospace;font-size:0.75rem">{{ $settings->sidebar_ad_code }}</textarea></div>
                    <div class="form-group"><label class="form-label">In-Article Ad Code</label><textarea name="in_article_ad_code" class="form-textarea" rows="3" style="font-family:monospace;font-size:0.75rem">{{ $settings->in_article_ad_code }}</textarea></div>
                </div>
                <div class="form-group"><label class="form-label">Popup Ad Code</label><textarea name="popup_ad_code" class="form-textarea" rows="3" style="font-family:monospace;font-size:0.75rem">{{ $settings->popup_ad_code }}</textarea></div>
            </div>
        </div>
    </div>

    {{-- API --}}
    <div class="settings-panel" id="panel-api" style="display:none">
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Cricket API</h2></div>
            <div class="admin-card-body">
                <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;margin-bottom:1rem;">
                    <input type="hidden" name="api_cricket_enabled" value="0">
                    <input type="checkbox" name="api_cricket_enabled" class="form-checkbox" value="1" {{ $settings->api_cricket_enabled ? 'checked' : '' }}>
                    <label style="font-size:0.875rem;cursor:pointer">Cricket API Enabled</label>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Cricket API Key (CricAPI)</label><input type="text" name="api_cricket_key" class="form-input" value="{{ $settings->api_cricket_key }}"></div>
                    <div class="form-group"><label class="form-label">Cricbuzz API Key</label><input type="text" name="cricket_api_key" class="form-input" value="{{ $settings->cricket_api_key }}"></div>
                </div>
                <div class="form-group"><label class="form-label">Sync Interval (seconds)</label><input type="number" name="api_sync_interval_seconds" class="form-input" value="{{ $settings->api_sync_interval_seconds ?? 60 }}" min="30"></div>
                <div style="display:flex;gap:1.5rem;flex-wrap:wrap;">
                    <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="auto_match_result_enabled" value="0"><input type="checkbox" name="auto_match_result_enabled" class="form-checkbox" value="1" {{ $settings->auto_match_result_enabled ? 'checked' : '' }}>Auto Match Result</label>
                    <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="points_table_auto_sync_enabled" value="0"><input type="checkbox" name="points_table_auto_sync_enabled" class="form-checkbox" value="1" {{ $settings->points_table_auto_sync_enabled ? 'checked' : '' }}>Points Table Auto-Sync</label>
                </div>
            </div>
        </div>
    </div>

    {{-- Maintenance --}}
    <div class="settings-panel" id="panel-maintenance" style="display:none">
        <div class="admin-card" style="{{ $settings->maintenance_mode ? 'border-color:rgba(239,68,68,0.5)' : '' }}">
            <div class="admin-card-header">
                <h2 class="admin-card-title" style="{{ $settings->maintenance_mode ? 'color:#ef4444' : '' }}">
                    {{ $settings->maintenance_mode ? '⚠ ' : '' }}Maintenance Mode
                </h2>
            </div>
            <div class="admin-card-body">
                <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;margin-bottom:1rem;">
                    <input type="hidden" name="maintenance_mode" value="0">
                    <input type="checkbox" name="maintenance_mode" id="maint_mode" class="form-checkbox" value="1" {{ $settings->maintenance_mode ? 'checked' : '' }}>
                    <label for="maint_mode" style="font-size:0.875rem;cursor:pointer;font-weight:600;color:{{ $settings->maintenance_mode ? '#ef4444' : 'inherit' }}">Enable Maintenance Mode</label>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Title</label><input type="text" name="maintenance_title" class="form-input" value="{{ $settings->maintenance_title ?? 'Under Maintenance' }}"></div>
                    <div class="form-group"><label class="form-label">Subtitle</label><input type="text" name="maintenance_subtitle" class="form-input" value="{{ $settings->maintenance_subtitle }}"></div>
                </div>
                <div class="form-group"><label class="form-label">Description</label><textarea name="maintenance_description" class="form-textarea" rows="3">{{ $settings->maintenance_description }}</textarea></div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                    <div class="form-group"><label class="form-label">Estimated Time</label><input type="text" name="maintenance_estimated_time" class="form-input" value="{{ $settings->maintenance_estimated_time }}" placeholder="2 hours, Tomorrow 10am…"></div>
                    <div class="form-group"><label class="form-label">Contact Email</label><input type="email" name="maintenance_contact_email" class="form-input" value="{{ $settings->maintenance_contact_email }}"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- Advanced --}}
    <div class="settings-panel" id="panel-advanced" style="display:none">
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Custom Code Injection</h2></div>
            <div class="admin-card-body">
                <div class="form-group"><label class="form-label">Custom Header Code (injected in &lt;head&gt;)</label><textarea name="custom_header_code" class="form-textarea" rows="5" style="font-family:monospace;font-size:0.75rem" placeholder="&lt;!-- Analytics, fonts, etc --&gt;">{{ $settings->custom_header_code }}</textarea></div>
                <div class="form-group"><label class="form-label">Custom Footer Code (before &lt;/body&gt;)</label><textarea name="custom_footer_code" class="form-textarea" rows="5" style="font-family:monospace;font-size:0.75rem" placeholder="&lt;!-- Scripts, chat widgets, etc --&gt;">{{ $settings->custom_footer_code }}</textarea></div>
            </div>
        </div>
    </div>

    {{-- Save Button --}}
    <div style="position:sticky;bottom:1rem;display:flex;justify-content:flex-end;margin-top:1.5rem;z-index:10;">
        <button type="submit" class="btn-primary-sm" style="padding:0.875rem 2rem;font-size:1rem;box-shadow:var(--shadow-lg);">
            💾 Save All Settings
        </button>
    </div>
</form>

@push('scripts')
<script>
function switchTab(tab) {
    document.querySelectorAll('.settings-panel').forEach(p => p.style.display = 'none');
    document.querySelectorAll('.settings-tab').forEach(t => { t.style.background = 'var(--card)'; t.style.borderColor = 'var(--border)'; t.style.color = 'var(--foreground)'; });
    document.getElementById('panel-' + tab).style.display = 'block';
    const activeBtn = document.querySelector('[data-tab="' + tab + '"]');
    if (activeBtn) { activeBtn.style.background = 'var(--primary)'; activeBtn.style.borderColor = 'var(--primary)'; activeBtn.style.color = 'var(--primary-foreground)'; }
}

// Init first tab
switchTab('general');

function pingSitemap() {
    const btn = event.target;
    btn.textContent = 'Pinging…';
    btn.disabled = true;
    fetch('{{ route("admin.settings.ping-sitemap") }}', {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': window.csrfToken(), 'Accept': 'application/json' }
    }).then(r => r.json()).then(d => {
        btn.textContent = '✓ ' + d.success_count + ' engines pinged!';
        setTimeout(() => { btn.textContent = '🗺 Ping Sitemap'; btn.disabled = false; }, 3000);
    }).catch(() => { btn.textContent = '✗ Failed'; btn.disabled = false; });
}
</script>
@endpush
@endsection
