<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin') — {{ $siteSettings?->site_name ?? 'ePlayHD' }}</title>
    <link rel="stylesheet" href="/css/app.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { background: var(--background); color: var(--foreground); margin: 0; }
        .admin-layout { display: grid; grid-template-columns: 260px 1fr; min-height: 100vh; }
        @media(max-width:1024px) { .admin-layout { grid-template-columns: 1fr; } .admin-sidebar { display: none; } }
        .icon { width: 1rem; height: 1rem; display: inline-block; vertical-align: -2px; }
    </style>
</head>
<body class="dark">
<div class="admin-layout">
    {{-- Sidebar --}}
    <aside class="admin-sidebar">
        <div class="admin-sidebar-logo">
            <a href="{{ url('/') }}" style="display:flex;align-items:center;gap:0.5rem;">
                @if($siteSettings?->logo_url)
                    <img src="{{ $siteSettings->logo_url }}" style="width:2rem;height:2rem;object-fit:contain">
                @else
                    <div class="logo-icon" style="width:2rem;height:2rem;border-radius:0.5rem;background:var(--primary);display:flex;align-items:center;justify-content:center;">
                        <svg style="width:1.25rem;height:1.25rem;color:white;fill:none;stroke:currentColor;stroke-width:2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    </div>
                @endif
                <span class="admin-sidebar-logo-text" style="font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:var(--primary);">{{ $siteSettings?->site_name ?? 'ePlayHD' }}</span>
            </a>
            <p style="font-size:0.7rem;color:var(--muted);margin-top:0.25rem;margin-left:2.5rem;">Admin Panel</p>
        </div>

        <nav style="padding:0.5rem 0.75rem;">
            {{-- Main --}}
            <div style="margin-bottom:1.25rem;">
                <p class="admin-nav-label">Main</p>
                <a href="{{ route('admin.dashboard') }}" class="admin-nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    Dashboard
                </a>
                <a href="{{ route('admin.matches.index') }}" class="admin-nav-link {{ request()->routeIs('admin.matches.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    Matches
                </a>
                <a href="{{ route('admin.tournaments.index') }}" class="admin-nav-link {{ request()->routeIs('admin.tournaments.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 21l4-4 4 4M12 17V3M5 8H2l2-5M19 8h3l-2-5"/></svg>
                    Tournaments
                </a>
                <a href="{{ route('admin.teams.index') }}" class="admin-nav-link {{ request()->routeIs('admin.teams.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    Teams
                </a>
                <a href="{{ route('admin.sports.index') }}" class="admin-nav-link {{ request()->routeIs('admin.sports.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                    Sports
                </a>
            </div>

            {{-- Media --}}
            <div style="margin-bottom:1.25rem;">
                <p class="admin-nav-label">Media</p>
                <a href="{{ route('admin.channels.index') }}" class="admin-nav-link {{ request()->routeIs('admin.channels.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    Channels
                </a>
                <a href="{{ route('admin.saved-servers.index') }}" class="admin-nav-link {{ request()->routeIs('admin.saved-servers.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    Saved Servers
                </a>
                <a href="{{ route('admin.banners.index') }}" class="admin-nav-link {{ request()->routeIs('admin.banners.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                    Banners
                </a>
                <a href="{{ route('admin.sponsor-notices.index') }}" class="admin-nav-link {{ request()->routeIs('admin.sponsor-notices.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 17H20L18.6 15.6A7 7 0 0 0 5 10"/><circle cx="5" cy="10" r="1"/></svg>
                    Sponsor Notices
                </a>
            </div>

            {{-- Content --}}
            <div style="margin-bottom:1.25rem;">
                <p class="admin-nav-label">Content</p>
                <a href="{{ route('admin.pages.index') }}" class="admin-nav-link {{ request()->routeIs('admin.pages.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    Pages
                </a>
                <a href="{{ route('admin.menus.index') }}" class="admin-nav-link {{ request()->routeIs('admin.menus.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                    Menus
                </a>
            </div>

            {{-- System --}}
            <div style="margin-bottom:1.25rem;">
                <p class="admin-nav-label">System</p>
                <a href="{{ route('admin.users.index') }}" class="admin-nav-link {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Users
                </a>
                <a href="{{ route('admin.settings.index') }}" class="admin-nav-link {{ request()->routeIs('admin.settings.*') ? 'active' : '' }}">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                    Settings
                </a>
            </div>

            {{-- Quick Links --}}
            <div style="border-top:1px solid var(--border);padding-top:1rem;margin-top:0.5rem;">
                <a href="{{ url('/') }}" target="_blank" class="admin-nav-link">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                    View Site
                </a>
                <form method="POST" action="{{ route('auth.logout') }}" style="margin:0">
                    @csrf
                    <button type="submit" class="admin-nav-link" style="width:100%;text-align:left;background:none;border:none;cursor:pointer;color:inherit;">
                        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                        Logout
                    </button>
                </form>
            </div>
        </nav>
    </aside>

    {{-- Main Content --}}
    <main class="admin-main">
        {{-- Flash Messages --}}
        @if(session('success'))
        <div class="flash-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
        <div class="flash-error">{{ session('error') }}</div>
        @endif

        @yield('content')
    </main>
</div>

<script src="/js/app.js"></script>
@stack('scripts')
</body>
</html>
