@props(['banners' => []])
@if(count($banners) > 0)
<div class="banner-slider" data-duration="{{ ($siteSettings->slider_duration_seconds ?? 5) * 1000 }}">
    @foreach($banners as $i => $banner)
    <div class="banner-slide {{ $i === 0 ? 'active' : '' }}">
        @if($banner->link_url)
        <a href="{{ $banner->link_url }}" {{ !str_starts_with($banner->link_url, '/') ? 'target="_blank" rel="noopener"' : '' }}>
        @endif
        <img src="{{ $banner->image_url }}" alt="{{ $banner->title }}" loading="{{ $i === 0 ? 'eager' : 'lazy' }}" style="width:100%;height:100%;object-fit:cover">
        @if($banner->title || $banner->subtitle)
        <div class="banner-overlay">
            @if($banner->badge_type && $banner->badge_type !== 'none')
            <span class="live-badge" style="margin-bottom:0.5rem;display:inline-flex;">{{ strtoupper(str_replace('_',' ',$banner->badge_type)) }}</span>
            @endif
            <h3 class="banner-title">{{ $banner->title }}</h3>
            @if($banner->subtitle)<p class="banner-subtitle">{{ $banner->subtitle }}</p>@endif
        </div>
        @endif
        @if($banner->link_url)</a>@endif
    </div>
    @endforeach
    @if(count($banners) > 1)
    <div class="slider-dots">
        @foreach($banners as $i => $banner)
        <button class="slider-dot {{ $i === 0 ? 'active' : '' }}" aria-label="Slide {{ $i+1 }}"></button>
        @endforeach
    </div>
    @endif
</div>
@endif
