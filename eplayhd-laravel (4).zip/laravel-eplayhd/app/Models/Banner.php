<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\MatchModel;

class Banner extends Model {
    protected $table = 'banners';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['title','subtitle','image_url','link_url','banner_type','badge_type','match_id','tournament_id','display_order','is_active'];
    protected $casts = ['is_active'=>'boolean'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function match() { return $this->belongsTo(MatchModel::class,'match_id'); }
    public function tournament() { return $this->belongsTo(Tournament::class,'tournament_id'); }
}
