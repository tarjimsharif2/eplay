<?php

namespace App\Services;

use App\Models\MatchModel;
use App\Models\MatchApiScore;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\SiteSettings;

class CricketApiService
{
    protected ?SiteSettings $settings;

    public function __construct()
    {
        $this->settings = cache()->remember('site_settings', 300, fn() => SiteSettings::first());
    }

    /**
     * Sync match score from CricAPI (cricapi.com)
     */
    public function syncMatchScore(MatchModel $match): array
    {
        if (!$this->settings?->api_cricket_enabled) {
            return ['error' => 'Cricket API is disabled in settings.'];
        }

        $apiKey = $this->settings->api_cricket_key;
        if (!$apiKey) {
            return ['error' => 'CricAPI key not configured.'];
        }

        $matchId = $match->cricapi_match_id;
        if (!$matchId) {
            return ['error' => 'No CricAPI match ID set for this match.'];
        }

        try {
            $response = Http::timeout(10)
                ->get("https://api.cricapi.com/v1/match_info", [
                    'apikey' => $apiKey,
                    'id' => $matchId,
                ]);

            if (!$response->successful()) {
                return ['error' => 'API request failed: ' . $response->status()];
            }

            $data = $response->json();

            if (!isset($data['data'])) {
                return ['error' => 'Unexpected API response format.'];
            }

            $matchData = $data['data'];

            // Update or create API score record
            $apiScore = MatchApiScore::updateOrCreate(
                ['match_id' => $match->id],
                [
                    'api_event_key' => $matchData['id'] ?? $matchId,
                    'home_team' => $matchData['teams'][0] ?? '',
                    'away_team' => $matchData['teams'][1] ?? '',
                    'status' => $matchData['status'] ?? '',
                    'status_info' => $matchData['status'] ?? '',
                    'venue' => $matchData['venue'] ?? '',
                    'event_live' => ($matchData['status'] ?? '') === 'live',
                    'last_synced_at' => now(),
                ]
            );

            // Auto-update match score from API
            if (!$match->manual_status_override) {
                $score_a = $matchData['score'][0]['r'] ?? null;
                $score_b = $matchData['score'][1]['r'] ?? null;

                if ($score_a !== null) {
                    $scoreA = ($matchData['score'][0]['r'] ?? 0) . '/' . ($matchData['score'][0]['w'] ?? 0)
                        . ' (' . ($matchData['score'][0]['o'] ?? 0) . ')';
                    $scoreB = isset($matchData['score'][1])
                        ? ($matchData['score'][1]['r'] ?? 0) . '/' . ($matchData['score'][1]['w'] ?? 0)
                            . ' (' . ($matchData['score'][1]['o'] ?? 0) . ')'
                        : null;

                    $match->update([
                        'score_a' => $scoreA,
                        'score_b' => $scoreB,
                    ]);
                }
            }

            Log::info('Match score synced', ['match_id' => $match->id, 'api_id' => $matchId]);

            return ['success' => true, 'data' => $apiScore->toArray()];

        } catch (\Exception $e) {
            Log::error('CricketApiService error', ['error' => $e->getMessage(), 'match_id' => $match->id]);
            return ['error' => $e->getMessage()];
        }
    }
}
