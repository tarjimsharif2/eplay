<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\SiteSettings;
use App\Models\UserRole;
use Symfony\Component\HttpFoundation\Response;

class MaintenanceModeMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $settings = cache()->remember('site_settings', 300, fn() => SiteSettings::first());

        if (!$settings?->maintenance_mode) {
            return $next($request);
        }

        // Allow auth page
        if ($request->routeIs('login') || $request->routeIs('auth.login') || $request->routeIs('auth.logout')) {
            return $next($request);
        }

        // Allow API routes
        if ($request->is('api/*')) {
            return $next($request);
        }

        // Allow admin routes for logged-in admins
        $adminSlug = $settings->admin_slug ?? 'admin';
        $isAdminRoute = $request->is('admin') || $request->is('admin/*') || $request->is($adminSlug) || $request->is($adminSlug . '/*');

        if ($isAdminRoute || auth()->check()) {
            $user = auth()->user();
            if ($user) {
                $isAdmin = UserRole::where('user_id', $user->id)->where('role', 'admin')->exists();
                if ($isAdmin) {
                    return $next($request);
                }
            }
        }

        // Show maintenance page
        return response()->view('pages.maintenance', ['settings' => $settings], 503);
    }
}
