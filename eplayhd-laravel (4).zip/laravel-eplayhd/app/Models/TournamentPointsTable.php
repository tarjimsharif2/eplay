<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class TournamentPointsTable extends Model {
    protected $table = 'tournament_points_table';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['tournament_id','team_id','played','won','lost','tied','no_result','points','net_run_rate','for_runs','for_overs','against_runs','against_overs','position','qualified','eliminated'];
    protected $casts = ['qualified'=>'boolean','eliminated'=>'boolean','net_run_rate'=>'decimal:3'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function tournament() { return $this->belongsTo(Tournament::class,'tournament_id'); }
    public function team() { return $this->belongsTo(Team::class,'team_id'); }
}
