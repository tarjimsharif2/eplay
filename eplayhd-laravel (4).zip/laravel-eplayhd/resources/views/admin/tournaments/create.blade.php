@extends('layouts.admin')
@section('title','Create Tournament')
@section('content')
<div class="admin-header"><a href="{{ route('admin.tournaments.index') }}" style="font-size:0.875rem;color:var(--muted)">← Back</a><h1 class="admin-page-title">Create Tournament</h1></div>
<form method="POST" action="{{ route('admin.tournaments.store') }}">@csrf
    <div class="admin-card"><div class="admin-card-header"><h2 class="admin-card-title">Details</h2></div>
    <div class="admin-card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" class="form-input" required value="{{ old('name') }}"></div>
            <div class="form-group"><label class="form-label">Season *</label><input type="text" name="season" class="form-input" required value="{{ old('season') }}" placeholder="2024, 2024-25…"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">Sport *</label>
                <select name="sport" class="form-select" required>
                    <option value="">Select Sport</option>
                    @foreach(['cricket','football','basketball','baseball','tennis','rugby','hockey'] as $s)<option value="{{ $s }}" {{ old('sport')===$s?'selected':'' }}>{{ ucfirst($s) }}</option>@endforeach
                </select></div>
            <div class="form-group"><label class="form-label">Slug</label><input type="text" name="slug" class="form-input" value="{{ old('slug') }}" placeholder="auto-generated"></div>
        </div>
        <div class="form-group"><label class="form-label">Logo URL</label><input type="text" name="logo_url" class="form-input" value="{{ old('logo_url') }}"></div>
        <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea">{{ old('description') }}</textarea></div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">SEO Title</label><input type="text" name="seo_title" class="form-input" value="{{ old('seo_title') }}"></div>
            <div class="form-group"><label class="form-label">SEO Description</label><input type="text" name="seo_description" class="form-input" value="{{ old('seo_description') }}"></div>
            <div class="form-group"><label class="form-label">Keywords</label><input type="text" name="seo_keywords" class="form-input" value="{{ old('seo_keywords') }}"></div>
        </div>
        <div style="display:flex;gap:1.5rem;flex-wrap:wrap;">
            @foreach([['is_active','Active'],['show_in_menu','Show in Menu'],['show_in_homepage','Show on Homepage']] as [$f,$l])
            <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="{{ $f }}" value="0"><input type="checkbox" name="{{ $f }}" class="form-checkbox" value="1" checked>{{ $l }}</label>
            @endforeach
        </div>
        <button type="submit" class="btn-primary-sm" style="margin-top:1.25rem;">Create Tournament</button>
    </div></div>
</form>
@endsection
