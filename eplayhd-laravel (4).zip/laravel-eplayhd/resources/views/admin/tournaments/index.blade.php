@extends('layouts.admin')
@section('title','Tournaments')
@section('content')
<div class="admin-header">
    <h1 class="admin-page-title">Tournaments</h1>
    <a href="{{ route('admin.tournaments.create') }}" class="btn-primary-sm">+ New</a>
</div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Name</th><th>Sport</th><th>Season</th><th>Active</th><th>In Menu</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($tournaments as $t)
            <tr>
                <td style="font-weight:600;font-size:0.875rem">{{ $t->name }}</td>
                <td style="font-size:0.875rem;color:var(--muted)">{{ $t->sport }}</td>
                <td style="font-size:0.875rem;color:var(--muted)">{{ $t->season }}</td>
                <td><span class="badge {{ $t->is_active ? 'badge-completed-sm' : 'badge-live-sm' }}">{{ $t->is_active ? 'Yes' : 'No' }}</span></td>
                <td><span class="badge {{ $t->show_in_menu ? 'badge-completed-sm' : '' }}" style="{{ !$t->show_in_menu ? 'color:var(--muted)' : '' }}">{{ $t->show_in_menu ? 'Yes' : 'No' }}</span></td>
                <td>
                    <a href="{{ route('admin.tournaments.edit', $t->id) }}" class="btn-sm btn-edit">Edit</a>
                    <a href="{{ route('admin.tournaments.points-table', $t->id) }}" class="btn-sm btn-success">Table</a>
                    <form method="POST" action="{{ route('admin.tournaments.destroy', $t->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete tournament?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem;">No tournaments.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem;">{{ $tournaments->links() }}</div>
</div>
@endsection
