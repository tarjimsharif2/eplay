@extends('layouts.admin')
@section('title','Edit Channel')
@section('content')
<div class="admin-header"><div><a href="{{ route('admin.channels.index') }}" style="font-size:0.875rem;color:var(--muted)">← Back</a><h1 class="admin-page-title">{{ $channel->name }}</h1></div><button onclick="document.getElementById('add-srv-modal').style.display='flex'" class="btn-primary-sm">+ Add Server</button></div>
<div style="display:grid;grid-template-columns:1fr 320px;gap:1.5rem;">
    <div>
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Streaming Servers ({{ $channel->streamingServers->count() }})</h2></div>
            <table class="admin-table">
                <thead><tr><th>Name</th><th>URL</th><th>Type</th><th>Order</th><th>Active</th><th></th></tr></thead>
                <tbody>
                    @forelse($channel->streamingServers->sortBy('display_order') as $srv)
                    <tr>
                        <td style="font-weight:500;font-size:0.875rem">{{ $srv->server_name }}</td>
                        <td style="font-size:0.75rem;color:var(--muted);max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $srv->server_url }}</td>
                        <td style="font-size:0.8rem">{{ $srv->server_type }}</td>
                        <td>{{ $srv->display_order }}</td>
                        <td><span class="badge {{ $srv->is_active ? 'badge-completed-sm' : 'badge-live-sm' }}">{{ $srv->is_active ? 'On' : 'Off' }}</span></td>
                        <td><form method="POST" action="{{ route('admin.channels.servers.destroy', [$channel->id, $srv->id]) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete server?">×</button></form></td>
                    </tr>
                    @empty
                    <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:1.5rem">No servers.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    <div>
        <div class="admin-card" style="position:sticky;top:1.5rem;">
            <div class="admin-card-header"><h2 class="admin-card-title">Channel Info</h2></div>
            <div class="admin-card-body">
                <form method="POST" action="{{ route('admin.channels.update', $channel->id) }}">@csrf @method('PUT')
                    <div class="form-group"><label class="form-label">Name</label><input type="text" name="name" class="form-input" value="{{ $channel->name }}" required></div>
                    <div class="form-group"><label class="form-label">Slug</label><input type="text" name="slug" class="form-input" value="{{ $channel->slug }}"></div>
                    <div class="form-group"><label class="form-label">Logo URL</label><input type="text" name="logo_url" class="form-input" value="{{ $channel->logo_url }}"></div>
                    <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="2">{{ $channel->description }}</textarea></div>
                    <div class="form-group"><label class="form-label">Display Order</label><input type="number" name="display_order" class="form-input" value="{{ $channel->display_order }}"></div>
                    <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer;margin-bottom:1rem"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" class="form-checkbox" value="1" {{ $channel->is_active ? 'checked' : '' }}>Active</label>
                    <button type="submit" class="btn-primary-sm" style="width:100%;justify-content:center">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div id="add-srv-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:550px;max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700">Add Channel Server</h3><button onclick="document.getElementById('add-srv-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.channels.servers.store', $channel->id) }}">@csrf
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Name *</label><input type="text" name="server_name" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Order</label><input type="number" name="display_order" class="form-input" value="1"></div>
            </div>
            <div class="form-group"><label class="form-label">Stream URL *</label><input type="text" name="server_url" class="form-input" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Type</label><select name="server_type" class="form-select"><option value="hls">HLS</option><option value="iframe">iFrame</option><option value="youtube">YouTube</option><option value="mp4">MP4</option></select></div>
                <div class="form-group"><label class="form-label">Player</label><select name="player_type" class="form-select"><option value="auto">Auto</option><option value="iframe">iFrame</option><option value="hlsjs">HLS.js</option></select></div>
            </div>
            <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer;margin-bottom:1rem"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" class="form-checkbox" value="1" checked>Active</label>
            <div style="display:flex;gap:0.75rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add</button><button type="button" onclick="document.getElementById('add-srv-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@endsection
