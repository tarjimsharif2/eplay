@extends('layouts.admin')
@section('title', 'Edit Match')
@section('content')
<div class="admin-header">
    <div>
        <a href="{{ route('admin.matches.show', $match->id) }}" style="font-size:0.875rem;color:var(--muted);">← Back</a>
        <h1 class="admin-page-title">Edit: {{ $match->teamA?->short_name }} vs {{ $match->teamB?->short_name }}</h1>
    </div>
</div>
<form method="POST" action="{{ route('admin.matches.update', $match->id) }}">
    @csrf @method('PUT')
    <div style="display:grid;grid-template-columns:1fr 300px;gap:1.5rem;">
        <div>
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">Teams & Basic Info</h2></div>
                <div class="admin-card-body">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Team A</label>
                            <select name="team_a_id" class="form-select" required>
                                @foreach($teams as $t)<option value="{{ $t->id }}" {{ $match->team_a_id === $t->id ? 'selected' : '' }}>{{ $t->name }}</option>@endforeach
                            </select></div>
                        <div class="form-group"><label class="form-label">Team B</label>
                            <select name="team_b_id" class="form-select" required>
                                @foreach($teams as $t)<option value="{{ $t->id }}" {{ $match->team_b_id === $t->id ? 'selected' : '' }}>{{ $t->name }}</option>@endforeach
                            </select></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Sport</label>
                            <select name="sport_id" class="form-select">
                                <option value="">No Sport</option>
                                @foreach($sports as $s)<option value="{{ $s->id }}" {{ $match->sport_id === $s->id ? 'selected' : '' }}>{{ $s->name }}</option>@endforeach
                            </select></div>
                        <div class="form-group"><label class="form-label">Tournament</label>
                            <select name="tournament_id" class="form-select">
                                <option value="">No Tournament</option>
                                @foreach($tournaments as $t)<option value="{{ $t->id }}" {{ $match->tournament_id === $t->id ? 'selected' : '' }}>{{ $t->name }}</option>@endforeach
                            </select></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Date</label><input type="date" name="match_date" class="form-input" value="{{ $match->match_date }}"></div>
                        <div class="form-group"><label class="form-label">Time</label><input type="time" name="match_time" class="form-input" value="{{ $match->match_time }}"></div>
                        <div class="form-group"><label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                @foreach(['upcoming','live','completed','abandoned','postponed'] as $s)<option value="{{ $s }}" {{ $match->status === $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>@endforeach
                            </select></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Match Number</label><input type="text" name="match_number" class="form-input" value="{{ $match->match_number }}"></div>
                        <div class="form-group"><label class="form-label">Format</label><input type="text" name="match_format" class="form-input" value="{{ $match->match_format }}" placeholder="T20, ODI, Test"></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Venue</label><input type="text" name="venue" class="form-input" value="{{ $match->venue }}"></div>
                        <div class="form-group"><label class="form-label">Match Label</label><input type="text" name="match_label" class="form-input" value="{{ $match->match_label }}"></div>
                    </div>
                    <div class="form-group"><label class="form-label">Slug</label><input type="text" name="slug" class="form-input" value="{{ $match->slug }}"></div>
                </div>
            </div>

            {{-- Score & Result --}}
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">Score & Result</h2></div>
                <div class="admin-card-body">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">{{ $match->teamA?->short_name }} Score</label><input type="text" name="score_a" class="form-input" value="{{ $match->score_a }}"></div>
                        <div class="form-group"><label class="form-label">{{ $match->teamB?->short_name }} Score</label><input type="text" name="score_b" class="form-input" value="{{ $match->score_b }}"></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Result</label>
                            <select name="match_result" class="form-select">
                                <option value="">No Result</option>
                                @foreach(['team_a_won','team_b_won','tied','draw','no_result'] as $r)<option value="{{ $r }}" {{ $match->match_result === $r ? 'selected' : '' }}>{{ str_replace('_',' ',ucfirst($r)) }}</option>@endforeach
                            </select></div>
                        <div class="form-group"><label class="form-label">Result Margin</label><input type="text" name="result_margin" class="form-input" value="{{ $match->result_margin }}" placeholder="Won by 6 wickets"></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Toss Winner</label>
                            <select name="toss_winner_id" class="form-select">
                                <option value="">–</option>
                                @foreach($teams as $t)<option value="{{ $t->id }}" {{ $match->toss_winner_id === $t->id ? 'selected' : '' }}>{{ $t->name }}</option>@endforeach
                            </select></div>
                        <div class="form-group"><label class="form-label">Toss Decision</label>
                            <select name="toss_decision" class="form-select">
                                <option value="">–</option>
                                <option value="bat" {{ $match->toss_decision === 'bat' ? 'selected' : '' }}>Bat</option>
                                <option value="bowl" {{ $match->toss_decision === 'bowl' ? 'selected' : '' }}>Bowl</option>
                            </select></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">Football Minute</label><input type="number" name="match_minute" class="form-input" value="{{ $match->match_minute }}" min="0" max="120"></div>
                        <div class="form-group"><label class="form-label">Test Day</label><input type="number" name="test_day" class="form-input" value="{{ $match->test_day }}" min="1" max="5"></div>
                    </div>
                    <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;">
                        <input type="hidden" name="is_stumps" value="0">
                        <input type="checkbox" name="is_stumps" id="is_stumps" class="form-checkbox" value="1" {{ $match->is_stumps ? 'checked' : '' }}>
                        <label for="is_stumps" style="font-size:0.875rem;cursor:pointer">Stumps Called (Day/Night)</label>
                    </div>
                </div>
            </div>

            {{-- API Settings --}}
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">API Score Sync</h2></div>
                <div class="admin-card-body">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group"><label class="form-label">CricAPI Match ID</label><input type="text" name="cricapi_match_id" class="form-input" value="{{ $match->cricapi_match_id }}"></div>
                        <div class="form-group"><label class="form-label">Cricbuzz Match ID</label><input type="text" name="cricbuzz_match_id" class="form-input" value="{{ $match->cricbuzz_match_id }}"></div>
                    </div>
                    <div style="display:flex;gap:1.5rem;flex-wrap:wrap;">
                        @foreach([['api_score_enabled','API Score Enabled'],['auto_sync_enabled','Auto Sync'],['manual_status_override','Manual Status Override']] as [$field,$label])
                        <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;margin:0;">
                            <input type="hidden" name="{{ $field }}" value="0">
                            <input type="checkbox" name="{{ $field }}" id="{{ $field }}" class="form-checkbox" value="1" {{ $match->$field ? 'checked' : '' }}>
                            <label for="{{ $field }}" style="font-size:0.875rem;cursor:pointer">{{ $label }}</label>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>

            {{-- SEO --}}
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">SEO</h2></div>
                <div class="admin-card-body">
                    <div class="form-group"><label class="form-label">SEO Title</label><input type="text" name="seo_title" class="form-input" value="{{ $match->seo_title }}"></div>
                    <div class="form-group"><label class="form-label">SEO Description</label><textarea name="seo_description" class="form-textarea" rows="2">{{ $match->seo_description }}</textarea></div>
                    <div class="form-group"><label class="form-label">Keywords</label><input type="text" name="seo_keywords" class="form-input" value="{{ $match->seo_keywords }}"></div>
                </div>
            </div>
        </div>

        {{-- Sidebar --}}
        <div>
            <div class="admin-card" style="position:sticky;top:1.5rem;">
                <div class="admin-card-header"><h2 class="admin-card-title">Settings</h2></div>
                <div class="admin-card-body" style="display:flex;flex-direction:column;gap:0.625rem;">
                    @foreach([['is_active','Active (visible)'],['is_priority','⭐ Priority'],['show_playing_xi','Show Playing XI']] as [$field,$label])
                    <div style="display:flex;align-items:center;gap:0.5rem;">
                        <input type="hidden" name="{{ $field }}" value="0">
                        <input type="checkbox" name="{{ $field }}" id="{{ $field }}_edit" class="form-checkbox" value="1" {{ $match->$field ? 'checked' : '' }}>
                        <label for="{{ $field }}_edit" style="font-size:0.875rem;cursor:pointer">{{ $label }}</label>
                    </div>
                    @endforeach
                    <button type="submit" class="btn-primary-sm" style="width:100%;justify-content:center;margin-top:0.75rem;padding:0.75rem;">Save Changes</button>
                    <a href="{{ route('admin.matches.show', $match->id) }}" class="btn-sm btn-edit" style="text-align:center;display:block;margin-top:0.25rem;">Cancel</a>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection
