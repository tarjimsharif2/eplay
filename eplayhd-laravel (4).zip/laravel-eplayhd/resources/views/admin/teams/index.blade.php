@extends('layouts.admin')
@section('title','Teams')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Teams ({{ $teams->total() }})</h1><button onclick="document.getElementById('add-team-modal').style.display='flex'" class="btn-primary-sm">+ New Team</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Logo</th><th>Name</th><th>Short</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($teams as $team)
            <tr>
                <td>@if($team->logo_url)<img src="{{ $team->logo_url }}" style="width:2rem;height:2rem;object-fit:contain;border-radius:0.25rem;{{ $team->logo_background_color ? 'background:'.$team->logo_background_color : '' }}">@else<div style="width:2rem;height:2rem;background:var(--accent);border-radius:0.25rem;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;color:var(--primary)">{{ strtoupper(substr($team->short_name,0,2)) }}</div>@endif</td>
                <td style="font-weight:500;font-size:0.875rem">{{ $team->name }}</td>
                <td style="font-family:monospace;font-size:0.875rem;color:var(--muted)">{{ $team->short_name }}</td>
                <td>
                    <button onclick="editTeam('{{ $team->id }}','{{ addslashes($team->name) }}','{{ addslashes($team->short_name) }}','{{ $team->logo_url }}','{{ $team->logo_background_color }}')" class="btn-sm btn-edit">Edit</button>
                    <form method="POST" action="{{ route('admin.teams.destroy', $team->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete team?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" style="text-align:center;color:var(--muted);padding:2rem">No teams.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem">{{ $teams->links() }}</div>
</div>
{{-- Add Modal --}}
<div id="add-team-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:480px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700" id="team-modal-title">Add Team</h3><button onclick="closeTeamModal()" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form id="team-form" method="POST" action="{{ route('admin.teams.store') }}">@csrf
            <input type="hidden" id="team-method" name="_method" value="">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Team Name *</label><input type="text" name="name" id="team-name" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Short Name *</label><input type="text" name="short_name" id="team-short" class="form-input" required maxlength="10" placeholder="IND"></div>
            </div>
            <div class="form-group"><label class="form-label">Logo URL</label><input type="text" name="logo_url" id="team-logo" class="form-input" placeholder="https://…"></div>
            <div class="form-group"><label class="form-label">Logo Background Color</label><input type="text" name="logo_background_color" id="team-bg" class="form-input" placeholder="#ffffff"></div>
            <div style="display:flex;gap:0.75rem;margin-top:1rem;">
                <button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Save Team</button>
                <button type="button" onclick="closeTeamModal()" class="btn-sm btn-edit">Cancel</button>
            </div>
        </form>
    </div>
</div>
@push('scripts')
<script>
function editTeam(id, name, short, logo, bg) {
    document.getElementById('team-modal-title').textContent = 'Edit Team';
    document.getElementById('team-form').action = '/admin/teams/' + id;
    document.getElementById('team-method').value = 'PUT';
    document.getElementById('team-name').value = name;
    document.getElementById('team-short').value = short;
    document.getElementById('team-logo').value = logo || '';
    document.getElementById('team-bg').value = bg || '';
    document.getElementById('add-team-modal').style.display = 'flex';
}
function closeTeamModal() {
    document.getElementById('team-form').action = '{{ route("admin.teams.store") }}';
    document.getElementById('team-method').value = '';
    document.getElementById('team-modal-title').textContent = 'Add Team';
    document.getElementById('add-team-modal').style.display = 'none';
}
</script>
@endpush
@endsection
