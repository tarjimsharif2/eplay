<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class DynamicPage extends Model {
    protected $table = 'dynamic_pages';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['title','slug','content','content_type','seo_title','seo_description','seo_keywords','og_image_url','is_active','show_in_header','show_in_footer','display_order'];
    protected $casts = ['is_active'=>'boolean','show_in_header'=>'boolean','show_in_footer'=>'boolean'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
}
