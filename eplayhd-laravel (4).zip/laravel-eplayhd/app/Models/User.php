<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
class User extends Authenticatable {
    use Notifiable;
    protected $table = 'users';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['name','email','password'];
    protected $hidden = ['password','remember_token'];
    protected $casts = ['email_verified_at'=>'datetime','password'=>'hashed'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function profile() { return $this->hasOne(Profile::class,'user_id'); }
    public function roles() { return $this->hasMany(UserRole::class,'user_id'); }
    public function hasRole(string $role): bool { return $this->roles()->where('role',$role)->exists(); }
    public function isAdmin(): bool { return $this->hasRole('admin') || ($this->profile?->is_admin ?? false); }
}
