<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\MatchInning;
use App\Models\MatchModel;
use Illuminate\Http\Request;

class InningsAdminController extends Controller
{
    public function index(string $matchId) {
        $match = bMatchModel::with(['teamA','teamB','innings.battingTeam'])->findOrFail($matchId);
        return view('admin.matches.innings', compact('match'));
    }
    public function store(Request $request, string $matchId) {
        bMatchModel::findOrFail($matchId);
        $v = $request->validate(['innings_number'=>'required|integer|in:1,2,3,4','batting_team_id'=>'required|exists:teams,id','runs'=>'nullable|integer','wickets'=>'nullable|integer|max:10','overs'=>'nullable|numeric','extras'=>'nullable|integer','declared'=>'boolean','is_current'=>'boolean']);
        $v['match_id'] = $matchId;
        MatchInning::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Innings added.');
    }
    public function update(Request $request, string $matchId, string $id) {
        MatchInning::where('match_id',$matchId)->findOrFail($id)->update($request->validate(['runs'=>'nullable|integer','wickets'=>'nullable|integer|max:10','overs'=>'nullable|numeric','extras'=>'nullable|integer','declared'=>'boolean','is_current'=>'boolean']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Innings updated.');
    }
    public function destroy(string $matchId, string $id) { MatchInning::where('match_id',$matchId)->findOrFail($id)->delete(); return back()->with('success','Innings deleted.'); }
}
