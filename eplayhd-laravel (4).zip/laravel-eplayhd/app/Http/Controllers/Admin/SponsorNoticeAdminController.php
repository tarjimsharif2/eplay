<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\SponsorNotice;
use App\Models\MatchModel;
use Illuminate\Http\Request;

class SponsorNoticeAdminController extends Controller
{
    public function index() {
        $notices = SponsorNotice::with('match')->orderBy('display_order')->paginate(20);
        $matches = bMatchModel::with(['teamA','teamB'])->where('is_active',true)->orderBy('updated_at','desc')->take(50)->get();
        return view('admin.sponsor-notices.index', compact('notices','matches'));
    }
    public function store(Request $request, string $matchId = null) {
        $v = $request->validate(['title'=>'required|string|max:500','content'=>'required|string','position'=>'nullable|string|max:100','display_type'=>'nullable|in:banner,popup,inline','background_color'=>'nullable|string|max:50','text_color'=>'nullable|string|max:50','is_active'=>'boolean','is_global'=>'boolean','match_id'=>'nullable|exists:matches,id','display_order'=>'nullable|integer']);
        if ($matchId) $v['match_id'] = $matchId;
        SponsorNotice::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Sponsor notice created.');
    }
    public function update(Request $request, string $id) {
        SponsorNotice::findOrFail($id)->update($request->validate(['title'=>'required|string|max:500','content'=>'required|string','position'=>'nullable|string|max:100','display_type'=>'nullable|in:banner,popup,inline','background_color'=>'nullable|string|max:50','text_color'=>'nullable|string|max:50','is_active'=>'boolean','is_global'=>'boolean','match_id'=>'nullable|exists:matches,id','display_order'=>'nullable|integer']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Sponsor notice updated.');
    }
    public function destroy(string $id) { SponsorNotice::findOrFail($id)->delete(); return back()->with('success','Notice deleted.'); }
}
