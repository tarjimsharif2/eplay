<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\MatchModel;
class MatchApiScore extends Model {
    protected $table = 'match_api_scores';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['match_id','api_event_key','home_team','away_team','home_score','away_score','home_overs','away_overs','status','status_info','toss','venue','event_live','batsmen','bowlers','extras','scorecard','last_synced_at'];
    protected $casts = ['batsmen'=>'array','bowlers'=>'array','extras'=>'array','scorecard'=>'array'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function match() { return $this->belongsTo(MatchModel::class,'match_id'); }
}
