<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\DynamicPage;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class DynamicPageAdminController extends Controller
{
    public function index() { return view('admin.pages.index', ['pages' => DynamicPage::orderBy('display_order')->paginate(20)]); }
    public function create() { return view('admin.pages.create'); }
    public function store(Request $request) {
        $v = $request->validate(['title'=>'required|string|max:500','slug'=>'required|string|unique:dynamic_pages,slug','content'=>'nullable|string','content_type'=>'nullable|in:html,markdown,text','seo_title'=>'nullable|string','seo_description'=>'nullable|string','seo_keywords'=>'nullable|string','og_image_url'=>'nullable|string','is_active'=>'boolean','show_in_header'=>'boolean','show_in_footer'=>'boolean','display_order'=>'nullable|integer']);
        DynamicPage::create($v);
        cache()->forget('footer_pages');
        return redirect()->route('admin.pages.index')->with('success','Page created.');
    }
    public function edit(string $id) { return view('admin.pages.edit', ['page' => DynamicPage::findOrFail($id)]); }
    public function update(Request $request, string $id) {
        $page = DynamicPage::findOrFail($id);
        $page->update($request->validate(['title'=>'required|string|max:500','slug'=>'required|string|unique:dynamic_pages,slug,'.$id,'content'=>'nullable|string','content_type'=>'nullable|in:html,markdown,text','seo_title'=>'nullable|string','seo_description'=>'nullable|string','seo_keywords'=>'nullable|string','og_image_url'=>'nullable|string','is_active'=>'boolean','show_in_header'=>'boolean','show_in_footer'=>'boolean','display_order'=>'nullable|integer']));
        cache()->forget('footer_pages');
        return redirect()->route('admin.pages.index')->with('success','Page updated.');
    }
    public function destroy(string $id) { DynamicPage::findOrFail($id)->delete(); cache()->forget('footer_pages'); return redirect()->route('admin.pages.index')->with('success','Page deleted.'); }
}
