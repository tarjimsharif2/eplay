<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Team;
use Illuminate\Http\Request;

class TeamAdminController extends Controller
{
    public function index() {
        $teams = Team::orderBy('name')->paginate(30);
        return view('admin.teams.index', compact('teams'));
    }
    public function store(Request $request) {
        $v = $request->validate(['name'=>'required|string|max:255','short_name'=>'required|string|max:20','logo_url'=>'nullable|string','logo_background_color'=>'nullable|string|max:50']);
        Team::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Team created.');
    }
    public function update(Request $request, string $id) {
        $team = Team::findOrFail($id);
        $v = $request->validate(['name'=>'required|string|max:255','short_name'=>'required|string|max:20','logo_url'=>'nullable|string','logo_background_color'=>'nullable|string|max:50']);
        $team->update($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Team updated.');
    }
    public function destroy(string $id) {
        Team::findOrFail($id)->delete();
        return back()->with('success','Team deleted.');
    }
    public function search(Request $request) {
        $teams = Team::where('name','like','%'.$request->q.'%')->orWhere('short_name','like','%'.$request->q.'%')->take(20)->get(['id','name','short_name','logo_url']);
        return response()->json(['teams'=>$teams]);
    }
}
