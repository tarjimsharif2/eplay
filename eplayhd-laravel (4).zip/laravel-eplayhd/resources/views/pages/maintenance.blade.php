<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $settings?->maintenance_title ?? 'Under Maintenance' }}</title>
    <link rel="stylesheet" href="/css/app.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@700;800&family=Space+Grotesk:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
<div class="maintenance-page">
    <div class="maintenance-card">
        <svg class="maintenance-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
        <h1 class="maintenance-title">{{ $settings?->maintenance_title ?? 'Under Maintenance' }}</h1>
        @if($settings?->maintenance_subtitle)
        <p class="maintenance-subtitle">{{ $settings->maintenance_subtitle }}</p>
        @endif
        @if($settings?->maintenance_description)
        <p class="maintenance-desc">{{ $settings->maintenance_description }}</p>
        @endif
        @if($settings?->maintenance_estimated_time)
        <div style="background:var(--accent);border:1px solid var(--border);border-radius:0.75rem;padding:1rem;margin-bottom:1.5rem;">
            <p style="font-size:0.875rem;color:var(--muted);">Expected back:</p>
            <p style="font-weight:600;color:var(--foreground);">{{ $settings->maintenance_estimated_time }}</p>
        </div>
        @endif
        @if($settings?->maintenance_contact_email)
        <p style="font-size:0.875rem;color:var(--muted);">Questions? Contact us at <a href="mailto:{{ $settings->maintenance_contact_email }}" style="color:var(--primary);">{{ $settings->maintenance_contact_email }}</a></p>
        @endif
        @if($settings?->telegram_link && $settings->telegram_link !== '#')
        <a href="{{ $settings->telegram_link }}" target="_blank" rel="noopener" class="telegram-btn" style="margin-top:1.5rem;display:inline-flex;">
            Join Telegram for Updates
        </a>
        @endif
        <div style="margin-top:2rem;">
            <a href="{{ route('login') }}" style="font-size:0.8rem;color:var(--muted);">Admin Login →</a>
        </div>
    </div>
</div>
</body>
</html>
