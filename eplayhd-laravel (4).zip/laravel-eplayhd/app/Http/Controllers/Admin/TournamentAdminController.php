<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Tournament;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class TournamentAdminController extends Controller
{
    public function index() {
        $tournaments = Tournament::orderBy('created_at','desc')->paginate(20);
        return view('admin.tournaments.index', compact('tournaments'));
    }
    public function create() {
        return view('admin.tournaments.create');
    }
    public function store(Request $request) {
        $v = $request->validate(['name'=>'required|string|max:500','sport'=>'required|string','season'=>'required|string','logo_url'=>'nullable|string','slug'=>'nullable|string|unique:tournaments,slug','is_active'=>'boolean','show_in_menu'=>'boolean','show_in_homepage'=>'boolean','seo_title'=>'nullable|string','seo_description'=>'nullable|string','seo_keywords'=>'nullable|string','description'=>'nullable|string','series_id'=>'nullable|string']);
        if (empty($v['slug'])) $v['slug'] = Str::slug($v['name'].'-'.$v['season']);
        Tournament::create($v);
        return redirect()->route('admin.tournaments.index')->with('success','Tournament created.');
    }
    public function edit(string $id) {
        $tournament = Tournament::findOrFail($id);
        return view('admin.tournaments.edit', compact('tournament'));
    }
    public function update(Request $request, string $id) {
        $t = Tournament::findOrFail($id);
        $v = $request->validate(['name'=>'required|string|max:500','sport'=>'required|string','season'=>'required|string','logo_url'=>'nullable|string','logo_background_color'=>'nullable|string|max:50','slug'=>'nullable|string|unique:tournaments,slug,'.$id,'is_active'=>'boolean','show_in_menu'=>'boolean','show_in_homepage'=>'boolean','is_completed'=>'boolean','seo_title'=>'nullable|string','seo_description'=>'nullable|string','seo_keywords'=>'nullable|string','description'=>'nullable|string','series_id'=>'nullable|string','show_participating_teams'=>'boolean','participating_teams_position'=>'nullable|string']);
        $t->update($v);
        cache()->forget('menu_tournaments');
        return redirect()->route('admin.tournaments.index')->with('success','Tournament updated.');
    }
    public function destroy(string $id) {
        Tournament::findOrFail($id)->delete();
        return redirect()->route('admin.tournaments.index')->with('success','Tournament deleted.');
    }
    public function search(Request $request) {
        $items = Tournament::where('name','like','%'.$request->q.'%')->take(10)->get(['id','name','season','sport']);
        return response()->json(['tournaments'=>$items]);
    }
}
