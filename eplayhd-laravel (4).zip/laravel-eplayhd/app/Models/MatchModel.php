<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class MatchModel extends Model {
    protected $table = 'matches';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $guarded = [];
    protected $casts = [
        'is_active'=>'boolean','is_priority'=>'boolean','is_stumps'=>'boolean',
        'show_playing_xi'=>'boolean','api_score_enabled'=>'boolean','auto_sync_enabled'=>'boolean',
        'manual_status_override'=>'boolean','match_start_time'=>'datetime','match_end_time'=>'datetime',
        'goals_team_a'=>'array','goals_team_b'=>'array',
    ];
    protected static function boot() {
        parent::boot();
        static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid());
    }
    public function teamA() { return $this->belongsTo(Team::class,'team_a_id'); }
    public function teamB() { return $this->belongsTo(Team::class,'team_b_id'); }
    public function tournament() { return $this->belongsTo(Tournament::class,'tournament_id'); }
    public function sport() { return $this->belongsTo(Sport::class,'sport_id'); }
    public function tossWinner() { return $this->belongsTo(Team::class,'toss_winner_id'); }
    public function streamingServers() { return $this->hasMany(StreamingServer::class,'match_id')->where('is_active',true)->orderBy('display_order'); }
    public function innings() { return $this->hasMany(MatchInning::class,'match_id')->orderBy('innings_number'); }
    public function playingXI() { return $this->hasMany(MatchPlayingXI::class,'match_id'); }
    public function substitutions() { return $this->hasMany(MatchSubstitution::class,'match_id'); }
    public function apiScore() { return $this->hasOne(MatchApiScore::class,'match_id'); }
    public function sponsorNotices() { return $this->hasMany(SponsorNotice::class,'match_id')->where('is_active',true)->orderBy('display_order'); }
    public function isLive(): bool { return $this->status === 'live'; }
}
