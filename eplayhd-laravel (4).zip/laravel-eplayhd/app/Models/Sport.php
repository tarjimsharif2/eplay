<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\MatchModel;
class Sport extends Model {
    protected $table = 'sports';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['name', 'icon_url', 'display_order'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function matches() { return $this->hasMany(MatchModel::class, 'sport_id'); }
}
