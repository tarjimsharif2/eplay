@extends('layouts.admin')
@section('title', 'Create Match')
@section('content')
<div class="admin-header">
    <div>
        <a href="{{ route('admin.matches.index') }}" style="font-size:0.875rem;color:var(--muted);display:flex;align-items:center;gap:0.375rem;margin-bottom:0.25rem;">
            ← Back to Matches
        </a>
        <h1 class="admin-page-title">Create New Match</h1>
    </div>
</div>

<form method="POST" action="{{ route('admin.matches.store') }}">
    @csrf
    <div style="display:grid;grid-template-columns:1fr 340px;gap:1.5rem;">
        <div>
            {{-- Teams --}}
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">Teams</h2></div>
                <div class="admin-card-body">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label class="form-label">Team A *</label>
                            <select name="team_a_id" class="form-select" required>
                                <option value="">Select Team A</option>
                                @foreach($teams as $team)
                                <option value="{{ $team->id }}" {{ old('team_a_id') === $team->id ? 'selected' : '' }}>{{ $team->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Team B *</label>
                            <select name="team_b_id" class="form-select" required>
                                <option value="">Select Team B</option>
                                @foreach($teams as $team)
                                <option value="{{ $team->id }}" {{ old('team_b_id') === $team->id ? 'selected' : '' }}>{{ $team->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label class="form-label">Sport</label>
                            <select name="sport_id" class="form-select">
                                <option value="">Select Sport</option>
                                @foreach($sports as $sport)
                                <option value="{{ $sport->id }}" {{ old('sport_id') === $sport->id ? 'selected' : '' }}>{{ $sport->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Tournament</label>
                            <select name="tournament_id" class="form-select">
                                <option value="">No Tournament</option>
                                @foreach($tournaments as $t)
                                <option value="{{ $t->id }}" {{ old('tournament_id') === $t->id ? 'selected' : '' }}>{{ $t->name }} ({{ $t->season }})</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Match Details --}}
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">Match Details</h2></div>
                <div class="admin-card-body">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label class="form-label">Date *</label>
                            <input type="date" name="match_date" class="form-input" value="{{ old('match_date', now()->format('Y-m-d')) }}" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Time (local) *</label>
                            <input type="time" name="match_time" class="form-input" value="{{ old('match_time', '14:00') }}" required>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label class="form-label">Status *</label>
                            <select name="status" class="form-select" required>
                                @foreach(['upcoming','live','completed','abandoned','postponed'] as $s)
                                <option value="{{ $s }}" {{ old('status','upcoming') === $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Match Number</label>
                            <input type="text" name="match_number" class="form-input" value="{{ old('match_number') }}" placeholder="Match 1, Final…">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Format</label>
                            <input type="text" name="match_format" class="form-input" value="{{ old('match_format') }}" placeholder="T20, ODI, Test…">
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label class="form-label">Venue</label>
                            <input type="text" name="venue" class="form-input" value="{{ old('venue') }}" placeholder="Stadium name, City">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Match Label</label>
                            <input type="text" name="match_label" class="form-input" value="{{ old('match_label') }}" placeholder="Super Over, DLS…">
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label class="form-label">Page Type</label>
                            <select name="page_type" class="form-select" id="page_type_select">
                                <option value="page" {{ old('page_type','page') === 'page' ? 'selected' : '' }}>Full Page (with streams)</option>
                                <option value="link" {{ old('page_type') === 'link' ? 'selected' : '' }}>External Link</option>
                            </select>
                        </div>
                        <div class="form-group" id="match_link_group" style="{{ old('page_type') !== 'link' ? 'display:none' : '' }}">
                            <label class="form-label">External Link</label>
                            <input type="url" name="match_link" class="form-input" value="{{ old('match_link') }}" placeholder="https://…">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Custom Slug</label>
                        <input type="text" name="slug" class="form-input" value="{{ old('slug') }}" placeholder="team-a-vs-team-b-date (auto-generated if empty)">
                    </div>
                </div>
            </div>

            {{-- SEO --}}
            <div class="admin-card">
                <div class="admin-card-header"><h2 class="admin-card-title">SEO</h2></div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">SEO Title</label>
                        <input type="text" name="seo_title" class="form-input" value="{{ old('seo_title') }}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SEO Description</label>
                        <textarea name="seo_description" class="form-textarea" rows="2">{{ old('seo_description') }}</textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Keywords</label>
                        <input type="text" name="seo_keywords" class="form-input" value="{{ old('seo_keywords') }}">
                    </div>
                </div>
            </div>
        </div>

        {{-- Sidebar --}}
        <div>
            <div class="admin-card" style="position:sticky;top:1.5rem;">
                <div class="admin-card-header"><h2 class="admin-card-title">Publish</h2></div>
                <div class="admin-card-body">
                    <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" id="is_active" class="form-checkbox" value="1" {{ old('is_active', 1) ? 'checked' : '' }}>
                        <label for="is_active" style="font-size:0.875rem;cursor:pointer">Active (visible on site)</label>
                    </div>
                    <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;">
                        <input type="hidden" name="is_priority" value="0">
                        <input type="checkbox" name="is_priority" id="is_priority" class="form-checkbox" value="1" {{ old('is_priority') ? 'checked' : '' }}>
                        <label for="is_priority" style="font-size:0.875rem;cursor:pointer">⭐ Priority Match</label>
                    </div>
                    <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;">
                        <input type="hidden" name="show_playing_xi" value="0">
                        <input type="checkbox" name="show_playing_xi" id="show_playing_xi" class="form-checkbox" value="1" {{ old('show_playing_xi',1) ? 'checked' : '' }}>
                        <label for="show_playing_xi" style="font-size:0.875rem;cursor:pointer">Show Playing XI</label>
                    </div>
                    <button type="submit" class="btn-primary-sm" style="width:100%;justify-content:center;padding:0.75rem;margin-top:1rem;">
                        Create Match
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

@push('scripts')
<script>
document.getElementById('page_type_select')?.addEventListener('change', function() {
    document.getElementById('match_link_group').style.display = this.value === 'link' ? 'block' : 'none';
});
</script>
@endpush
@endsection
