@extends('layouts.admin')
@section('title', 'Streaming Servers')
@section('content')
<div class="admin-header">
    <div>
        <a href="{{ route('admin.matches.show', $match->id) }}" style="font-size:0.875rem;color:var(--muted);">← Back to Match</a>
        <h1 class="admin-page-title">Servers: {{ $match->teamA?->short_name }} vs {{ $match->teamB?->short_name }}</h1>
    </div>
    <button onclick="document.getElementById('add-server-modal').style.display='flex'" class="btn-primary-sm">+ Add Server</button>
</div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Name</th><th>URL</th><th>Type</th><th>Player</th><th>Order</th><th>Working</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($match->streamingServers->sortBy('display_order') as $server)
            <tr>
                <td style="font-weight:600;font-size:0.875rem;">{{ $server->server_name }}</td>
                <td style="font-size:0.75rem;color:var(--muted);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $server->server_url }}</td>
                <td style="font-size:0.8rem">{{ $server->server_type }}</td>
                <td style="font-size:0.8rem">{{ $server->player_type }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $server->display_order }}</td>
                <td>
                    @if($server->is_working)<span class="badge badge-completed-sm">✓</span>
                    @else<span class="badge badge-live-sm">✗ ({{ $server->not_working_reports }})</span>@endif
                </td>
                <td>
                    <button onclick="editServer('{{ $server->id }}','{{ addslashes($server->server_name) }}','{{ addslashes($server->server_url) }}','{{ $server->server_type }}','{{ $server->player_type }}','{{ $server->display_order }}')" class="btn-sm btn-edit">Edit</button>
                    <form method="POST" action="{{ route('admin.match.servers.destroy', [$match->id, $server->id]) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete server?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:2rem;">No servers. Add one above.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Add Modal --}}
<div id="add-server-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:600px;max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
            <h3 style="font-family:var(--font-display);font-weight:700;">Add Streaming Server</h3>
            <button onclick="document.getElementById('add-server-modal').style.display='none'" style="color:var(--muted);font-size:1.5rem;background:none;border:none;cursor:pointer;">&times;</button>
        </div>
        <form method="POST" action="{{ route('admin.match.servers.store', $match->id) }}">@csrf
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Server Name *</label><input type="text" name="server_name" class="form-input" required placeholder="Server 1, HD Link…"></div>
                <div class="form-group"><label class="form-label">Display Order</label><input type="number" name="display_order" class="form-input" value="1"></div>
            </div>
            <div class="form-group"><label class="form-label">Stream URL *</label><input type="text" name="server_url" class="form-input" required placeholder="https://… or iframe URL"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Stream Type</label>
                    <select name="server_type" class="form-select">
                        <option value="hls">HLS (m3u8)</option>
                        <option value="iframe">iFrame</option>
                        <option value="youtube">YouTube</option>
                        <option value="mp4">MP4</option>
                        <option value="dash">DASH</option>
                    </select></div>
                <div class="form-group"><label class="form-label">Player Type</label>
                    <select name="player_type" class="form-select">
                        <option value="auto">Auto</option>
                        <option value="iframe">iFrame</option>
                        <option value="hlsjs">HLS.js</option>
                        <option value="native">Native</option>
                    </select></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Referer</label><input type="text" name="referer_value" class="form-input" placeholder="https://…"></div>
                <div class="form-group"><label class="form-label">Origin</label><input type="text" name="origin_value" class="form-input" placeholder="https://…"></div>
            </div>
            <div class="form-group" style="display:flex;align-items:center;gap:0.5rem;">
                <input type="hidden" name="is_active" value="0">
                <input type="checkbox" name="is_active" id="srv_active" class="form-checkbox" value="1" checked>
                <label for="srv_active" style="font-size:0.875rem;cursor:pointer">Active</label>
            </div>
            <div style="display:flex;gap:0.75rem;margin-top:1rem;">
                <button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add Server</button>
                <button type="button" onclick="document.getElementById('add-server-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
