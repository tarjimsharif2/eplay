@extends('layouts.admin')
@section('title','Sponsor Notices')
@section('content')
<div class="admin-header"><h1 class="admin-page-title">Sponsor Notices</h1><button onclick="document.getElementById('add-notice-modal').style.display='flex'" class="btn-primary-sm">+ Add</button></div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Title</th><th>Position</th><th>Global</th><th>Match</th><th>Active</th><th></th></tr></thead>
        <tbody>
            @forelse($notices as $n)
            <tr>
                <td style="font-weight:500">{{ $n->title }}</td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $n->position }}</td>
                <td><span class="badge {{ $n->is_global ? 'badge-completed-sm' : '' }}" style="{{ !$n->is_global ? 'color:var(--muted)' : '' }}">{{ $n->is_global ? 'Global' : 'Specific' }}</span></td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $n->match?->teamA?->short_name ?? '–' }}</td>
                <td><span class="badge {{ $n->is_active ? 'badge-completed-sm' : 'badge-live-sm' }}">{{ $n->is_active ? 'On' : 'Off' }}</span></td>
                <td><form method="POST" action="{{ route('admin.sponsor-notices.destroy', $n->id) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete?">Del</button></form></td>
            </tr>
            @empty
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">No notices.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div style="padding:1rem">{{ $notices->links() }}</div>
</div>
<div id="add-notice-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;"><h3 style="font-weight:700">Add Sponsor Notice</h3><button onclick="document.getElementById('add-notice-modal').style.display='none'" style="font-size:1.5rem;background:none;border:none;cursor:pointer;color:var(--muted)">&times;</button></div>
        <form method="POST" action="{{ route('admin.sponsor-notices.store') }}">@csrf
            <div class="form-group"><label class="form-label">Title *</label><input type="text" name="title" class="form-input" required></div>
            <div class="form-group"><label class="form-label">Content *</label><textarea name="content" class="form-textarea" required rows="3"></textarea></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Position</label><input type="text" name="position" class="form-input" placeholder="above-player, below-servers"></div>
                <div class="form-group"><label class="form-label">Display Type</label><select name="display_type" class="form-select"><option value="banner">Banner</option><option value="popup">Popup</option><option value="inline">Inline</option></select></div>
            </div>
            <div class="form-group"><label class="form-label">Match (optional)</label>
                <select name="match_id" class="form-select">
                    <option value="">No match (global)</option>
                    @foreach($matches as $m)<option value="{{ $m->id }}">{{ $m->teamA?->short_name }} vs {{ $m->teamB?->short_name }} ({{ $m->match_date }})</option>@endforeach
                </select></div>
            <div style="display:flex;gap:1.5rem;margin-bottom:1rem;">
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" class="form-checkbox" value="1" checked>Active</label>
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="is_global" value="0"><input type="checkbox" name="is_global" class="form-checkbox" value="1">Global</label>
            </div>
            <div style="display:flex;gap:0.75rem;"><button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add Notice</button><button type="button" onclick="document.getElementById('add-notice-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button></div>
        </form>
    </div>
</div>
@endsection
