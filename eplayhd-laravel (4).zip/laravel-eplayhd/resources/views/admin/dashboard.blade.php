@extends('layouts.admin')
@section('title', 'Dashboard')
@section('content')
<div class="admin-header">
    <h1 class="admin-page-title">Dashboard</h1>
    <div class="admin-actions">
        <a href="{{ route('admin.matches.create') }}" class="btn-primary-sm">
            <svg style="width:0.875rem;height:0.875rem" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            New Match
        </a>
    </div>
</div>

{{-- Stats --}}
<div class="stat-grid">
    <div class="stat-card">
        <p class="stat-label">Total Matches</p>
        <p class="stat-value">{{ $stats['total_matches'] }}</p>
    </div>
    <div class="stat-card" style="border-color:rgba(239,68,68,0.4);">
        <p class="stat-label" style="color:#ef4444">🔴 Live</p>
        <p class="stat-value" style="color:#ef4444;">{{ $stats['live_matches'] }}</p>
    </div>
    <div class="stat-card" style="border-color:rgba(59,130,246,0.4);">
        <p class="stat-label" style="color:#2563eb">Upcoming</p>
        <p class="stat-value" style="color:#2563eb;">{{ $stats['upcoming_matches'] }}</p>
    </div>
    <div class="stat-card" style="border-color:rgba(34,197,94,0.4);">
        <p class="stat-label" style="color:#16a34a">Completed</p>
        <p class="stat-value" style="color:#16a34a;">{{ $stats['completed_matches'] }}</p>
    </div>
    <div class="stat-card">
        <p class="stat-label">Tournaments</p>
        <p class="stat-value">{{ $stats['total_tournaments'] }}</p>
        <p class="stat-sublabel">{{ $stats['active_tournaments'] }} active</p>
    </div>
    <div class="stat-card">
        <p class="stat-label">Teams</p>
        <p class="stat-value">{{ $stats['total_teams'] }}</p>
    </div>
    <div class="stat-card">
        <p class="stat-label">Channels</p>
        <p class="stat-value">{{ $stats['total_channels'] }}</p>
    </div>
    <div class="stat-card" style="{{ $stats['broken_servers'] > 0 ? 'border-color:rgba(234,179,8,0.4);' : '' }}">
        <p class="stat-label">Servers</p>
        <p class="stat-value">{{ $stats['active_servers'] }}</p>
        @if($stats['broken_servers'] > 0)
        <p class="stat-sublabel" style="color:#ca8a04;">⚠ {{ $stats['broken_servers'] }} broken</p>
        @endif
    </div>
</div>

@if($liveMatches->count() > 0)
<div class="admin-card" style="border-color:rgba(239,68,68,0.3);">
    <div class="admin-card-header">
        <h2 class="admin-card-title" style="color:#ef4444;">🔴 Live Now ({{ $liveMatches->count() }})</h2>
    </div>
    <table class="admin-table">
        <thead>
            <tr>
                <th>Match</th>
                <th>Score</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($liveMatches as $match)
            <tr>
                <td>
                    <div style="font-weight:600">{{ $match->teamA?->short_name ?? '?' }} vs {{ $match->teamB?->short_name ?? '?' }}</div>
                    <div style="font-size:0.75rem;color:var(--muted)">{{ $match->tournament?->name }}</div>
                </td>
                <td>
                    <span style="font-weight:600;color:var(--primary)">{{ $match->score_a ?: '–' }}</span>
                    <span style="color:var(--muted)"> / </span>
                    <span style="font-weight:600;color:var(--primary)">{{ $match->score_b ?: '–' }}</span>
                </td>
                <td>
                    <a href="{{ route('admin.matches.show', $match->id) }}" class="btn-sm btn-edit">Manage</a>
                    @if($match->slug && $match->page_type === 'page')
                    <a href="{{ url('/match/'.$match->slug) }}" target="_blank" class="btn-sm btn-success">View</a>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif

{{-- Recent Matches --}}
<div class="admin-card">
    <div class="admin-card-header">
        <h2 class="admin-card-title">Recent Matches</h2>
        <a href="{{ route('admin.matches.index') }}" class="btn-sm btn-edit">View All</a>
    </div>
    <table class="admin-table">
        <thead>
            <tr>
                <th>Match</th>
                <th>Tournament</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($recentMatches as $match)
            <tr>
                <td>
                    <div style="font-weight:600">{{ $match->teamA?->short_name ?? '?' }} vs {{ $match->teamB?->short_name ?? '?' }}</div>
                    <div style="font-size:0.75rem;color:var(--muted)">{{ $match->match_number }}</div>
                </td>
                <td style="font-size:0.875rem;color:var(--muted)">{{ $match->tournament?->name ?? '–' }}</td>
                <td>
                    <span class="badge {{ $match->status === 'live' ? 'badge-live-sm' : ($match->status === 'upcoming' ? 'badge-upcoming-sm' : 'badge-completed-sm') }}">
                        {{ ucfirst($match->status) }}
                    </span>
                </td>
                <td style="font-size:0.8rem;color:var(--muted)">{{ $match->match_date ?? '–' }}</td>
                <td>
                    <a href="{{ route('admin.matches.show', $match->id) }}" class="btn-sm btn-edit">Edit</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

{{-- Quick Links --}}
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:0.75rem;margin-top:1.5rem;">
    <a href="{{ route('admin.matches.create') }}" style="display:flex;flex-direction:column;align-items:center;gap:0.5rem;padding:1.25rem;background:var(--card);border:1px solid var(--border);border-radius:0.75rem;text-align:center;transition:all 0.2s;font-size:0.875rem;font-weight:500;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='var(--border)'">
        ⚡ New Match
    </a>
    <a href="{{ route('admin.teams.index') }}" style="display:flex;flex-direction:column;align-items:center;gap:0.5rem;padding:1.25rem;background:var(--card);border:1px solid var(--border);border-radius:0.75rem;text-align:center;transition:all 0.2s;font-size:0.875rem;font-weight:500;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='var(--border)'">
        👥 Manage Teams
    </a>
    <a href="{{ route('admin.banners.index') }}" style="display:flex;flex-direction:column;align-items:center;gap:0.5rem;padding:1.25rem;background:var(--card);border:1px solid var(--border);border-radius:0.75rem;text-align:center;transition:all 0.2s;font-size:0.875rem;font-weight:500;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='var(--border)'">
        🖼 Banners
    </a>
    <a href="{{ route('admin.settings.index') }}" style="display:flex;flex-direction:column;align-items:center;gap:0.5rem;padding:1.25rem;background:var(--card);border:1px solid var(--border);border-radius:0.75rem;text-align:center;transition:all 0.2s;font-size:0.875rem;font-weight:500;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='var(--border)'">
        ⚙️ Settings
    </a>
</div>
@endsection
