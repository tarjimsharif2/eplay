<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\MatchModel;
class MatchPlayingXI extends Model {
    protected $table = 'match_playing_xi';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['match_id','team_id','player_name','player_role','player_image','batting_order','is_captain','is_vice_captain','is_wicket_keeper','is_bench','change_status'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function match() { return $this->belongsTo(MatchModel::class,'match_id'); }
    public function team() { return $this->belongsTo(Team::class,'team_id'); }
}
