<header class="header" id="site-header">
    <div class="container">
        <div class="header-inner">
            {{-- Logo --}}
            <a href="{{ route('home') }}" class="header-logo">
                @if($siteSettings?->logo_url)
                    <img src="{{ $siteSettings->logo_url }}" alt="{{ $siteSettings->site_name }}" class="logo-img">
                @else
                    <div class="logo-icon">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                            <rect x="2" y="3" width="20" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>
                            <path d="M8 21h8M12 17v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </div>
                @endif
                <span class="logo-text">{{ $siteSettings?->site_name ?? 'ePlayHD' }}</span>
            </a>

            {{-- Desktop Navigation --}}
            <nav class="header-nav desktop-nav" id="desktop-nav">
                <a href="{{ route('home') }}" class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}">Home</a>

                @foreach($customMenus as $menu)
                    @if(!$menu->parent_id)
                        @include('components.menu-item', ['item' => $menu, 'menuTournaments' => $menuTournaments, 'tournamentsBySport' => $tournamentsBySport])
                    @endif
                @endforeach

                <a href="{{ route('channels.index') }}" class="nav-link {{ request()->routeIs('channels.*') ? 'active' : '' }}">
                    <svg class="w-4 h-4 inline mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                    Channels
                </a>
            </nav>

            <div class="header-actions">
                {{-- Theme Toggle --}}
                <button class="theme-toggle" id="theme-toggle" title="Toggle theme">
                    <svg class="sun-icon w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
                    </svg>
                    <svg class="moon-icon w-4 h-4 hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                    </svg>
                </button>

                {{-- Mobile menu button --}}
                <button class="mobile-menu-btn" id="mobile-menu-btn" aria-label="Toggle menu">
                    <svg class="hamburger w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
                    </svg>
                    <svg class="close-icon w-6 h-6 hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
        </div>

        {{-- Mobile Navigation --}}
        <nav class="mobile-nav hidden" id="mobile-nav">
            <a href="{{ route('home') }}" class="mobile-nav-link {{ request()->routeIs('home') ? 'active' : '' }}">Home</a>
            @foreach($customMenus as $menu)
                @if(!$menu->parent_id)
                    <a href="{{ $menu->url ?? '#' }}" class="mobile-nav-link" {{ $menu->open_in_new_tab ? 'target="_blank"' : '' }}>
                        {{ $menu->title }}
                    </a>
                    @if($menu->children->count() > 0)
                        @foreach($menu->children as $child)
                            <a href="{{ $child->url ?? '#' }}" class="mobile-nav-link pl-6 text-sm" {{ $child->open_in_new_tab ? 'target="_blank"' : '' }}>
                                — {{ $child->title }}
                            </a>
                        @endforeach
                    @endif
                    {{-- If Tournaments menu, show tournaments --}}
                    @if(strtolower($menu->title) === 'tournaments')
                        @foreach($menuTournaments as $tournament)
                            <a href="{{ route('tournament.show', $tournament->slug) }}" class="mobile-nav-link pl-6 text-sm">
                                — {{ $tournament->name }}
                            </a>
                        @endforeach
                    @endif
                @endif
            @endforeach
            <a href="{{ route('channels.index') }}" class="mobile-nav-link {{ request()->routeIs('channels.*') ? 'active' : '' }}">Channels</a>
        </nav>
    </div>
</header>

<script>
// Header mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const mobileNav = document.getElementById('mobile-nav');
    const hamburger = mobileBtn?.querySelector('.hamburger');
    const closeIcon = mobileBtn?.querySelector('.close-icon');
    
    mobileBtn?.addEventListener('click', function() {
        mobileNav.classList.toggle('hidden');
        hamburger?.classList.toggle('hidden');
        closeIcon?.classList.toggle('hidden');
    });

    // Dropdown menus
    document.querySelectorAll('.dropdown-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const dropdown = this.nextElementSibling;
            const allDropdowns = document.querySelectorAll('.dropdown-menu');
            allDropdowns.forEach(d => {
                if (d !== dropdown) d.classList.add('hidden');
            });
            dropdown?.classList.toggle('hidden');
        });
    });

    // Close dropdown on outside click
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.dropdown-wrapper')) {
            document.querySelectorAll('.dropdown-menu').forEach(d => d.classList.add('hidden'));
        }
    });
});
</script>
