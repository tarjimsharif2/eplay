<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class SitemapPingHistory extends Model {
    protected $table = 'sitemap_ping_history';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['sitemap_url','ping_type','results','success_count','total_count','triggered_by'];
    protected $casts = ['results'=>'array'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
}
