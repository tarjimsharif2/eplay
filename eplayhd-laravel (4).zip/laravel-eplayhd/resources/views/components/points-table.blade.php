<div class="points-table-section">
    <h2 class="section-title" style="font-size:1rem;margin-bottom:1rem;">
        <svg style="width:1rem;height:1rem;display:inline" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 21l4-4 4 4M12 17V3M5 8H2l2-5M19 8h3l-2-5"/></svg>
        Points Table — {{ $tournament->name }}
    </h2>
    <div style="overflow-x:auto">
    <table class="points-table">
        <thead>
            <tr>
                <th>#</th><th>Team</th><th title="Played">P</th><th title="Won">W</th><th title="Lost">L</th><th title="Tied">T</th><th title="No Result">NR</th><th title="Points">Pts</th><th title="Net Run Rate">NRR</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pointsTable as $row)
            <tr class="{{ $row->qualified ? 'qualified-row' : ($row->eliminated ? 'eliminated-row' : '') }}">
                <td style="font-weight:700;color:var(--muted)">{{ $row->position }}</td>
                <td>
                    <div style="display:flex;align-items:center;gap:0.5rem;">
                        @if($row->team?->logo_url)
                        <img src="{{ $row->team->logo_url }}" style="width:1.25rem;height:1.25rem;object-fit:contain;border-radius:0.125rem">
                        @endif
                        <span style="font-size:0.8rem;font-weight:500">{{ $row->team?->short_name }}</span>
                        @if($row->qualified)<span style="font-size:0.6rem;color:#16a34a;font-weight:700;margin-left:0.25rem">Q</span>@endif
                        @if($row->eliminated)<span style="font-size:0.6rem;color:#ef4444;font-weight:700;margin-left:0.25rem">E</span>@endif
                    </div>
                </td>
                <td>{{ $row->played }}</td>
                <td style="color:#16a34a;font-weight:600">{{ $row->won }}</td>
                <td style="color:#ef4444">{{ $row->lost }}</td>
                <td>{{ $row->tied }}</td>
                <td style="color:var(--muted)">{{ $row->no_result }}</td>
                <td style="font-weight:700;color:var(--primary)">{{ $row->points }}</td>
                <td style="font-size:0.75rem;color:var(--muted)">{{ number_format($row->net_run_rate ?? 0, 3) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    </div>
</div>
