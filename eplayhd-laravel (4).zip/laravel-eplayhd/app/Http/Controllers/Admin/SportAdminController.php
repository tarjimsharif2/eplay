<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Sport;
use Illuminate\Http\Request;

class SportAdminController extends Controller
{
    public function index() {
        $sports = Sport::orderBy('display_order')->get();
        return view('admin.sports.index', compact('sports'));
    }
    public function store(Request $request) {
        $v = $request->validate(['name'=>'required|string|max:255','icon_url'=>'nullable|string','display_order'=>'nullable|integer']);
        Sport::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Sport created.');
    }
    public function update(Request $request, string $id) {
        Sport::findOrFail($id)->update($request->validate(['name'=>'required|string|max:255','icon_url'=>'nullable|string','display_order'=>'nullable|integer']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Sport updated.');
    }
    public function destroy(string $id) { Sport::findOrFail($id)->delete(); return back()->with('success','Sport deleted.'); }
}
