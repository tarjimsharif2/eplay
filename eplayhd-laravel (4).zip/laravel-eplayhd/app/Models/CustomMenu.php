<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class CustomMenu extends Model {
    protected $table = 'custom_menus';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['title','url','icon_name','menu_type','parent_id','display_order','is_active','open_in_new_tab'];
    protected $casts = ['is_active'=>'boolean','open_in_new_tab'=>'boolean'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function parent() { return $this->belongsTo(CustomMenu::class,'parent_id'); }
    public function children() { return $this->hasMany(CustomMenu::class,'parent_id')->where('is_active',true)->orderBy('display_order'); }
}
