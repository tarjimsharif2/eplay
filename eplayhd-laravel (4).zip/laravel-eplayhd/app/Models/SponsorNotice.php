<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\MatchModel;
class SponsorNotice extends Model {
    protected $table = 'sponsor_notices';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['title','content','position','display_type','background_color','text_color','is_active','is_global','match_id','display_order'];
    protected $casts = ['is_active'=>'boolean','is_global'=>'boolean'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function match() { return $this->belongsTo(MatchModel::class,'match_id'); }
}
