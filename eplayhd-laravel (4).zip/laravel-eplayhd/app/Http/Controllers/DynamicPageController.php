<?php
namespace App\Http\Controllers;
use App\Models\DynamicPage;
use App\Models\SiteSettings;

class DynamicPageController extends Controller
{
    public function show(string $slug)
    {
        $page = DynamicPage::where('slug', $slug)->where('is_active', true)->firstOrFail();
        $siteSettings = SiteSettings::first();
        $seoTitle = $page->seo_title ?? ($page->title . ' | ' . ($siteSettings?->site_name ?? 'ePlayHD'));
        $seoDescription = $page->seo_description ?? '';
        $seoKeywords = $page->seo_keywords ?? '';
        return view('pages.dynamic', compact('page', 'seoTitle', 'seoDescription', 'seoKeywords', 'siteSettings'));
    }
}
