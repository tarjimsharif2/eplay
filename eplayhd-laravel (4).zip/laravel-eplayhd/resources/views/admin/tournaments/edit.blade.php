@extends('layouts.admin')
@section('title','Edit Tournament')
@section('content')
<div class="admin-header"><a href="{{ route('admin.tournaments.index') }}" style="font-size:0.875rem;color:var(--muted)">← Back</a><h1 class="admin-page-title">Edit: {{ $tournament->name }}</h1></div>
<form method="POST" action="{{ route('admin.tournaments.update', $tournament->id) }}">@csrf @method('PUT')
    <div class="admin-card"><div class="admin-card-header"><h2 class="admin-card-title">Details</h2></div>
    <div class="admin-card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" class="form-input" required value="{{ $tournament->name }}"></div>
            <div class="form-group"><label class="form-label">Season *</label><input type="text" name="season" class="form-input" required value="{{ $tournament->season }}"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">Sport *</label>
                <select name="sport" class="form-select" required>
                    @foreach(['cricket','football','basketball','baseball','tennis','rugby','hockey'] as $s)<option value="{{ $s }}" {{ $tournament->sport===$s?'selected':'' }}>{{ ucfirst($s) }}</option>@endforeach
                </select></div>
            <div class="form-group"><label class="form-label">Slug</label><input type="text" name="slug" class="form-input" value="{{ $tournament->slug }}"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">Logo URL</label><input type="text" name="logo_url" class="form-input" value="{{ $tournament->logo_url }}"></div>
            <div class="form-group"><label class="form-label">Logo BG Color</label><input type="text" name="logo_background_color" class="form-input" value="{{ $tournament->logo_background_color }}" placeholder="#ffffff"></div>
        </div>
        <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea">{{ $tournament->description }}</textarea></div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
            <div class="form-group"><label class="form-label">SEO Title</label><input type="text" name="seo_title" class="form-input" value="{{ $tournament->seo_title }}"></div>
            <div class="form-group"><label class="form-label">SEO Desc</label><input type="text" name="seo_description" class="form-input" value="{{ $tournament->seo_description }}"></div>
            <div class="form-group"><label class="form-label">Keywords</label><input type="text" name="seo_keywords" class="form-input" value="{{ $tournament->seo_keywords }}"></div>
        </div>
        <div style="display:flex;gap:1.5rem;flex-wrap:wrap;margin-bottom:1rem;">
            @foreach([['is_active','Active'],['show_in_menu','Show in Menu'],['show_in_homepage','Show on Homepage'],['is_completed','Completed'],['show_participating_teams','Show Teams']] as [$f,$l])
            <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="{{ $f }}" value="0"><input type="checkbox" name="{{ $f }}" class="form-checkbox" value="1" {{ $tournament->$f ? 'checked' : '' }}>{{ $l }}</label>
            @endforeach
        </div>
        <button type="submit" class="btn-primary-sm">Save Changes</button>
    </div></div>
</form>
@endsection
