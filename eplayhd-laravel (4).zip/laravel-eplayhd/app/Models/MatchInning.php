<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use App\Models\MatchModel;
class MatchInning extends Model {
    protected $table = 'match_innings';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['match_id','innings_number','batting_team_id','runs','wickets','overs','extras','declared','is_current'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function match() { return $this->belongsTo(MatchModel::class,'match_id'); }
    public function battingTeam() { return $this->belongsTo(Team::class,'batting_team_id'); }
}
