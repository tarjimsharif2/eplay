@props(['server', 'matchId'])
<div class="player-container" id="player-{{ $server->id }}" data-server-id="{{ $server->id }}" data-match-id="{{ $matchId }}">
    <div style="display:flex;align-items:center;justify-content:center;height:100%;color:white;font-size:0.875rem;">
        Loading player…
    </div>
</div>
<script>
(function() {
    const container = document.getElementById('player-{{ $server->id }}');
    if (!container) return;
    window.initVideoPlayer(
        container,
        '{{ addslashes($server->server_url) }}',
        '{{ $server->server_type }}',
        '{{ $server->player_type }}'
    );
})();
</script>
