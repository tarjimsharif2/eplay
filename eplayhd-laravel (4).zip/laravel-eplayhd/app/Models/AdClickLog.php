<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class AdClickLog extends Model {
    protected $table = 'ad_click_logs';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['device_fingerprint','click_count','first_click_at','last_click_at','blocked_until'];
    protected $casts = ['first_click_at'=>'datetime','last_click_at'=>'datetime','blocked_until'=>'datetime'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
}
