<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\StreamingServer;
use App\Models\MatchModel;
use Illuminate\Http\Request;

class StreamingServerAdminController extends Controller
{
    public function index(string $matchId) {
        $match = bMatchModel::with(['teamA','teamB','streamingServers'])->findOrFail($matchId);
        return view('admin.matches.servers', compact('match'));
    }
    public function store(Request $request, string $matchId) {
        bMatchModel::findOrFail($matchId);
        $v = $request->validate(['server_name'=>'required|string|max:255','server_url'=>'required|string','server_type'=>'nullable|string|max:50','player_type'=>'nullable|string|max:50','display_order'=>'nullable|integer','is_active'=>'boolean','drm_scheme'=>'nullable|string','drm_license_url'=>'nullable|string','clearkey_key_id'=>'nullable|string','clearkey_key'=>'nullable|string','referer_value'=>'nullable|string','origin_value'=>'nullable|string','user_agent'=>'nullable|string','cookie_value'=>'nullable|string','ad_block_enabled'=>'boolean']);
        $v['match_id'] = $matchId;
        StreamingServer::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Server added.');
    }
    public function update(Request $request, string $matchId, string $id) {
        $server = StreamingServer::where('match_id',$matchId)->findOrFail($id);
        $server->update($request->validate(['server_name'=>'required|string|max:255','server_url'=>'required|string','server_type'=>'nullable|string|max:50','player_type'=>'nullable|string|max:50','display_order'=>'nullable|integer','is_active'=>'boolean','is_working'=>'boolean','drm_scheme'=>'nullable|string','drm_license_url'=>'nullable|string','clearkey_key_id'=>'nullable|string','clearkey_key'=>'nullable|string','referer_value'=>'nullable|string','origin_value'=>'nullable|string','user_agent'=>'nullable|string','cookie_value'=>'nullable|string','ad_block_enabled'=>'boolean']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Server updated.');
    }
    public function destroy(string $matchId, string $id) {
        StreamingServer::where('match_id',$matchId)->findOrFail($id)->delete();
        return back()->with('success','Server deleted.');
    }
    public function reorder(Request $request, string $matchId) {
        foreach ($request->order as $item) { StreamingServer::where('match_id',$matchId)->where('id',$item['id'])->update(['display_order'=>$item['order']]); }
        return response()->json(['success'=>true]);
    }
}
