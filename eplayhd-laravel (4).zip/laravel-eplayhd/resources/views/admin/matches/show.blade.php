@extends('layouts.admin')
@section('title', $match->teamA?->short_name . ' vs ' . $match->teamB?->short_name)
@section('content')
<div class="admin-header">
    <div>
        <a href="{{ route('admin.matches.index') }}" style="font-size:0.875rem;color:var(--muted);">← Back to Matches</a>
        <h1 class="admin-page-title" style="margin-top:0.25rem;">
            {{ $match->teamA?->name ?? '?' }} vs {{ $match->teamB?->name ?? '?' }}
        </h1>
        <p style="font-size:0.875rem;color:var(--muted)">{{ $match->tournament?->name }} • {{ $match->match_date }} • {{ $match->match_format }}</p>
    </div>
    <div class="admin-actions">
        @if($match->slug && $match->page_type === 'page')
        <a href="{{ url('/match/'.$match->slug) }}" target="_blank" class="btn-sm btn-success">View Page</a>
        @endif
        <a href="{{ route('admin.matches.edit', $match->id) }}" class="btn-primary-sm">Edit Details</a>
    </div>
</div>

{{-- Status Quick Controls --}}
<div class="admin-card" style="margin-bottom:1rem;">
    <div class="admin-card-body" style="display:flex;gap:0.75rem;flex-wrap:wrap;align-items:center;padding:0.875rem 1.25rem;">
        <span style="font-size:0.875rem;font-weight:600;color:var(--muted);">Status:</span>
        @foreach(['upcoming','live','completed','abandoned','postponed'] as $s)
        <button onclick="setStatus('{{ $s }}')" class="btn-sm {{ $match->status === $s ? 'btn-success' : 'btn-edit' }}" id="status-{{ $s }}">
            {{ $match->status === 'live' && $s === 'live' ? '🔴 ' : '' }}{{ ucfirst($s) }}
        </button>
        @endforeach
        <span style="font-size:0.8rem;color:var(--muted);margin-left:auto;">Slug: <code style="background:var(--accent);padding:0.125rem 0.375rem;border-radius:0.25rem;font-size:0.75rem">{{ $match->slug }}</code></span>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 320px;gap:1.5rem;">
    <div>
        {{-- Streaming Servers --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h2 class="admin-card-title">Streaming Servers ({{ $match->streamingServers->count() }})</h2>
                <a href="{{ route('admin.match.servers.index', $match->id) }}" class="btn-primary-sm">Manage Servers</a>
            </div>
            <table class="admin-table">
                <thead><tr><th>Name</th><th>Type</th><th>Working</th><th>Order</th></tr></thead>
                <tbody>
                    @forelse($match->streamingServers as $server)
                    <tr>
                        <td style="font-size:0.875rem;font-weight:500">{{ $server->server_name }}</td>
                        <td style="font-size:0.8rem;color:var(--muted)">{{ $server->server_type }} / {{ $server->player_type }}</td>
                        <td>
                            @if($server->is_working)
                                <span class="badge badge-completed-sm">✓ Working</span>
                            @else
                                <span class="badge badge-live-sm">✗ Broken</span>
                            @endif
                        </td>
                        <td style="font-size:0.8rem;color:var(--muted)">{{ $server->display_order }}</td>
                    </tr>
                    @empty
                    <tr><td colspan="4" style="text-align:center;color:var(--muted);padding:1.5rem;">No servers added yet.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        {{-- Innings --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h2 class="admin-card-title">Innings ({{ $match->innings->count() }})</h2>
                <a href="{{ route('admin.match.innings', $match->id) }}" class="btn-primary-sm">Manage</a>
            </div>
            <table class="admin-table">
                <thead><tr><th>Innings</th><th>Batting Team</th><th>Score</th><th>Overs</th><th>Status</th></tr></thead>
                <tbody>
                    @forelse($match->innings as $inn)
                    <tr>
                        <td style="font-weight:600">{{ $inn->innings_number }}</td>
                        <td style="font-size:0.875rem">{{ $inn->battingTeam?->name ?? '–' }}</td>
                        <td style="font-weight:700;color:var(--primary)">{{ $inn->runs ?? '–' }}/{{ $inn->wickets ?? '–' }}</td>
                        <td style="font-size:0.875rem;color:var(--muted)">{{ $inn->overs }}</td>
                        <td>@if($inn->is_current)<span class="badge badge-live-sm">Current</span>@endif @if($inn->declared)<span class="badge badge-completed-sm">D</span>@endif</td>
                    </tr>
                    @empty
                    <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:1.5rem;">No innings added.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        {{-- Playing XI --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h2 class="admin-card-title">Playing XI ({{ $match->playingXI->count() }})</h2>
                <a href="{{ route('admin.match.playing-xi', $match->id) }}" class="btn-primary-sm">Manage</a>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;padding:1rem;">
                @foreach([$match->teamA, $match->teamB] as $team)
                <div>
                    <p style="font-weight:600;font-size:0.875rem;margin-bottom:0.5rem;color:var(--primary)">{{ $team?->name }}</p>
                    @foreach($match->playingXI->where('team_id', $team?->id) as $player)
                    <div style="font-size:0.8rem;padding:0.25rem 0;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.375rem;">
                        @if($player->is_captain)<span style="color:var(--primary);font-weight:700">(C)</span>@endif
                        @if($player->is_vice_captain)<span style="color:var(--muted);font-size:0.7rem">(VC)</span>@endif
                        @if($player->is_wicket_keeper)<span style="color:var(--muted);font-size:0.7rem">(WK)</span>@endif
                        {{ $player->player_name }}
                    </div>
                    @endforeach
                    @if($match->playingXI->where('team_id', $team?->id)->isEmpty())
                    <p style="font-size:0.8rem;color:var(--muted)">Not added yet</p>
                    @endif
                </div>
                @endforeach
            </div>
        </div>

        {{-- Score Update --}}
        @if(in_array($match->status, ['live','completed']))
        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Score Update</h2></div>
            <div class="admin-card-body">
                <div style="display:grid;grid-template-columns:1fr 1fr {{ $match->sport?->name === 'Football' ? '80px' : '' }};gap:1rem;">
                    <div class="form-group">
                        <label class="form-label">{{ $match->teamA?->short_name }} Score</label>
                        <input type="text" id="score_a" class="form-input" value="{{ $match->score_a }}" placeholder="23/4 (9.2)">
                    </div>
                    <div class="form-group">
                        <label class="form-label">{{ $match->teamB?->short_name }} Score</label>
                        <input type="text" id="score_b" class="form-input" value="{{ $match->score_b }}" placeholder="186/8 (20)">
                    </div>
                    @if($match->sport?->name === 'Football')
                    <div class="form-group">
                        <label class="form-label">Minute</label>
                        <input type="number" id="match_minute" class="form-input" value="{{ $match->match_minute }}" min="0" max="120">
                    </div>
                    @endif
                </div>
                <button onclick="saveScore()" class="btn-primary-sm">Save Score</button>
                @if($match->api_score_enabled)
                <button onclick="syncApiScore()" class="btn-sm btn-edit" style="margin-left:0.5rem">🔄 Sync API</button>
                @endif
            </div>
        </div>
        @endif
    </div>

    {{-- Right Sidebar --}}
    <div>
        <div class="admin-card" style="margin-bottom:1rem;">
            <div class="admin-card-header"><h2 class="admin-card-title">Match Info</h2></div>
            <div class="admin-card-body" style="font-size:0.875rem;display:flex;flex-direction:column;gap:0.5rem;">
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Status</span><span class="badge {{ $match->status === 'live' ? 'badge-live-sm' : ($match->status === 'upcoming' ? 'badge-upcoming-sm' : 'badge-completed-sm') }}">{{ ucfirst($match->status) }}</span></div>
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Date</span><span>{{ $match->match_date }}</span></div>
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Time</span><span>{{ $match->match_time }}</span></div>
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Venue</span><span style="text-align:right;max-width:160px">{{ $match->venue ?? '–' }}</span></div>
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Format</span><span>{{ $match->match_format ?? '–' }}</span></div>
                @if($match->tossWinner)
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Toss</span><span>{{ $match->tossWinner->short_name }} won, {{ $match->toss_decision }}</span></div>
                @endif
                @if($match->match_result)
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Result</span><span style="color:var(--primary);font-weight:600">{{ $match->result_margin }}</span></div>
                @endif
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Priority</span><span>{{ $match->is_priority ? '⭐ Yes' : 'No' }}</span></div>
                <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted)">Active</span><span>{{ $match->is_active ? '✓ Yes' : '✗ No' }}</span></div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header"><h2 class="admin-card-title">Quick Links</h2></div>
            <div class="admin-card-body" style="display:flex;flex-direction:column;gap:0.5rem;">
                <a href="{{ route('admin.matches.edit', $match->id) }}" class="btn-sm btn-edit" style="justify-content:center">Edit Details</a>
                <a href="{{ route('admin.match.servers.index', $match->id) }}" class="btn-sm btn-edit" style="justify-content:center">Manage Servers</a>
                <a href="{{ route('admin.match.playing-xi', $match->id) }}" class="btn-sm btn-edit" style="justify-content:center">Playing XI</a>
                <a href="{{ route('admin.match.innings', $match->id) }}" class="btn-sm btn-edit" style="justify-content:center">Innings</a>
                <a href="{{ route('admin.match.points-table', $match->id) }}" class="btn-sm btn-edit" style="justify-content:center">Points Table</a>
                <form method="POST" action="{{ route('admin.matches.destroy', $match->id) }}" style="margin-top:0.5rem">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn-sm btn-delete" style="width:100%;justify-content:center" data-confirm="Delete this match permanently?">Delete Match</button>
                </form>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function setStatus(status) {
    fetch('{{ route("admin.matches.status", $match->id) }}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': window.csrfToken() },
        body: JSON.stringify({ status })
    }).then(r => r.json()).then(d => {
        if (d.success) location.reload();
    });
}

function saveScore() {
    const score_a = document.getElementById('score_a')?.value;
    const score_b = document.getElementById('score_b')?.value;
    const match_minute = document.getElementById('match_minute')?.value;
    fetch('{{ route("admin.matches.score", $match->id) }}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': window.csrfToken() },
        body: JSON.stringify({ score_a, score_b, match_minute })
    }).then(r => r.json()).then(d => {
        if (d.success) { const t = document.createElement('div'); t.className = 'toast toast-success'; t.textContent = 'Score saved!'; document.body.appendChild(t); setTimeout(() => t.remove(), 3000); }
    });
}

function syncApiScore() {
    fetch('{{ route("admin.matches.sync", $match->id) }}', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': window.csrfToken() }
    }).then(r => r.json()).then(d => alert(d.success ? 'Synced!' : d.error));
}
</script>
@endpush
@endsection
