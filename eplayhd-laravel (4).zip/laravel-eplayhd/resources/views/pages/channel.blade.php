@extends('layouts.app')
@section('title', $seoTitle)
@section('meta_description', $seoDescription)
@section('meta_keywords', $seoKeywords)
@section('content')
<div class="container" style="padding:2rem 1rem;">
    <div style="max-width:900px;margin:0 auto;">
        {{-- Channel Header --}}
        <div style="display:flex;align-items:center;gap:1.25rem;background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;margin-bottom:1.5rem;">
            <div style="width:4rem;height:4rem;border-radius:0.75rem;border:1px solid var(--border);padding:0.375rem;flex-shrink:0;display:flex;align-items:center;justify-content:center;{{ $channel->logo_background_color ? 'background:'.$channel->logo_background_color : '' }}">
                @if($channel->logo_url)
                    <img src="{{ $channel->logo_url }}" alt="{{ $channel->name }}" style="width:100%;height:100%;object-fit:contain">
                @else
                    <span style="font-weight:700;font-size:1.25rem;color:var(--primary)">{{ strtoupper(substr($channel->name,0,2)) }}</span>
                @endif
            </div>
            <div>
                <h1 style="font-size:1.5rem;font-weight:800;font-family:var(--font-display);">{{ $channel->name }}</h1>
                @if($channel->description)<p style="color:var(--muted);font-size:0.875rem;margin-top:0.25rem;">{{ $channel->description }}</p>@endif
            </div>
        </div>

        {{-- Streaming Servers --}}
        @if($channel->streamingServers->count() > 0)
        <div class="servers-section">
            <div class="server-tabs">
                @foreach($channel->streamingServers as $server)
                <button class="server-tab {{ $loop->first ? 'active' : '' }}"
                    data-url="{{ $server->server_url }}"
                    data-type="{{ $server->server_type }}"
                    data-player="{{ $server->player_type }}"
                    onclick="switchChannelServer(this)">
                    {{ $server->server_name }}
                </button>
                @endforeach
            </div>
            <div class="player-container" id="channel-player"></div>
        </div>
        @else
        <div class="no-servers"><p>No streams available for this channel right now.</p></div>
        @endif
    </div>
</div>
@push('scripts')
<script>
const firstServer = document.querySelector('.server-tab[data-url]');
if (firstServer) {
    const container = document.getElementById('channel-player');
    window.initVideoPlayer(container, firstServer.dataset.url, firstServer.dataset.type, firstServer.dataset.player);
}
function switchChannelServer(btn) {
    document.querySelectorAll('.server-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    const container = document.getElementById('channel-player');
    container.innerHTML = '';
    window.initVideoPlayer(container, btn.dataset.url, btn.dataset.type, btn.dataset.player);
}
</script>
@endpush
@endsection
