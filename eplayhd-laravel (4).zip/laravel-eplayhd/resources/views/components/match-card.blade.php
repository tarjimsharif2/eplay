@php
    $teamA = $match->teamA;
    $teamB = $match->teamB;
    $tournament = $match->tournament;
    $sport = $match->sport;
    $sportName = $sport?->name ?? $tournament?->sport ?? 'Sport';
    $sportLower = strtolower($sportName);
    $isCricket = str_contains($sportLower, 'cricket') || in_array(strtolower($match->match_format ?? ''), ['test','odi','t20','t10','the_hundred']);
    $isFootball = str_contains($sportLower, 'football') || str_contains($sportLower, 'soccer');
    $displayStatus = $match->status;
    $isClickable = ($match->page_type === 'page' && $match->slug) || $match->match_link;

    $cricketFormats = [
        'test' => ['label' => 'TEST', 'color' => 'bg-red-600'],
        'odi' => ['label' => 'ODI', 'color' => 'bg-blue-600'],
        't20' => ['label' => 'T20', 'color' => 'bg-green-600'],
        't10' => ['label' => 'T10', 'color' => 'bg-purple-600'],
        'the_hundred' => ['label' => 'THE HUNDRED', 'color' => 'bg-orange-600'],
    ];
    $cricketFormat = $match->match_format ? ($cricketFormats[strtolower($match->match_format)] ?? null) : null;

    // Score parsing
    $parseScore = function($score) {
        if (!$score) return null;
        preg_match('/\((\d+\.?\d*)\s*ov\)/i', $score, $oversMatch);
        $cleanScore = preg_replace('/\s*\(\d+\.?\d*\s*ov\)/i', '', $score ?? '');
        return ['score' => trim($cleanScore), 'overs' => $oversMatch[1] ?? null];
    };
    $scoreA = $parseScore($match->score_a);
    $scoreB = $parseScore($match->score_b);

    // Status helpers
    $statusClasses = [
        'live' => 'badge-live',
        'completed' => 'badge-completed',
        'upcoming' => 'badge-upcoming',
        'abandoned' => 'badge-abandoned',
        'postponed' => 'badge-postponed',
    ];
    $statusTexts = [
        'live' => 'Live',
        'completed' => 'Completed',
        'upcoming' => 'Upcoming',
        'abandoned' => 'Abandoned',
        'postponed' => 'Postponed',
    ];
    $statusClass = $match->is_stumps ? 'badge-stumps' : ($statusClasses[$displayStatus] ?? 'badge-upcoming');
    $statusText = $match->is_stumps ? 'STUMPS' : ($statusTexts[$displayStatus] ?? 'Upcoming');

    // Match result text
    $resultText = null;
    if ($displayStatus === 'completed' && $match->match_result) {
        switch ($match->match_result) {
            case 'team_a_won':
                $resultText = $teamA?->name . ' Won' . ($match->result_margin ? ' by ' . $match->result_margin : '');
                break;
            case 'team_b_won':
                $resultText = $teamB?->name . ' Won' . ($match->result_margin ? ' by ' . $match->result_margin : '');
                break;
            case 'tied': $resultText = 'Match Tied'; break;
            case 'draw': $resultText = 'Match Drawn'; break;
            case 'no_result': $resultText = 'No Result'; break;
        }
    }

    // Format match number
    $matchNumberDisplay = null;
    if ($match->match_number) {
        $num = $match->match_number;
        if (is_numeric($num)) {
            $matchNumberDisplay = 'Match #' . $num;
        } elseif (preg_match('/^(Round|Matchday|Week|Match)\s*#?\s*(\d+)$/i', $num, $m)) {
            $matchNumberDisplay = $m[1] . ' #' . $m[2];
        } else {
            $matchNumberDisplay = $num;
        }
    }

    // Date label
    $matchDateLabel = $match->match_date;
    if ($match->match_start_time) {
        $startTime = \Carbon\Carbon::parse($match->match_start_time);
        $now = \Carbon\Carbon::now();
        if ($startTime->isToday()) $matchDateLabel = 'Today';
        elseif ($startTime->isTomorrow()) $matchDateLabel = 'Tomorrow';
        else $matchDateLabel = $startTime->format('jS F Y');
    }
    $isTodayOrTomorrow = in_array($matchDateLabel, ['Today', 'Tomorrow']);
    $matchTime = $match->match_start_time ? \Carbon\Carbon::parse($match->match_start_time)->format('g:i A') : $match->match_time;
@endphp

<div class="match-card {{ $isClickable ? 'clickable' : '' }} {{ $displayStatus }}"
    @if($isClickable)
        onclick="@if($match->page_type === 'page' && $match->slug) window.location.href='{{ route('match.show', $match->slug) }}' @elseif($match->match_link) window.open('{{ $match->match_link }}', '_blank') @endif"
    @endif
    data-match-id="{{ $match->id }}">

    {{-- Priority bar --}}
    @if($match->is_priority)
    <div class="priority-bar"></div>
    @endif

    {{-- Tournament Logo --}}
    @if($tournament?->logo_url)
    <div class="tournament-logo-corner">
        <div class="tournament-logo-badge" style="{{ $tournament->logo_background_color ? 'background-color:' . $tournament->logo_background_color : '' }}">
            <img src="{{ $tournament->logo_url }}" alt="{{ $tournament->name }}">
        </div>
    </div>
    @endif

    <div class="match-card-inner">
        {{-- Format Badge (Test/ODI/T20) --}}
        @if($match->match_format === 'test')
        <div class="format-badges">
            <span class="format-badge bg-red-600">TEST</span>
            <span class="format-badge bg-amber-500">Day {{ $match->test_day ?? 1 }}</span>
        </div>
        @elseif($isCricket && $cricketFormat && $match->match_format !== 'test')
        <div class="format-badges">
            <span class="format-badge {{ $cricketFormat['color'] }}">{{ $cricketFormat['label'] }}</span>
        </div>
        @endif

        {{-- Match Label --}}
        @if($match->match_label)
        <div class="match-label-wrapper">
            <span class="match-label">{{ $match->match_label }}</span>
        </div>
        @endif

        {{-- Tournament Name --}}
        @if($tournament)
        <div class="match-tournament">
            <h3 class="tournament-name">{{ $tournament->name }}</h3>
            <div class="tournament-season">
                <div class="season-line"></div>
                <span>{{ $tournament->season }}</span>
                <div class="season-line"></div>
            </div>
        </div>
        @endif

        {{-- Sport & Match Number --}}
        <div class="match-meta-row">
            <span class="sport-badge">{{ $sportName }}</span>
            <div class="match-meta-right">
                @if($match->is_priority)
                <svg class="w-4 h-4 text-yellow-500 fill-yellow-500" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                @endif
                @if($matchNumberDisplay)
                <span class="match-number">{{ $matchNumberDisplay }}</span>
                @endif
            </div>
        </div>

        {{-- Teams & Scores --}}
        @if($isFootball && in_array($displayStatus, ['live', 'completed']))
            {{-- Football Score Layout --}}
            <div class="football-score-layout">
                <div class="team-with-score">
                    <div class="team-logo" style="{{ $teamA?->logo_background_color ? 'background-color:' . $teamA->logo_background_color : '' }}">
                        @if($teamA?->logo_url)
                            <img src="{{ $teamA->logo_url }}" alt="{{ $teamA->name }}">
                        @else
                            <span class="team-initials">{{ strtoupper(substr($teamA?->name ?? '??', 0, 2)) }}</span>
                        @endif
                    </div>
                    <span class="team-name-sm">{{ $teamA?->name }}</span>
                    <span class="football-score" id="score-a-{{ $match->id }}">{{ $match->score_a ?? '0' }}</span>
                </div>

                <div class="score-separator">
                    <span class="vs-dash">-</span>
                    @if($displayStatus === 'live' && $match->match_minute !== null)
                        <span class="football-minute" id="minute-{{ $match->id }}">{{ $match->match_minute }}'</span>
                    @elseif($displayStatus === 'completed')
                        <span class="ft-badge">FT</span>
                    @endif
                </div>

                <div class="team-with-score team-with-score--right">
                    <span class="football-score" id="score-b-{{ $match->id }}">{{ $match->score_b ?? '0' }}</span>
                    <div class="team-logo" style="{{ $teamB?->logo_background_color ? 'background-color:' . $teamB->logo_background_color : '' }}">
                        @if($teamB?->logo_url)
                            <img src="{{ $teamB->logo_url }}" alt="{{ $teamB->name }}">
                        @else
                            <span class="team-initials">{{ strtoupper(substr($teamB?->name ?? '??', 0, 2)) }}</span>
                        @endif
                    </div>
                    <span class="team-name-sm">{{ $teamB?->name }}</span>
                </div>
            </div>

            {{-- Goal Scorers --}}
            @php
                $goalsA = is_array($match->goals_team_a) ? $match->goals_team_a : (json_decode($match->goals_team_a ?? '[]', true) ?? []);
                $goalsB = is_array($match->goals_team_b) ? $match->goals_team_b : (json_decode($match->goals_team_b ?? '[]', true) ?? []);
            @endphp
            @if(!empty($goalsA) || !empty($goalsB))
            <div class="goal-scorers">
                <div class="goal-list">
                    @foreach($goalsA as $goal)
                    <div class="goal-item">
                        <span class="goal-icon">⚽</span>
                        <span class="goal-player">{{ $goal['player'] }}</span>
                        <span class="goal-minute">{{ $goal['minute'] }}</span>
                        @if(!empty($goal['type']) && $goal['type'] === 'penalty')<span class="goal-type">(P)</span>@endif
                        @if(!empty($goal['type']) && $goal['type'] === 'own_goal')<span class="goal-type og">(OG)</span>@endif
                    </div>
                    @endforeach
                </div>
                <div class="goal-list goal-list--right">
                    @foreach($goalsB as $goal)
                    <div class="goal-item goal-item--right">
                        @if(!empty($goal['type']) && $goal['type'] === 'penalty')<span class="goal-type">(P)</span>@endif
                        @if(!empty($goal['type']) && $goal['type'] === 'own_goal')<span class="goal-type og">(OG)</span>@endif
                        <span class="goal-minute">{{ $goal['minute'] }}</span>
                        <span class="goal-player">{{ $goal['player'] }}</span>
                        <span class="goal-icon">⚽</span>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        @else
            {{-- Cricket / Default Team Layout --}}
            <div class="teams-layout">
                {{-- Team A --}}
                <div class="team-col">
                    <div class="team-logo" style="{{ $teamA?->logo_background_color ? 'background-color:' . $teamA->logo_background_color : '' }}">
                        @if($teamA?->logo_url)
                            <img src="{{ $teamA->logo_url }}" alt="{{ $teamA->name }}">
                        @else
                            <span class="team-initials">{{ strtoupper(substr($teamA?->name ?? '??', 0, 2)) }}</span>
                        @endif
                    </div>
                    <span class="team-name">{{ $teamA?->name }}</span>
                    @if($scoreA && (!$isFootball || in_array($displayStatus, ['live', 'completed'])))
                    <div class="team-score">
                        <span class="score-runs" id="score-a-{{ $match->id }}">{{ $scoreA['score'] }}</span>
                        @if($scoreA['overs'])
                        <span class="score-overs">({{ $scoreA['overs'] }} ov)</span>
                        @endif
                    </div>
                    @endif
                </div>

                {{-- VS --}}
                <div class="vs-col">
                    <div class="vs-circle">VS</div>
                </div>

                {{-- Team B --}}
                <div class="team-col">
                    <div class="team-logo" style="{{ $teamB?->logo_background_color ? 'background-color:' . $teamB->logo_background_color : '' }}">
                        @if($teamB?->logo_url)
                            <img src="{{ $teamB->logo_url }}" alt="{{ $teamB->name }}">
                        @else
                            <span class="team-initials">{{ strtoupper(substr($teamB?->name ?? '??', 0, 2)) }}</span>
                        @endif
                    </div>
                    <span class="team-name">{{ $teamB?->name }}</span>
                    @if($scoreB && (!$isFootball || in_array($displayStatus, ['live', 'completed'])))
                    <div class="team-score">
                        <span class="score-runs" id="score-b-{{ $match->id }}">{{ $scoreB['score'] }}</span>
                        @if($scoreB['overs'])
                        <span class="score-overs">({{ $scoreB['overs'] }} ov)</span>
                        @endif
                    </div>
                    @endif
                </div>
            </div>

            {{-- Innings Info (Cricket) --}}
            @if($isCricket && isset($match->innings) && $match->innings->count() > 0)
            <div class="innings-summary">
                @foreach($match->innings->sortBy('innings_number') as $inn)
                @php
                    $isTeamA = $inn->batting_team_id === $match->team_a_id;
                    $teamLabel = $isTeamA ? ($teamA?->short_name ?? $teamA?->name) : ($teamB?->short_name ?? $teamB?->name);
                @endphp
                <div class="innings-row">
                    <span class="innings-team">{{ $teamLabel }}</span>
                    <span class="innings-score">{{ $inn->runs }}/{{ $inn->wickets }}</span>
                    <span class="innings-overs">({{ $inn->overs }} ov)</span>
                    @if($inn->declared) <span class="innings-declared">d</span> @endif
                    @if($inn->is_current) <span class="innings-current">★</span> @endif
                </div>
                @endforeach
            </div>
            @endif

            {{-- Toss Info --}}
            @if($isCricket && $match->toss_winner_id)
            @php
                $tossWinner = $match->toss_winner_id === $match->team_a_id ? $teamA : $teamB;
            @endphp
            <div class="toss-info">
                <span class="toss-icon">🪙</span>
                <span><strong>{{ $tossWinner?->name }}</strong> elected to <strong class="{{ $match->toss_decision === 'bat' ? 'text-green' : 'text-blue' }}">{{ $match->toss_decision === 'bat' ? 'Bat' : 'Bowl' }}</strong></span>
            </div>
            @endif
        @endif

        {{-- Match Result --}}
        @if($resultText)
        <div class="match-result">
            <span>{{ $resultText }}</span>
        </div>
        @endif

        {{-- Footer: Venue, Date/Time, Status --}}
        <div class="match-footer">
            @if($match->venue)
            <p class="match-venue">
                <svg class="w-3.5 h-3.5 inline mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                {{ $match->venue }}
            </p>
            @endif
            <div class="match-time-row">
                <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
                <span class="{{ $isTodayOrTomorrow ? 'text-primary font-semibold' : '' }}">{{ $matchDateLabel }}</span>
                <span>• {{ $matchTime }}</span>
            </div>
            <span class="status-badge {{ $statusClass }}">
                @if($displayStatus === 'live' && !$match->is_stumps)
                <span class="live-pulse"></span>
                @endif
                {{ $statusText }}
            </span>
        </div>
    </div>
</div>
