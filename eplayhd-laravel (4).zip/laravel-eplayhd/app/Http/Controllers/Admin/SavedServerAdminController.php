<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\SavedStreamingServer;
use Illuminate\Http\Request;

class SavedServerAdminController extends Controller
{
    public function index() { return view('admin.saved-servers.index', ['servers' => SavedStreamingServer::orderBy('server_name')->paginate(20)]); }
    public function store(Request $request) {
        SavedStreamingServer::create($request->validate(['server_name'=>'required|string|max:255','server_url'=>'required|string','server_type'=>'nullable|string|max:50','player_type'=>'nullable|string|max:50','drm_scheme'=>'nullable|string','drm_license_url'=>'nullable|string','clearkey_key_id'=>'nullable|string','clearkey_key'=>'nullable|string','referer_value'=>'nullable|string','origin_value'=>'nullable|string','user_agent'=>'nullable|string','cookie_value'=>'nullable|string','ad_block_enabled'=>'boolean','notes'=>'nullable|string']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Saved server created.');
    }
    public function update(Request $request, string $id) {
        SavedStreamingServer::findOrFail($id)->update($request->validate(['server_name'=>'required|string|max:255','server_url'=>'required|string','server_type'=>'nullable|string|max:50','player_type'=>'nullable|string|max:50','drm_scheme'=>'nullable|string','drm_license_url'=>'nullable|string','clearkey_key_id'=>'nullable|string','clearkey_key'=>'nullable|string','referer_value'=>'nullable|string','origin_value'=>'nullable|string','user_agent'=>'nullable|string','cookie_value'=>'nullable|string','ad_block_enabled'=>'boolean','notes'=>'nullable|string']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Server updated.');
    }
    public function destroy(string $id) { SavedStreamingServer::findOrFail($id)->delete(); return back()->with('success','Server deleted.'); }
}
