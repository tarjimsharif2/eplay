@extends('layouts.app')
@section('title', $seoTitle)
@section('meta_description', $seoDescription)
@section('meta_keywords', $seoKeywords)
@section('og_image', $page->og_image_url ?? $siteSettings?->og_image_url ?? '')
@section('content')
<div class="container" style="padding:2rem 1rem;">
    <div style="max-width:800px;margin:0 auto;">
        <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:2rem;">
            <h1 style="font-size:2rem;font-weight:800;font-family:var(--font-display);margin-bottom:1.5rem;">{{ $page->title }}</h1>
            <div class="page-content prose" style="color:var(--foreground);line-height:1.8;">
                @if($page->content_type === 'html')
                    {!! $page->content !!}
                @elseif($page->content_type === 'markdown')
                    {!! \Illuminate\Support\Str::markdown($page->content ?? '') !!}
                @else
                    {{ $page->content }}
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
