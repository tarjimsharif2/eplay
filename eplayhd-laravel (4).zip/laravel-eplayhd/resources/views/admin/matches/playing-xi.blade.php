@extends('layouts.admin')
@section('title', 'Playing XI')
@section('content')
<div class="admin-header">
    <div>
        <a href="{{ route('admin.matches.show', $match->id) }}" style="font-size:0.875rem;color:var(--muted);">← Back to Match</a>
        <h1 class="admin-page-title">Playing XI: {{ $match->teamA?->short_name }} vs {{ $match->teamB?->short_name }}</h1>
    </div>
    <button onclick="document.getElementById('add-player-modal').style.display='flex'" class="btn-primary-sm">+ Add Player</button>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;">
    @foreach([$match->teamA, $match->teamB] as $team)
    <div class="admin-card">
        <div class="admin-card-header"><h2 class="admin-card-title">{{ $team?->name }}</h2></div>
        <table class="admin-table">
            <thead><tr><th>#</th><th>Player</th><th>Role</th><th>Badges</th><th></th></tr></thead>
            <tbody>
                @forelse($match->playingXI->where('team_id',$team?->id)->sortBy('batting_order') as $p)
                <tr>
                    <td style="font-size:0.8rem;color:var(--muted)">{{ $p->batting_order }}</td>
                    <td style="font-size:0.875rem;font-weight:{{ $p->is_captain ? '700' : '400' }}">{{ $p->player_name }}</td>
                    <td style="font-size:0.8rem;color:var(--muted)">{{ $p->player_role }}</td>
                    <td style="font-size:0.75rem;">
                        @if($p->is_captain)<span style="color:var(--primary);font-weight:700">C</span> @endif
                        @if($p->is_vice_captain)<span style="color:var(--muted)">VC</span> @endif
                        @if($p->is_wicket_keeper)<span style="color:var(--primary)">WK</span> @endif
                        @if($p->is_bench)<span style="color:#ca8a04">B</span> @endif
                    </td>
                    <td>
                        <form method="POST" action="{{ route('admin.match.playing-xi.destroy', [$match->id, $p->id]) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Remove player?">×</button></form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="5" style="color:var(--muted);padding:1rem;text-align:center;">No players added.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @endforeach
</div>

{{-- Add Player Modal --}}
<div id="add-player-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:500px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
            <h3 style="font-family:var(--font-display);font-weight:700;">Add Player</h3>
            <button onclick="document.getElementById('add-player-modal').style.display='none'" style="color:var(--muted);font-size:1.5rem;background:none;border:none;cursor:pointer;">&times;</button>
        </div>
        <form method="POST" action="{{ route('admin.match.playing-xi.store', $match->id) }}">@csrf
            <div class="form-group"><label class="form-label">Team *</label>
                <select name="team_id" class="form-select" required>
                    <option value="{{ $match->teamA?->id }}">{{ $match->teamA?->name }}</option>
                    <option value="{{ $match->teamB?->id }}">{{ $match->teamB?->name }}</option>
                </select></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Player Name *</label><input type="text" name="player_name" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Role</label>
                    <select name="player_role" class="form-select">
                        @foreach(['Batsman','Bowler','All-Rounder','Wicket-Keeper','Wicket-Keeper Batsman'] as $r)<option>{{ $r }}</option>@endforeach
                    </select></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Batting Order</label><input type="number" name="batting_order" class="form-input" min="1" max="11"></div>
                <div class="form-group"><label class="form-label">Player Image URL</label><input type="text" name="player_image" class="form-input" placeholder="https://…"></div>
            </div>
            <div style="display:flex;gap:1.5rem;flex-wrap:wrap;margin-bottom:1rem;">
                @foreach([['is_captain','Captain'],['is_vice_captain','Vice Captain'],['is_wicket_keeper','WK'],['is_bench','Bench']] as [$f,$l])
                <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.875rem;cursor:pointer">
                    <input type="hidden" name="{{ $f }}" value="0">
                    <input type="checkbox" name="{{ $f }}" class="form-checkbox" value="1"> {{ $l }}
                </label>
                @endforeach
            </div>
            <div style="display:flex;gap:0.75rem;">
                <button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add Player</button>
                <button type="button" onclick="document.getElementById('add-player-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
