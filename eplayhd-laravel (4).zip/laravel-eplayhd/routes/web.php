<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\MatchController;
use App\Http\Controllers\TournamentController;
use App\Http\Controllers\ChannelController;
use App\Http\Controllers\DynamicPageController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\AdsTxtController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\MatchAdminController;
use App\Http\Controllers\Admin\TournamentAdminController;
use App\Http\Controllers\Admin\TeamAdminController;
use App\Http\Controllers\Admin\SportAdminController;
use App\Http\Controllers\Admin\ChannelAdminController;
use App\Http\Controllers\Admin\StreamingServerAdminController;
use App\Http\Controllers\Admin\BannerAdminController;
use App\Http\Controllers\Admin\SiteSettingsController;
use App\Http\Controllers\Admin\DynamicPageAdminController;
use App\Http\Controllers\Admin\CustomMenuAdminController;
use App\Http\Controllers\Admin\UserAdminController;
use App\Http\Controllers\Admin\SponsorNoticeAdminController;
use App\Http\Controllers\Admin\PointsTableAdminController;
use App\Http\Controllers\Admin\SavedServerAdminController;
use App\Http\Controllers\Admin\PlayingXIAdminController;
use App\Http\Controllers\Admin\InningsAdminController;

/*
|--------------------------------------------------------------------------
| Public Routes
|--------------------------------------------------------------------------
*/

// Home
Route::get('/', [HomeController::class, 'index'])->name('home');

// Match pages
Route::get('/match/{slug}', [MatchController::class, 'show'])->name('match.show');

// Tournament pages
Route::get('/tournament/{slug}', [TournamentController::class, 'show'])->name('tournament.show');

// Channel pages
Route::get('/channels', [ChannelController::class, 'index'])->name('channels.index');
Route::get('/channel/{slug}', [ChannelController::class, 'show'])->name('channel.show');

// Dynamic CMS pages
Route::get('/page/{slug}', [DynamicPageController::class, 'show'])->name('page.show');

// SEO / Technical files
Route::get('/ads.txt', [AdsTxtController::class, 'show'])->name('ads.txt');
Route::get('/sitemap.xml', [SitemapController::class, 'show'])->name('sitemap');
Route::get('/robots.txt', [SitemapController::class, 'robots'])->name('robots.txt');

/*
|--------------------------------------------------------------------------
| Auth Routes
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/auth', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/auth/login', [AuthController::class, 'login'])->name('auth.login');
});

Route::post('/auth/logout', [AuthController::class, 'logout'])->name('auth.logout')
    ->middleware('auth');

/*
|--------------------------------------------------------------------------
| API Routes (JSON)
|--------------------------------------------------------------------------
*/
Route::prefix('api')->group(function () {
    Route::get('/matches', [MatchController::class, 'apiMatches'])->name('api.matches');
    Route::get('/match/{id}/servers', [MatchController::class, 'apiServers'])->name('api.servers');
    Route::get('/match/{id}/score', [MatchController::class, 'apiScore'])->name('api.score');
    Route::get('/match/{id}/innings', [MatchController::class, 'apiInnings'])->name('api.innings');
    Route::get('/match/{id}/playing-xi', [MatchController::class, 'apiPlayingXI'])->name('api.playing-xi');
    Route::post('/match/{id}/server/{serverId}/not-working', [MatchController::class, 'reportNotWorking'])->name('api.server.not-working');
    Route::post('/match/{id}/server/{serverId}/working', [MatchController::class, 'reportWorking'])->name('api.server.working');
    Route::get('/tournaments', [TournamentController::class, 'apiTournaments'])->name('api.tournaments');
    Route::get('/tournament/{id}/points-table', [TournamentController::class, 'apiPointsTable'])->name('api.points-table');
    Route::get('/channels', [ChannelController::class, 'apiChannels'])->name('api.channels');
    Route::get('/site-settings', [\App\Http\Controllers\Api\SiteSettingsApiController::class, 'index'])->name('api.site-settings');
    Route::get('/banners', [\App\Http\Controllers\Api\BannersApiController::class, 'index'])->name('api.banners');
    Route::get('/menus', [\App\Http\Controllers\Api\MenuApiController::class, 'index'])->name('api.menus');
    Route::post('/ad-click', [\App\Http\Controllers\Api\AdClickController::class, 'track'])->name('api.ad-click');
});

/*
|--------------------------------------------------------------------------
| Admin Routes (Protected)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'admin'])->group(function () {
    // Use site settings admin_slug for admin URL
    Route::get('/admin', [DashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/admin/dashboard', [DashboardController::class, 'index']);

    // Matches
    Route::prefix('admin/matches')->name('admin.matches.')->group(function () {
        Route::get('/', [MatchAdminController::class, 'index'])->name('index');
        Route::get('/create', [MatchAdminController::class, 'create'])->name('create');
        Route::post('/', [MatchAdminController::class, 'store'])->name('store');
        Route::get('/{id}', [MatchAdminController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [MatchAdminController::class, 'edit'])->name('edit');
        Route::put('/{id}', [MatchAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [MatchAdminController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/status', [MatchAdminController::class, 'updateStatus'])->name('status');
        Route::post('/{id}/score', [MatchAdminController::class, 'updateScore'])->name('score');
        // Streaming servers
        Route::prefix('/{matchId}/servers')->name('servers.')->group(function () {
            Route::get('/', [StreamingServerAdminController::class, 'index'])->name('index');
            Route::post('/', [StreamingServerAdminController::class, 'store'])->name('store');
            Route::put('/{id}', [StreamingServerAdminController::class, 'update'])->name('update');
            Route::delete('/{id}', [StreamingServerAdminController::class, 'destroy'])->name('destroy');
            Route::post('/reorder', [StreamingServerAdminController::class, 'reorder'])->name('reorder');
        });
        // Playing XI
        Route::prefix('/{matchId}/playing-xi')->name('playing-xi.')->group(function () {
            Route::get('/', [PlayingXIAdminController::class, 'index'])->name('index');
            Route::post('/', [PlayingXIAdminController::class, 'store'])->name('store');
            Route::put('/{id}', [PlayingXIAdminController::class, 'update'])->name('update');
            Route::delete('/{id}', [PlayingXIAdminController::class, 'destroy'])->name('destroy');
        });
        // Innings
        Route::prefix('/{matchId}/innings')->name('innings.')->group(function () {
            Route::get('/', [InningsAdminController::class, 'index'])->name('index');
            Route::post('/', [InningsAdminController::class, 'store'])->name('store');
            Route::put('/{id}', [InningsAdminController::class, 'update'])->name('update');
            Route::delete('/{id}', [InningsAdminController::class, 'destroy'])->name('destroy');
        });
        // Points Table
        Route::prefix('/{matchId}/points-table')->name('points.')->group(function () {
            Route::get('/', [PointsTableAdminController::class, 'index'])->name('index');
            Route::post('/', [PointsTableAdminController::class, 'store'])->name('store');
            Route::put('/{id}', [PointsTableAdminController::class, 'update'])->name('update');
            Route::delete('/{id}', [PointsTableAdminController::class, 'destroy'])->name('destroy');
        });
        // Sponsor Notices
        Route::prefix('/{matchId}/sponsor-notices')->name('sponsor.')->group(function () {
            Route::post('/', [SponsorNoticeAdminController::class, 'store'])->name('store');
            Route::put('/{id}', [SponsorNoticeAdminController::class, 'update'])->name('update');
            Route::delete('/{id}', [SponsorNoticeAdminController::class, 'destroy'])->name('destroy');
        });
    });

    // Tournaments
    Route::prefix('admin/tournaments')->name('admin.tournaments.')->group(function () {
        Route::get('/', [TournamentAdminController::class, 'index'])->name('index');
        Route::get('/create', [TournamentAdminController::class, 'create'])->name('create');
        Route::post('/', [TournamentAdminController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [TournamentAdminController::class, 'edit'])->name('edit');
        Route::put('/{id}', [TournamentAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [TournamentAdminController::class, 'destroy'])->name('destroy');
        Route::get('/{id}/points-table', [PointsTableAdminController::class, 'tournamentTable'])->name('points-table');
        Route::post('/{id}/points-table', [PointsTableAdminController::class, 'storeTournament'])->name('points-table.store');
        Route::put('/{id}/points-table/{entryId}', [PointsTableAdminController::class, 'updateTournament'])->name('points-table.update');
        Route::delete('/{id}/points-table/{entryId}', [PointsTableAdminController::class, 'destroyTournament'])->name('points-table.destroy');
    });

    // Teams
    Route::prefix('admin/teams')->name('admin.teams.')->group(function () {
        Route::get('/', [TeamAdminController::class, 'index'])->name('index');
        Route::post('/', [TeamAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [TeamAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [TeamAdminController::class, 'destroy'])->name('destroy');
    });

    // Sports
    Route::prefix('admin/sports')->name('admin.sports.')->group(function () {
        Route::get('/', [SportAdminController::class, 'index'])->name('index');
        Route::post('/', [SportAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [SportAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [SportAdminController::class, 'destroy'])->name('destroy');
    });

    // Channels
    Route::prefix('admin/channels')->name('admin.channels.')->group(function () {
        Route::get('/', [ChannelAdminController::class, 'index'])->name('index');
        Route::post('/', [ChannelAdminController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [ChannelAdminController::class, 'edit'])->name('edit');
        Route::put('/{id}', [ChannelAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [ChannelAdminController::class, 'destroy'])->name('destroy');
        // Channel Servers
        Route::prefix('/{channelId}/servers')->name('servers.')->group(function () {
            Route::post('/', [ChannelAdminController::class, 'addServer'])->name('store');
            Route::put('/{id}', [ChannelAdminController::class, 'updateServer'])->name('update');
            Route::delete('/{id}', [ChannelAdminController::class, 'destroyServer'])->name('destroy');
        });
    });

    // Banners
    Route::prefix('admin/banners')->name('admin.banners.')->group(function () {
        Route::get('/', [BannerAdminController::class, 'index'])->name('index');
        Route::post('/', [BannerAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [BannerAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [BannerAdminController::class, 'destroy'])->name('destroy');
        Route::post('/reorder', [BannerAdminController::class, 'reorder'])->name('reorder');
    });

    // Dynamic Pages
    Route::prefix('admin/pages')->name('admin.pages.')->group(function () {
        Route::get('/', [DynamicPageAdminController::class, 'index'])->name('index');
        Route::get('/create', [DynamicPageAdminController::class, 'create'])->name('create');
        Route::post('/', [DynamicPageAdminController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [DynamicPageAdminController::class, 'edit'])->name('edit');
        Route::put('/{id}', [DynamicPageAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [DynamicPageAdminController::class, 'destroy'])->name('destroy');
    });

    // Custom Menus
    Route::prefix('admin/menus')->name('admin.menus.')->group(function () {
        Route::get('/', [CustomMenuAdminController::class, 'index'])->name('index');
        Route::post('/', [CustomMenuAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [CustomMenuAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [CustomMenuAdminController::class, 'destroy'])->name('destroy');
        Route::post('/reorder', [CustomMenuAdminController::class, 'reorder'])->name('reorder');
    });

    // Sponsor Notices
    Route::prefix('admin/sponsor-notices')->name('admin.sponsor-notices.')->group(function () {
        Route::get('/', [SponsorNoticeAdminController::class, 'index'])->name('index');
        Route::post('/', [SponsorNoticeAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [SponsorNoticeAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [SponsorNoticeAdminController::class, 'destroy'])->name('destroy');
    });

    // Saved Servers
    Route::prefix('admin/saved-servers')->name('admin.saved-servers.')->group(function () {
        Route::get('/', [SavedServerAdminController::class, 'index'])->name('index');
        Route::post('/', [SavedServerAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [SavedServerAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [SavedServerAdminController::class, 'destroy'])->name('destroy');
    });

    // Users & Roles
    Route::prefix('admin/users')->name('admin.users.')->group(function () {
        Route::get('/', [UserAdminController::class, 'index'])->name('index');
        Route::post('/', [UserAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [UserAdminController::class, 'update'])->name('update');
        Route::delete('/{id}', [UserAdminController::class, 'destroy'])->name('destroy');
    });

    // Site Settings
    Route::get('/admin/settings', [SiteSettingsController::class, 'index'])->name('admin.settings');
    Route::put('/admin/settings', [SiteSettingsController::class, 'update'])->name('admin.settings.update');

    // Admin API endpoints (JSON responses for AJAX)
    Route::prefix('admin/api')->name('admin.api.')->group(function () {
        Route::get('/matches', [MatchAdminController::class, 'apiIndex'])->name('matches');
        Route::get('/teams/search', [TeamAdminController::class, 'search'])->name('teams.search');
        Route::get('/tournaments/search', [TournamentAdminController::class, 'search'])->name('tournaments.search');
        Route::post('/matches/{id}/sync-score', [MatchAdminController::class, 'syncScore'])->name('sync-score');
        Route::post('/sitemap/ping', [SiteSettingsController::class, 'pingSitemap'])->name('sitemap.ping');
        Route::post('/google-index', [SiteSettingsController::class, 'googleIndex'])->name('google.index');
        Route::get('/stats', [DashboardController::class, 'stats'])->name('stats');
    });
});

// Dynamic admin slug support
Route::get('/{adminSlug}', function (string $adminSlug) {
    $settings = \App\Models\SiteSettings::first();
    $configuredSlug = $settings?->admin_slug ?? 'admin';

    if ($adminSlug === $configuredSlug && $adminSlug !== 'admin') {
        return redirect('/admin');
    }

    // Otherwise treat as dynamic page or 404
    $page = \App\Models\DynamicPage::where('slug', $adminSlug)->where('is_active', true)->first();
    if ($page) {
        return redirect('/page/' . $adminSlug);
    }

    abort(404);
})->where('adminSlug', '[a-zA-Z0-9\-_]+');
