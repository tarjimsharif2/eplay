-- ============================================================
-- ePlayHD - Complete MySQL Database Schema
-- Converted from Supabase/PostgreSQL migrations
-- Compatible with MySQL 8.0+
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+00:00';

-- ============================================================
-- DROP TABLES (in order to avoid FK constraint errors)
-- ============================================================
DROP TABLE IF EXISTS `sitemap_ping_history`;
DROP TABLE IF EXISTS `user_custom_roles`;
DROP TABLE IF EXISTS `custom_role_permissions`;
DROP TABLE IF EXISTS `user_permissions`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `admin_otp_codes`;
DROP TABLE IF EXISTS `sponsor_notices`;
DROP TABLE IF EXISTS `match_substitutions`;
DROP TABLE IF EXISTS `match_playing_xi`;
DROP TABLE IF EXISTS `match_innings`;
DROP TABLE IF EXISTS `match_api_scores`;
DROP TABLE IF EXISTS `ad_click_logs`;
DROP TABLE IF EXISTS `channel_streaming_servers`;
DROP TABLE IF EXISTS `channels`;
DROP TABLE IF EXISTS `streaming_servers`;
DROP TABLE IF EXISTS `saved_streaming_servers`;
DROP TABLE IF EXISTS `banners`;
DROP TABLE IF EXISTS `tournament_points_table`;
DROP TABLE IF EXISTS `matches`;
DROP TABLE IF EXISTS `teams`;
DROP TABLE IF EXISTS `tournaments`;
DROP TABLE IF EXISTS `sports`;
DROP TABLE IF EXISTS `cricket_series`;
DROP TABLE IF EXISTS `football_leagues`;
DROP TABLE IF EXISTS `dynamic_pages`;
DROP TABLE IF EXISTS `custom_menus`;
DROP TABLE IF EXISTS `sponsor_notices`;
DROP TABLE IF EXISTS `site_settings`;
DROP TABLE IF EXISTS `profiles`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `password_reset_tokens`;
DROP TABLE IF EXISTS `sessions`;
DROP TABLE IF EXISTS `cache`;
DROP TABLE IF EXISTS `jobs`;
DROP TABLE IF EXISTS `job_batches`;
DROP TABLE IF EXISTS `failed_jobs`;

-- ============================================================
-- LARAVEL CORE TABLES
-- ============================================================

CREATE TABLE `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `email_verified_at` TIMESTAMP NULL DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `remember_token` VARCHAR(100) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `password_reset_tokens` (
  `email` VARCHAR(255) NOT NULL PRIMARY KEY,
  `token` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `sessions` (
  `id` VARCHAR(255) NOT NULL PRIMARY KEY,
  `user_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `user_agent` TEXT NULL,
  `payload` LONGTEXT NOT NULL,
  `last_activity` INT NOT NULL,
  INDEX `sessions_user_id_index` (`user_id`),
  INDEX `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `cache` (
  `key` VARCHAR(255) NOT NULL PRIMARY KEY,
  `value` MEDIUMTEXT NOT NULL,
  `expiration` INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `queue` VARCHAR(255) NOT NULL,
  `payload` LONGTEXT NOT NULL,
  `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `reserved_at` INT UNSIGNED NULL DEFAULT NULL,
  `available_at` INT UNSIGNED NOT NULL,
  `created_at` INT UNSIGNED NOT NULL,
  INDEX `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `failed_jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `uuid` VARCHAR(255) NOT NULL UNIQUE,
  `connection` TEXT NOT NULL,
  `queue` TEXT NOT NULL,
  `payload` LONGTEXT NOT NULL,
  `exception` LONGTEXT NOT NULL,
  `failed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- APPLICATION TABLES
-- ============================================================

-- Profiles (extends users)
CREATE TABLE `profiles` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `user_id` BIGINT UNSIGNED NOT NULL UNIQUE,
  `email` VARCHAR(255) NULL DEFAULT NULL,
  `full_name` VARCHAR(255) NULL DEFAULT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_profiles_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Roles
CREATE TABLE `roles` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL UNIQUE,
  `display_name` VARCHAR(255) NOT NULL,
  `description` TEXT NULL DEFAULT NULL,
  `color` VARCHAR(50) NULL DEFAULT NULL,
  `is_system` TINYINT(1) NULL DEFAULT 0,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role Permissions
CREATE TABLE `role_permissions` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `role` ENUM('admin','moderator','editor','viewer') NOT NULL,
  `permission` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_role_permissions_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Roles
CREATE TABLE `user_roles` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `role` ENUM('admin','moderator','editor','viewer') NOT NULL DEFAULT 'viewer',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `user_roles_user_id_role_unique` (`user_id`, `role`),
  INDEX `idx_user_roles_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Custom Roles
CREATE TABLE `custom_role_permissions` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `role_id` CHAR(36) NOT NULL,
  `permission` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Custom Roles
CREATE TABLE `user_custom_roles` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `role_id` CHAR(36) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User Permissions
CREATE TABLE `user_permissions` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `permission` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin OTP Codes
CREATE TABLE `admin_otp_codes` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `otp_code` VARCHAR(10) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `is_used` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_admin_otp_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sports
CREATE TABLE `sports` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `icon_url` TEXT NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Teams
CREATE TABLE `teams` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `short_name` VARCHAR(20) NOT NULL,
  `logo_url` TEXT NULL DEFAULT NULL,
  `logo_background_color` VARCHAR(50) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_teams_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tournaments
CREATE TABLE `tournaments` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `name` VARCHAR(500) NOT NULL,
  `sport` VARCHAR(100) NOT NULL DEFAULT 'Cricket',
  `season` VARCHAR(100) NOT NULL,
  `logo_url` TEXT NULL DEFAULT NULL,
  `logo_background_color` VARCHAR(50) NULL DEFAULT NULL,
  `slug` VARCHAR(500) NULL DEFAULT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `show_in_menu` TINYINT(1) NOT NULL DEFAULT 0,
  `show_in_homepage` TINYINT(1) NOT NULL DEFAULT 0,
  `is_completed` TINYINT(1) NOT NULL DEFAULT 0,
  `seo_title` VARCHAR(500) NULL DEFAULT NULL,
  `seo_description` TEXT NULL DEFAULT NULL,
  `seo_keywords` TEXT NULL DEFAULT NULL,
  `total_matches` INT NULL DEFAULT NULL,
  `start_date` DATE NULL DEFAULT NULL,
  `end_date` DATE NULL DEFAULT NULL,
  `description` TEXT NULL DEFAULT NULL,
  `total_teams` INT NULL DEFAULT NULL,
  `total_venues` INT NULL DEFAULT NULL,
  `show_participating_teams` TINYINT(1) NULL DEFAULT 0,
  `participating_teams_position` VARCHAR(100) NULL DEFAULT 'below_table',
  `custom_participating_teams` JSON NULL DEFAULT NULL,
  `series_id` VARCHAR(255) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_tournaments_slug` (`slug`(191)),
  INDEX `idx_tournaments_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Matches
CREATE TABLE `matches` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `tournament_id` CHAR(36) NULL DEFAULT NULL,
  `team_a_id` CHAR(36) NOT NULL,
  `team_b_id` CHAR(36) NOT NULL,
  `sport_id` CHAR(36) NULL DEFAULT NULL,
  `match_number` VARCHAR(100) NULL DEFAULT NULL,
  `match_date` VARCHAR(50) NOT NULL,
  `match_time` VARCHAR(50) NOT NULL,
  `match_start_time` TIMESTAMP NULL DEFAULT NULL,
  `match_end_time` TIMESTAMP NULL DEFAULT NULL,
  `status` ENUM('upcoming','live','completed','abandoned','postponed') NOT NULL DEFAULT 'upcoming',
  `venue` VARCHAR(500) NULL DEFAULT NULL,
  `score_a` VARCHAR(200) NULL DEFAULT NULL,
  `score_b` VARCHAR(200) NULL DEFAULT NULL,
  `match_link` TEXT NULL DEFAULT NULL,
  `match_duration_minutes` INT NULL DEFAULT NULL,
  `match_minute` INT NULL DEFAULT NULL,
  `match_format` VARCHAR(50) NULL DEFAULT NULL,
  `match_label` VARCHAR(255) NULL DEFAULT NULL,
  `match_result` ENUM('team_a_won','team_b_won','tied','draw','no_result') NULL DEFAULT NULL,
  `result_margin` VARCHAR(255) NULL DEFAULT NULL,
  `is_priority` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `is_stumps` TINYINT(1) NULL DEFAULT 0,
  `stumps_time` VARCHAR(100) NULL DEFAULT NULL,
  `day_start_time` VARCHAR(100) NULL DEFAULT NULL,
  `next_day_start` VARCHAR(100) NULL DEFAULT NULL,
  `test_day` INT NULL DEFAULT NULL,
  `slug` VARCHAR(500) NULL DEFAULT NULL,
  `page_type` VARCHAR(50) NULL DEFAULT 'page',
  `seo_title` VARCHAR(500) NULL DEFAULT NULL,
  `seo_description` TEXT NULL DEFAULT NULL,
  `seo_keywords` TEXT NULL DEFAULT NULL,
  `api_score_enabled` TINYINT(1) NULL DEFAULT 0,
  `auto_sync_enabled` TINYINT(1) NULL DEFAULT 0,
  `auto_match_result_enabled` TINYINT(1) NULL DEFAULT 0,
  `cricapi_match_id` VARCHAR(255) NULL DEFAULT NULL,
  `cricbuzz_match_id` VARCHAR(255) NULL DEFAULT NULL,
  `espn_event_id` VARCHAR(255) NULL DEFAULT NULL,
  `score_source` VARCHAR(100) NULL DEFAULT NULL,
  `last_api_sync` TIMESTAMP NULL DEFAULT NULL,
  `manual_status_override` TINYINT(1) NULL DEFAULT 0,
  `toss_winner_id` CHAR(36) NULL DEFAULT NULL,
  `toss_decision` VARCHAR(50) NULL DEFAULT NULL,
  `goals_team_a` JSON NULL DEFAULT NULL,
  `goals_team_b` JSON NULL DEFAULT NULL,
  `show_playing_xi` TINYINT(1) NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`tournament_id`) REFERENCES `tournaments`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`team_a_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`team_b_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`sport_id`) REFERENCES `sports`(`id`) ON DELETE SET NULL,
  INDEX `idx_matches_tournament_id` (`tournament_id`),
  INDEX `idx_matches_team_a_id` (`team_a_id`),
  INDEX `idx_matches_team_b_id` (`team_b_id`),
  INDEX `idx_matches_status` (`status`),
  INDEX `idx_matches_slug` (`slug`(191)),
  INDEX `idx_matches_sport_id` (`sport_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Match Innings (Cricket)
CREATE TABLE `match_innings` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `match_id` CHAR(36) NOT NULL,
  `innings_number` INT NOT NULL,
  `batting_team_id` CHAR(36) NOT NULL,
  `runs` INT NULL DEFAULT 0,
  `wickets` INT NULL DEFAULT 0,
  `overs` DECIMAL(5,1) NULL DEFAULT 0.0,
  `extras` INT NULL DEFAULT 0,
  `declared` TINYINT(1) NULL DEFAULT 0,
  `is_current` TINYINT(1) NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`batting_team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
  INDEX `idx_innings_match_id` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Match Playing XI
CREATE TABLE `match_playing_xi` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `match_id` CHAR(36) NOT NULL,
  `team_id` CHAR(36) NOT NULL,
  `player_name` VARCHAR(255) NOT NULL,
  `player_role` VARCHAR(100) NULL DEFAULT NULL,
  `player_image` TEXT NULL DEFAULT NULL,
  `batting_order` INT NULL DEFAULT NULL,
  `is_captain` TINYINT(1) NULL DEFAULT 0,
  `is_vice_captain` TINYINT(1) NULL DEFAULT 0,
  `is_wicket_keeper` TINYINT(1) NULL DEFAULT 0,
  `is_bench` TINYINT(1) NULL DEFAULT 0,
  `change_status` VARCHAR(100) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
  INDEX `idx_playing_xi_match_id` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Match Substitutions (Football)
CREATE TABLE `match_substitutions` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `match_id` CHAR(36) NOT NULL,
  `team_id` CHAR(36) NOT NULL,
  `player_in` VARCHAR(255) NOT NULL,
  `player_out` VARCHAR(255) NOT NULL,
  `minute` VARCHAR(20) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
  INDEX `idx_substitutions_match_id` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Match API Scores
CREATE TABLE `match_api_scores` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `match_id` CHAR(36) NOT NULL UNIQUE,
  `api_event_key` VARCHAR(255) NULL DEFAULT NULL,
  `home_team` VARCHAR(255) NULL DEFAULT NULL,
  `away_team` VARCHAR(255) NULL DEFAULT NULL,
  `home_score` VARCHAR(100) NULL DEFAULT NULL,
  `away_score` VARCHAR(100) NULL DEFAULT NULL,
  `home_overs` VARCHAR(50) NULL DEFAULT NULL,
  `away_overs` VARCHAR(50) NULL DEFAULT NULL,
  `status` VARCHAR(100) NULL DEFAULT NULL,
  `status_info` TEXT NULL DEFAULT NULL,
  `toss` TEXT NULL DEFAULT NULL,
  `venue` VARCHAR(500) NULL DEFAULT NULL,
  `event_live` TINYINT(1) NULL DEFAULT 0,
  `batsmen` JSON NULL DEFAULT NULL,
  `bowlers` JSON NULL DEFAULT NULL,
  `extras` JSON NULL DEFAULT NULL,
  `scorecard` JSON NULL DEFAULT NULL,
  `last_synced_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE,
  INDEX `idx_api_scores_match_id` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tournament Points Table
CREATE TABLE `tournament_points_table` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `tournament_id` CHAR(36) NOT NULL,
  `team_id` CHAR(36) NOT NULL,
  `played` INT NOT NULL DEFAULT 0,
  `won` INT NOT NULL DEFAULT 0,
  `lost` INT NOT NULL DEFAULT 0,
  `tied` INT NOT NULL DEFAULT 0,
  `no_result` INT NOT NULL DEFAULT 0,
  `points` INT NOT NULL DEFAULT 0,
  `net_run_rate` DECIMAL(10,3) NULL DEFAULT 0.000,
  `for_runs` INT NULL DEFAULT 0,
  `for_overs` DECIMAL(10,1) NULL DEFAULT 0.0,
  `against_runs` INT NULL DEFAULT 0,
  `against_overs` DECIMAL(10,1) NULL DEFAULT 0.0,
  `position` INT NULL DEFAULT NULL,
  `qualified` TINYINT(1) NULL DEFAULT 0,
  `eliminated` TINYINT(1) NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`tournament_id`) REFERENCES `tournaments`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `uq_points_tournament_team` (`tournament_id`, `team_id`),
  INDEX `idx_points_tournament_id` (`tournament_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Streaming Servers (per match)
CREATE TABLE `streaming_servers` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `match_id` CHAR(36) NOT NULL,
  `server_name` VARCHAR(255) NOT NULL,
  `server_url` TEXT NOT NULL,
  `server_type` VARCHAR(50) NOT NULL DEFAULT 'hls',
  `player_type` VARCHAR(50) NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `original_display_order` INT NULL DEFAULT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `is_working` TINYINT(1) NULL DEFAULT 1,
  `not_working_reports` INT NULL DEFAULT 0,
  `last_reported_at` TIMESTAMP NULL DEFAULT NULL,
  `drm_scheme` VARCHAR(100) NULL DEFAULT NULL,
  `drm_license_url` TEXT NULL DEFAULT NULL,
  `clearkey_key_id` VARCHAR(500) NULL DEFAULT NULL,
  `clearkey_key` VARCHAR(500) NULL DEFAULT NULL,
  `referer_value` TEXT NULL DEFAULT NULL,
  `origin_value` TEXT NULL DEFAULT NULL,
  `user_agent` TEXT NULL DEFAULT NULL,
  `cookie_value` TEXT NULL DEFAULT NULL,
  `ad_block_enabled` TINYINT(1) NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE,
  INDEX `idx_streaming_match_id` (`match_id`),
  INDEX `idx_streaming_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Saved Streaming Servers (template library)
CREATE TABLE `saved_streaming_servers` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `server_name` VARCHAR(255) NOT NULL,
  `server_url` TEXT NOT NULL,
  `server_type` VARCHAR(50) NOT NULL DEFAULT 'hls',
  `player_type` VARCHAR(50) NULL DEFAULT NULL,
  `drm_scheme` VARCHAR(100) NULL DEFAULT NULL,
  `drm_license_url` TEXT NULL DEFAULT NULL,
  `clearkey_key_id` VARCHAR(500) NULL DEFAULT NULL,
  `clearkey_key` VARCHAR(500) NULL DEFAULT NULL,
  `referer_value` TEXT NULL DEFAULT NULL,
  `origin_value` TEXT NULL DEFAULT NULL,
  `user_agent` TEXT NULL DEFAULT NULL,
  `cookie_value` TEXT NULL DEFAULT NULL,
  `ad_block_enabled` TINYINT(1) NULL DEFAULT 0,
  `notes` TEXT NULL DEFAULT NULL,
  `tags` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Channels
CREATE TABLE `channels` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(500) NULL DEFAULT NULL,
  `description` TEXT NULL DEFAULT NULL,
  `logo_url` TEXT NULL DEFAULT NULL,
  `logo_background_color` VARCHAR(50) NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `seo_title` VARCHAR(500) NULL DEFAULT NULL,
  `seo_description` TEXT NULL DEFAULT NULL,
  `seo_keywords` TEXT NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_channels_slug` (`slug`(191)),
  INDEX `idx_channels_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Channel Streaming Servers
CREATE TABLE `channel_streaming_servers` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `channel_id` CHAR(36) NOT NULL,
  `server_name` VARCHAR(255) NOT NULL,
  `server_url` TEXT NOT NULL,
  `server_type` VARCHAR(50) NOT NULL DEFAULT 'hls',
  `player_type` VARCHAR(50) NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `original_display_order` INT NULL DEFAULT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `is_working` TINYINT(1) NULL DEFAULT 1,
  `drm_scheme` VARCHAR(100) NULL DEFAULT NULL,
  `drm_license_url` TEXT NULL DEFAULT NULL,
  `clearkey_key_id` VARCHAR(500) NULL DEFAULT NULL,
  `clearkey_key` VARCHAR(500) NULL DEFAULT NULL,
  `referer_value` TEXT NULL DEFAULT NULL,
  `origin_value` TEXT NULL DEFAULT NULL,
  `user_agent` TEXT NULL DEFAULT NULL,
  `cookie_value` TEXT NULL DEFAULT NULL,
  `ad_block_enabled` TINYINT(1) NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`channel_id`) REFERENCES `channels`(`id`) ON DELETE CASCADE,
  INDEX `idx_ch_servers_channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Banners
CREATE TABLE `banners` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `title` VARCHAR(500) NOT NULL,
  `subtitle` TEXT NULL DEFAULT NULL,
  `image_url` TEXT NOT NULL,
  `link_url` TEXT NULL DEFAULT NULL,
  `banner_type` ENUM('match','tournament','custom') NULL DEFAULT 'custom',
  `badge_type` ENUM('none','live','upcoming','watch_now') NULL DEFAULT 'none',
  `match_id` CHAR(36) NULL DEFAULT NULL,
  `tournament_id` CHAR(36) NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`tournament_id`) REFERENCES `tournaments`(`id`) ON DELETE SET NULL,
  INDEX `idx_banners_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sponsor Notices
CREATE TABLE `sponsor_notices` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `title` VARCHAR(500) NOT NULL,
  `content` TEXT NOT NULL,
  `position` VARCHAR(100) NOT NULL DEFAULT 'before_player',
  `display_type` VARCHAR(50) NOT NULL DEFAULT 'banner',
  `background_color` VARCHAR(50) NULL DEFAULT NULL,
  `text_color` VARCHAR(50) NULL DEFAULT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `is_global` TINYINT(1) NULL DEFAULT 0,
  `match_id` CHAR(36) NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE,
  INDEX `idx_sponsor_match_id` (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dynamic Pages (CMS)
CREATE TABLE `dynamic_pages` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `title` VARCHAR(500) NOT NULL,
  `slug` VARCHAR(500) NOT NULL UNIQUE,
  `content` LONGTEXT NULL DEFAULT NULL,
  `content_type` VARCHAR(50) NOT NULL DEFAULT 'html',
  `seo_title` VARCHAR(500) NULL DEFAULT NULL,
  `seo_description` TEXT NULL DEFAULT NULL,
  `seo_keywords` TEXT NULL DEFAULT NULL,
  `og_image_url` TEXT NULL DEFAULT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `show_in_header` TINYINT(1) NULL DEFAULT 0,
  `show_in_footer` TINYINT(1) NULL DEFAULT 0,
  `display_order` INT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_dynamic_pages_slug` (`slug`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Custom Menus
CREATE TABLE `custom_menus` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `url` TEXT NULL DEFAULT NULL,
  `icon_name` VARCHAR(100) NULL DEFAULT NULL,
  `menu_type` VARCHAR(50) NULL DEFAULT 'link',
  `parent_id` CHAR(36) NULL DEFAULT NULL,
  `display_order` INT NULL DEFAULT 0,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `open_in_new_tab` TINYINT(1) NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`parent_id`) REFERENCES `custom_menus`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cricket Series
CREATE TABLE `cricket_series` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `series_id` VARCHAR(255) NOT NULL,
  `series_name` VARCHAR(500) NOT NULL,
  `start_date` DATE NULL DEFAULT NULL,
  `end_date` DATE NULL DEFAULT NULL,
  `match_count` INT NULL DEFAULT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `last_synced_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Football Leagues
CREATE TABLE `football_leagues` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `league_code` VARCHAR(100) NOT NULL,
  `league_name` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) NULL DEFAULT 1,
  `last_synced_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ad Click Logs
CREATE TABLE `ad_click_logs` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `device_fingerprint` VARCHAR(255) NOT NULL UNIQUE,
  `click_count` INT NOT NULL DEFAULT 1,
  `first_click_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_click_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `blocked_until` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_ad_clicks_fingerprint` (`device_fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sitemap Ping History
CREATE TABLE `sitemap_ping_history` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `sitemap_url` TEXT NOT NULL,
  `ping_type` VARCHAR(100) NOT NULL DEFAULT 'google',
  `results` JSON NULL DEFAULT NULL,
  `success_count` INT NULL DEFAULT 0,
  `total_count` INT NULL DEFAULT 0,
  `triggered_by` VARCHAR(255) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Site Settings
CREATE TABLE `site_settings` (
  `id` CHAR(36) NOT NULL DEFAULT (UUID()) PRIMARY KEY,
  `site_name` VARCHAR(255) NOT NULL DEFAULT 'ePlayHD',
  `site_title` VARCHAR(500) NOT NULL DEFAULT 'ePlayHD - Live Sports Streaming',
  `site_description` TEXT NULL DEFAULT NULL,
  `site_keywords` TEXT NULL DEFAULT NULL,
  `logo_url` TEXT NULL DEFAULT NULL,
  `favicon_url` TEXT NULL DEFAULT NULL,
  `og_image_url` TEXT NULL DEFAULT NULL,
  `canonical_url` TEXT NULL DEFAULT NULL,
  `footer_text` TEXT NULL DEFAULT NULL,
  `disclaimer_text` TEXT NULL DEFAULT NULL,
  `show_disclaimer` TINYINT(1) NULL DEFAULT 1,
  `telegram_link` TEXT NULL DEFAULT NULL,
  `twitter_handle` VARCHAR(100) NULL DEFAULT NULL,
  `facebook_app_id` VARCHAR(100) NULL DEFAULT NULL,
  `social_links` JSON NULL DEFAULT NULL,
  -- Admin settings
  `admin_slug` VARCHAR(255) NULL DEFAULT 'admin',
  -- Ad settings
  `ads_enabled` TINYINT(1) NULL DEFAULT 0,
  `ads_txt_content` LONGTEXT NULL DEFAULT NULL,
  `google_adsense_id` VARCHAR(100) NULL DEFAULT NULL,
  `header_ad_code` LONGTEXT NULL DEFAULT NULL,
  `footer_ad_code` LONGTEXT NULL DEFAULT NULL,
  `sidebar_ad_code` LONGTEXT NULL DEFAULT NULL,
  `in_article_ad_code` LONGTEXT NULL DEFAULT NULL,
  `popup_ad_code` LONGTEXT NULL DEFAULT NULL,
  `multiple_ad_codes` JSON NULL DEFAULT NULL,
  `ad_block_rules` JSON NULL DEFAULT NULL,
  `ad_click_protection` JSON NULL DEFAULT NULL,
  -- Analytics
  `google_analytics_id` VARCHAR(100) NULL DEFAULT NULL,
  -- SEO
  `robots_txt` LONGTEXT NULL DEFAULT NULL,
  `schema_org_enabled` TINYINT(1) NULL DEFAULT 1,
  -- Custom code
  `custom_header_code` LONGTEXT NULL DEFAULT NULL,
  `custom_footer_code` LONGTEXT NULL DEFAULT NULL,
  -- Homepage settings
  `homepage_channels_limit` INT NULL DEFAULT 6,
  `homepage_completed_days` INT NULL DEFAULT 3,
  `slider_duration_seconds` INT NULL DEFAULT 5,
  -- Match page ad positions
  `match_page_ad_positions` JSON NULL DEFAULT NULL,
  `tournament_page_ad_positions` JSON NULL DEFAULT NULL,
  -- Maintenance mode
  `maintenance_mode` TINYINT(1) NULL DEFAULT 0,
  `maintenance_title` VARCHAR(500) NULL DEFAULT NULL,
  `maintenance_subtitle` VARCHAR(500) NULL DEFAULT NULL,
  `maintenance_description` TEXT NULL DEFAULT NULL,
  `maintenance_estimated_time` VARCHAR(255) NULL DEFAULT NULL,
  `maintenance_end_time` VARCHAR(255) NULL DEFAULT NULL,
  `maintenance_show_countdown` TINYINT(1) NULL DEFAULT 0,
  `maintenance_contact_email` VARCHAR(255) NULL DEFAULT NULL,
  `maintenance_social_message` TEXT NULL DEFAULT NULL,
  -- API settings
  `api_cricket_enabled` TINYINT(1) NULL DEFAULT 0,
  `api_cricket_key` VARCHAR(500) NULL DEFAULT NULL,
  `cricket_api_enabled` TINYINT(1) NULL DEFAULT 0,
  `cricket_api_key` VARCHAR(500) NULL DEFAULT NULL,
  `api_sync_interval_seconds` INT NULL DEFAULT 60,
  `auto_match_result_enabled` TINYINT(1) NULL DEFAULT 0,
  `rapidapi_enabled` TINYINT(1) NULL DEFAULT 0,
  `rapidapi_key` VARCHAR(500) NULL DEFAULT NULL,
  `rapidapi_endpoints` JSON NULL DEFAULT NULL,
  -- Points table
  `points_table_auto_sync_enabled` TINYINT(1) NULL DEFAULT 0,
  `points_table_sync_time` VARCHAR(100) NULL DEFAULT NULL,
  -- SMTP
  `smtp_enabled` TINYINT(1) NULL DEFAULT 0,
  `smtp_host` VARCHAR(255) NULL DEFAULT NULL,
  `smtp_port` INT NULL DEFAULT 587,
  `smtp_user` VARCHAR(255) NULL DEFAULT NULL,
  `smtp_password` VARCHAR(500) NULL DEFAULT NULL,
  `smtp_from_email` VARCHAR(255) NULL DEFAULT NULL,
  `smtp_from_name` VARCHAR(255) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Default admin user (password: admin123 - bcrypt hashed)
INSERT INTO `users` (`name`, `email`, `password`, `created_at`, `updated_at`) VALUES
('Admin', 'admin@eplayhd.com', '$2y$12$9Y7LT6M1qz4bJfTJ6J0BG.EqBJlwL3GDf/fIHH/ICqmG/bvpvVD6q', NOW(), NOW());

-- Admin profile
INSERT INTO `profiles` (`id`, `user_id`, `email`, `full_name`, `is_admin`) VALUES
(UUID(), 1, 'admin@eplayhd.com', 'Admin', 1);

-- Admin role
INSERT INTO `user_roles` (`id`, `user_id`, `role`) VALUES
(UUID(), 1, 'admin');

-- Default Sports
INSERT INTO `sports` (`id`, `name`, `display_order`) VALUES
(UUID(), 'Cricket', 1),
(UUID(), 'Football', 2),
(UUID(), 'Tennis', 3),
(UUID(), 'Basketball', 4);

-- Default Site Settings
INSERT INTO `site_settings` (`id`, `site_name`, `site_title`, `site_description`, `admin_slug`, `ads_enabled`, `schema_org_enabled`, `show_disclaimer`, `homepage_channels_limit`, `homepage_completed_days`, `slider_duration_seconds`) VALUES
(UUID(), 'ePlayHD', 'ePlayHD - Live Sports Streaming', 'Watch live sports matches online. Get live scores, schedules and streaming links.', 'admin', 0, 1, 1, 6, 3, 5);

SET FOREIGN_KEY_CHECKS = 1;
