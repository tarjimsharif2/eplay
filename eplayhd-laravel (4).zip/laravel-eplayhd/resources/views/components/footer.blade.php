<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            {{-- Brand --}}
            <div class="footer-brand">
                <a href="{{ route('home') }}" class="footer-logo">
                    @if($siteSettings?->logo_url)
                        <img src="{{ $siteSettings->logo_url }}" alt="{{ $siteSettings?->site_name }}" class="w-8 h-8 rounded-lg object-contain">
                    @else
                        <div class="logo-icon">
                            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                                <rect x="2" y="3" width="20" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>
                            </svg>
                        </div>
                    @endif
                    <span class="logo-text">{{ $siteSettings?->site_name ?? 'ePlayHD' }}</span>
                </a>
                <p class="footer-desc">Watch live sports matches online. Get live scores, schedules and streaming links.</p>
                @if($siteSettings?->telegram_link && $siteSettings->telegram_link !== '#')
                <a href="{{ $siteSettings->telegram_link }}" target="_blank" rel="noopener noreferrer" class="telegram-btn">
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.248-1.97 9.289c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.833.932z"/></svg>
                    Join Telegram
                </a>
                @endif
            </div>

            {{-- Quick Links --}}
            <div class="footer-col">
                <h4 class="footer-heading">Quick Links</h4>
                <nav class="footer-nav">
                    <a href="{{ route('home') }}" class="footer-link">Home</a>
                    <a href="{{ route('channels.index') }}" class="footer-link">Channels</a>
                    @foreach($footerPages as $page)
                        <a href="{{ route('page.show', $page->slug) }}" class="footer-link">{{ $page->title }}</a>
                    @endforeach
                </nav>
            </div>

            {{-- Tournaments --}}
            @if($activeTournaments->count() > 0)
            <div class="footer-col">
                <h4 class="footer-heading">
                    <svg class="w-4 h-4 inline mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>
                    Tournaments
                </h4>
                <nav class="footer-nav">
                    @foreach($tournamentsBySport as $sport => $sportTournaments)
                        <div class="footer-sport-group">
                            <span class="footer-sport-label">{{ $sport }}</span>
                            @foreach($sportTournaments->take(3) as $tournament)
                                <a href="{{ route('tournament.show', $tournament->slug) }}" class="footer-link pl-2">
                                    @if($tournament->logo_url)
                                        <img src="{{ $tournament->logo_url }}" alt="" class="w-3.5 h-3.5 inline object-contain mr-1">
                                    @endif
                                    {{ $tournament->name }}
                                </a>
                            @endforeach
                        </div>
                    @endforeach
                </nav>
            </div>
            @endif

            {{-- Legal --}}
            <div class="footer-col">
                <h4 class="footer-heading">Legal</h4>
                <nav class="footer-nav">
                    @foreach($footerPages->whereIn('slug', ['dmca', 'privacy', 'terms', 'contact-us', 'privacy-policy']) as $page)
                        <a href="{{ route('page.show', $page->slug) }}" class="footer-link">{{ $page->title }}</a>
                    @endforeach
                </nav>
            </div>
        </div>

        {{-- Disclaimer --}}
        @if($siteSettings?->show_disclaimer)
        <div class="footer-disclaimer">
            <div class="disclaimer-box">
                <div class="disclaimer-title">
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                    <h3>Important Disclaimer</h3>
                </div>
                <p>{{ $siteSettings->disclaimer_text ?? 'All content displayed here is from publicly available sources on the internet. We do not own or claim ownership of any matches, streams, or highlights. This platform is for informational purposes only.' }}</p>
            </div>
        </div>
        @endif

        <div class="footer-bottom">
            <p>{{ $siteSettings?->footer_text ?? '© ' . date('Y') . ' ' . ($siteSettings?->site_name ?? 'ePlayHD') . '. All rights reserved.' }}</p>
        </div>
    </div>
</footer>
