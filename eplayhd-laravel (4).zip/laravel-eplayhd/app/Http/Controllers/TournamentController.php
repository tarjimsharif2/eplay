<?php

namespace App\Http\Controllers;

use App\Models\Tournament;
use App\Models\TournamentPointsTable;
use App\Models\MatchModel;
use App\Models\SiteSettings;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Carbon\Carbon;

class TournamentController extends Controller
{
    public function show(string $slug)
    {
        $tournament = Tournament::with(['matches.teamA', 'matches.teamB', 'matches.sport'])
            ->where('slug', $slug)
            ->orWhere('id', $slug)
            ->first();

        if (!$tournament) abort(404);

        $siteSettings = SiteSettings::first();

        // Tournament matches grouped by status
        $matches = bMatchModel::with(['teamA', 'teamB', 'sport', 'innings'])
            ->where('tournament_id', $tournament->id)
            ->where('is_active', true)
            ->orderByRaw("FIELD(status,'live','upcoming','completed','abandoned','postponed')")
            ->orderBy('match_start_time')
            ->get();

        $liveMatches = $matches->where('status', 'live');
        $upcomingMatches = $matches->where('status', 'upcoming');
        $completedMatches = $matches->where('status', 'completed')->sortByDesc('updated_at');

        // Points table
        $pointsTable = TournamentPointsTable::where('tournament_id', $tournament->id)
            ->with('team')
            ->orderBy('position')
            ->get();

        // Participating teams
        $participatingTeams = collect();
        if ($tournament->show_participating_teams) {
            if ($tournament->custom_participating_teams) {
                $participatingTeams = collect($tournament->custom_participating_teams);
            } else {
                // Auto-get from matches
                $teamIds = $matches->pluck('team_a_id')->merge($matches->pluck('team_b_id'))->unique();
                $participatingTeams = \App\Models\Team::whereIn('id', $teamIds)->get();
            }
        }

        // SEO
        $seoTitle = $tournament->seo_title
            ?? ($tournament->name . ' ' . $tournament->season . ' | ' . ($siteSettings?->site_name ?? 'ePlayHD'));
        $seoDescription = $tournament->seo_description
            ?? ('Follow ' . $tournament->name . ' ' . $tournament->season . ' live scores, results and points table.');
        $seoKeywords = $tournament->seo_keywords ?? '';

        // Ad positions from settings
        $adPositions = json_decode($siteSettings?->tournament_page_ad_positions ?? '{}', true) ?? [];

        return view('pages.tournament', compact(
            'tournament', 'matches', 'liveMatches', 'upcomingMatches', 'completedMatches',
            'pointsTable', 'participatingTeams', 'seoTitle', 'seoDescription', 'seoKeywords',
            'siteSettings', 'adPositions'
        ));
    }

    public function apiTournaments(Request $request): JsonResponse
    {
        $tournaments = Tournament::where('is_active', true)
            ->orderBy('created_at', 'desc')
            ->get(['id', 'name', 'sport', 'season', 'logo_url', 'slug', 'show_in_menu']);

        return response()->json(['tournaments' => $tournaments]);
    }

    public function apiPointsTable(string $id): JsonResponse
    {
        $table = TournamentPointsTable::where('tournament_id', $id)
            ->with('team')
            ->orderBy('position')
            ->get();

        return response()->json(['points_table' => $table]);
    }
}
