@extends('layouts.admin')
@section('title', 'Innings')
@section('content')
<div class="admin-header">
    <div>
        <a href="{{ route('admin.matches.show', $match->id) }}" style="font-size:0.875rem;color:var(--muted);">← Back</a>
        <h1 class="admin-page-title">Innings: {{ $match->teamA?->short_name }} vs {{ $match->teamB?->short_name }}</h1>
    </div>
    <button onclick="document.getElementById('add-inn-modal').style.display='flex'" class="btn-primary-sm">+ Add Innings</button>
</div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>Innings</th><th>Batting Team</th><th>Score</th><th>Overs</th><th>Extras</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
            @forelse($match->innings->sortBy('innings_number') as $inn)
            <tr>
                <td style="font-weight:700">{{ $inn->innings_number }}</td>
                <td style="font-size:0.875rem">{{ $inn->battingTeam?->name ?? '–' }}</td>
                <td style="font-weight:700;color:var(--primary);font-size:1rem">{{ $inn->runs ?? '–' }}/{{ $inn->wickets ?? '–' }}</td>
                <td style="color:var(--muted)">{{ $inn->overs }}</td>
                <td style="color:var(--muted)">{{ $inn->extras }}</td>
                <td>
                    @if($inn->is_current)<span class="badge badge-live-sm">Current</span>@endif
                    @if($inn->declared)<span class="badge badge-completed-sm">Declared</span>@endif
                </td>
                <td>
                    <form method="POST" action="{{ route('admin.match.innings.destroy', [$match->id, $inn->id]) }}" style="display:inline">@csrf @method('DELETE')<button type="submit" class="btn-sm btn-delete" data-confirm="Delete innings?">Del</button></form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:2rem;">No innings added.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
{{-- Quick update form --}}
<div class="admin-card">
    <div class="admin-card-header"><h2 class="admin-card-title">Quick Update Innings</h2></div>
    <div class="admin-card-body">
        @foreach($match->innings->sortBy('innings_number') as $inn)
        <form method="POST" action="{{ route('admin.match.innings.update', [$match->id, $inn->id]) }}" style="display:flex;gap:0.75rem;align-items:flex-end;margin-bottom:0.75rem;flex-wrap:wrap;">
            @csrf @method('PUT')
            <div style="font-weight:600;font-size:0.875rem;min-width:100px">Innings {{ $inn->innings_number }}<br><span style="color:var(--muted);font-size:0.75rem">{{ $inn->battingTeam?->short_name }}</span></div>
            <div><label class="form-label" style="font-size:0.75rem">Runs</label><input type="number" name="runs" class="form-input" value="{{ $inn->runs }}" style="width:80px"></div>
            <div><label class="form-label" style="font-size:0.75rem">Wickets</label><input type="number" name="wickets" class="form-input" value="{{ $inn->wickets }}" style="width:80px" max="10"></div>
            <div><label class="form-label" style="font-size:0.75rem">Overs</label><input type="number" name="overs" class="form-input" value="{{ $inn->overs }}" style="width:80px" step="0.1"></div>
            <div><label class="form-label" style="font-size:0.75rem">Extras</label><input type="number" name="extras" class="form-input" value="{{ $inn->extras }}" style="width:80px"></div>
            <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.8rem;cursor:pointer"><input type="hidden" name="declared" value="0"><input type="checkbox" name="declared" class="form-checkbox" value="1" {{ $inn->declared ? 'checked' : '' }}>Dec</label>
            <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.8rem;cursor:pointer"><input type="hidden" name="is_current" value="0"><input type="checkbox" name="is_current" class="form-checkbox" value="1" {{ $inn->is_current ? 'checked' : '' }}>Current</label>
            <button type="submit" class="btn-sm btn-success">Save</button>
        </form>
        @endforeach
    </div>
</div>
{{-- Add modal --}}
<div id="add-inn-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:var(--card);border:1px solid var(--border);border-radius:1rem;padding:1.5rem;width:100%;max-width:480px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
            <h3 style="font-family:var(--font-display);font-weight:700;">Add Innings</h3>
            <button onclick="document.getElementById('add-inn-modal').style.display='none'" style="color:var(--muted);font-size:1.5rem;background:none;border:none;cursor:pointer;">&times;</button>
        </div>
        <form method="POST" action="{{ route('admin.match.innings.store', $match->id) }}">@csrf
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                <div class="form-group"><label class="form-label">Innings No. *</label>
                    <select name="innings_number" class="form-select" required>
                        @for($i=1;$i<=4;$i++)<option value="{{ $i }}">Innings {{ $i }}</option>@endfor
                    </select></div>
                <div class="form-group"><label class="form-label">Batting Team *</label>
                    <select name="batting_team_id" class="form-select" required>
                        <option value="{{ $match->teamA?->id }}">{{ $match->teamA?->name }}</option>
                        <option value="{{ $match->teamB?->id }}">{{ $match->teamB?->name }}</option>
                    </select></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.75rem;">
                <div class="form-group"><label class="form-label">Runs</label><input type="number" name="runs" class="form-input" min="0"></div>
                <div class="form-group"><label class="form-label">Wickets</label><input type="number" name="wickets" class="form-input" min="0" max="10"></div>
                <div class="form-group"><label class="form-label">Overs</label><input type="number" name="overs" class="form-input" step="0.1"></div>
            </div>
            <div style="display:flex;gap:1.5rem;margin-bottom:1rem;">
                <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="declared" value="0"><input type="checkbox" name="declared" class="form-checkbox" value="1">Declared</label>
                <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.875rem;cursor:pointer"><input type="hidden" name="is_current" value="0"><input type="checkbox" name="is_current" class="form-checkbox" value="1">Current Innings</label>
            </div>
            <div style="display:flex;gap:0.75rem;">
                <button type="submit" class="btn-primary-sm" style="flex:1;justify-content:center">Add</button>
                <button type="button" onclick="document.getElementById('add-inn-modal').style.display='none'" class="btn-sm btn-edit">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
