<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MatchModel;
use App\Models\Tournament;
use App\Models\Team;
use App\Models\Channel;
use App\Models\StreamingServer;
use App\Models\SiteSettings;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = $this->getStats();
        $recentMatches = bMatchModel::with(['teamA', 'teamB', 'tournament'])
            ->orderBy('updated_at', 'desc')
            ->take(10)
            ->get();

        $liveMatches = bMatchModel::with(['teamA', 'teamB'])
            ->where('status', 'live')
            ->get();

        $settings = SiteSettings::first();

        return view('admin.dashboard', compact('stats', 'recentMatches', 'liveMatches', 'settings'));
    }

    public function stats(): JsonResponse
    {
        return response()->json($this->getStats());
    }

    private function getStats(): array
    {
        return [
            'total_matches' => bMatchModel::count(),
            'live_matches' => bMatchModel::where('status', 'live')->count(),
            'upcoming_matches' => bMatchModel::where('status', 'upcoming')->count(),
            'completed_matches' => bMatchModel::where('status', 'completed')->count(),
            'total_tournaments' => Tournament::count(),
            'active_tournaments' => Tournament::where('is_active', true)->where('is_completed', false)->count(),
            'total_teams' => Team::count(),
            'total_channels' => Channel::count(),
            'active_servers' => StreamingServer::where('is_active', true)->count(),
            'broken_servers' => StreamingServer::where('is_working', false)->count(),
        ];
    }
}
