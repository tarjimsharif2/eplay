<?php
namespace App\Http\Controllers;
use App\Models\SiteSettings;
class AdsTxtController extends Controller
{
    public function show()
    {
        $settings = SiteSettings::first();
        $content = $settings?->ads_txt_content ?? '';
        return response($content, 200)->header('Content-Type', 'text/plain');
    }
}
