<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
class Profile extends Model {
    protected $table = 'profiles';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['user_id','email','full_name','avatar_url','is_admin','preferences'];
    protected $casts = ['is_admin'=>'boolean','preferences'=>'array'];
    protected static function boot() { parent::boot(); static::creating(fn($m) => $m->id = $m->id ?: (string) Str::uuid()); }
    public function user() { return $this->belongsTo(User::class,'user_id'); }
}
