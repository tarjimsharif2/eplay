<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\MatchModel;
use App\Models\Tournament;
use Illuminate\Http\Request;

class BannerAdminController extends Controller
{
    public function index() {
        $banners = Banner::with(['match','tournament'])->orderBy('display_order')->get();
        $matches = bMatchModel::where('is_active',true)->with(['teamA','teamB'])->orderBy('updated_at','desc')->take(50)->get();
        $tournaments = Tournament::where('is_active',true)->orderBy('name')->get();
        return view('admin.banners.index', compact('banners','matches','tournaments'));
    }
    public function store(Request $request) {
        $v = $request->validate(['title'=>'required|string|max:500','image_url'=>'required|string','link_url'=>'nullable|string','banner_type'=>'nullable|in:match,tournament,custom','badge_type'=>'nullable|in:none,live,upcoming,watch_now','match_id'=>'nullable|exists:matches,id','tournament_id'=>'nullable|exists:tournaments,id','display_order'=>'nullable|integer','is_active'=>'boolean','subtitle'=>'nullable|string']);
        Banner::create($v);
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Banner created.');
    }
    public function update(Request $request, string $id) {
        Banner::findOrFail($id)->update($request->validate(['title'=>'required|string|max:500','image_url'=>'required|string','link_url'=>'nullable|string','banner_type'=>'nullable|in:match,tournament,custom','badge_type'=>'nullable|in:none,live,upcoming,watch_now','match_id'=>'nullable|exists:matches,id','tournament_id'=>'nullable|exists:tournaments,id','display_order'=>'nullable|integer','is_active'=>'boolean','subtitle'=>'nullable|string']));
        return $request->wantsJson() ? response()->json(['success'=>true]) : back()->with('success','Banner updated.');
    }
    public function destroy(string $id) { Banner::findOrFail($id)->delete(); return back()->with('success','Banner deleted.'); }
    public function reorder(Request $request) {
        foreach ($request->order as $item) { Banner::where('id',$item['id'])->update(['display_order'=>$item['order']]); }
        return response()->json(['success'=>true]);
    }
}
